'use strict';

angular.module('smoApp')
  .controller('PageHeaderCtrl', function ($scope,$filter) {
     $scope.clock = function(){
     	$scope.today = $filter('date')( Date.now(),'dd MMMM yyyy HH:mm');
     	// console.log($scope.today)
     	// $timeout($scope.clock(),1000)
     }
     $scope.clock();
     
  });
