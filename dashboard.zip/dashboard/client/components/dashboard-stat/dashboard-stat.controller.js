'use strict';

angular.module('smoApp')
  .controller('DashboardStatCtrl', function ($scope,$rootScope,$http,Pipelines,$cookies) {
    $scope.currUser = $cookies.getObject('currentUser')
    // console.log($scope.currUser);
    Pipelines.getByDeptId({},{deptId:2},function(cp){
    	$scope.corporatePipeline = cp.count;
    })
    Pipelines.getByDeptId({},{deptId:1},function(cm){
    	$scope.commercialPipeline = cm.count;
    })
    Pipelines.getByDeptId({},{deptId:4},function(pp){
    	$scope.publicPipeline = pp.count;
    })
    Pipelines.get(function(pipe){
    	$scope.totalNewPipeline = 0
    	angular.forEach(pipe.offerings, function(r){
    		if(r.createdAt==r.updatedAt){
    			$scope.totalNewPipeline +=1;
    		}
    	})
    })
  });
