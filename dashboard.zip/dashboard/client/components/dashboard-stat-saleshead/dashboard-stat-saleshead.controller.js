'use strict';

angular.module('smoApp')
  .controller('DashboardStatSalesheadCtrl', function ($scope,$rootScope,$http,Pipelines,$cookies) {
    $scope.currUser = $cookies.getObject('currentUser')
    // console.log($scope.currUser);
    Pipelines.getByDeptId({},{deptId:$scope.currUser.departementId},function(p){
    	$scope.pipelines = p.count;
    })
    
  });
