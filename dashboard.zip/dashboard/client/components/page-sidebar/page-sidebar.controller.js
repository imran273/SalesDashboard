'use strict';

angular.module('smoApp')
.controller('PageSidebarCtrl', function ($scope,$rootScope,$location,$cookies) {
	$scope.currUser = $cookies.getObject('currentUser');

	$scope.viewPort = $rootScope.getViewPort();
	$scope.resBreakpointMd = $rootScope.getResponsiveBreakpoint('md');
	$scope.handleToggler = function(){
		if ($.cookie && $.cookie('sidebar_closed') === '1' && $scope.viewPort.width >= $scope.resBreakpointMd) {
			$('body').addClass('page-sidebar-closed');
			$('.page-sidebar-menu').addClass('page-sidebar-menu-closed');
		}
	}
	$scope.handleToggler();
	//console.log($scope.viewPort);
	$scope.isActive = function(route) {
	  //console.log('route: '+route+' currRoute: '+$location.path())
	  return route === $location.path();
	};
	$scope.sidebarMenu = [{
		href:'/',
		title:'Dashboard',
		icon:'icon-home',
		isShow: ($scope.currUser.roleId==1 || $scope.currUser.roleId==2 || $scope.currUser.roleId== 3)? true:false
	},{
		href:'/saleshead',
		title:'Sales Head Summary',
		icon: 'icon-pie-chart',
		isShow: ($scope.currUser.roleId==5)? true:false
	},{
		href:'/sales',
		title:'Sales Summary',
		icon: 'icon-pie-chart',
		isShow:($scope.currUser.roleId==4)? true:false
	},{
		href:'/clients',
		title:'Customer',
		icon: 'icon-users',
		isShow:($scope.currUser.roleId==1 || $scope.currUser.roleId== 4)? true:false
	},{
		href:'/pipelines',
		title:'Pipelines',
		icon: 'icon-share',
		isShow:($scope.currUser.roleId==1 || $scope.currUser.roleId== 4)? true:false
	},{
		href:'/products',
		title:'Products',
		icon: 'icon-basket',
		isShow:($scope.currUser.roleId==1 || $scope.currUser.roleId== 4)? true:false
	},{
		href:'/schedules',
		title:'Appointment',
		icon: 'icon-calendar',
		isShow:($scope.currUser.roleId== 4)? true:false
	},{
		href:'/realization',
		title:'Realization',
		icon: 'icon-check',
		isShow:true
	},{
		href:'/callreport',
		title:'Call Report',
		icon: 'icon-graph',
		isShow:($scope.currUser.roleId==1 || $scope.currUser.roleId== 4)? true:false
	},{
		href:'/users',
		title:'Users',
		icon:'icon-user',
		isShow:($scope.currUser.roleId==1 || $scope.currUser.roleId== 2 || $scope.currUser.roleId== 3 || $scope.currUser.roleId== 5)? true:false
	},{
		href:'/division',
		title:'Division',
		icon: 'icon-layers',
		isShow:($scope.currUser.roleId==1)? true:false
	},{
		href:'/departements',
		title:'Departements',
		icon: 'icon-direction',
		isShow:($scope.currUser.roleId==1)? true:false
	},{
		href:'/status',
		title:'Status',
		icon: 'icon-flag',
		isShow:($scope.currUser.roleId==1)? true:false
	},{
		href:'/salesCycles',
		title:'Sales Cycles',
		icon: 'icon-refresh',
		isShow:($scope.currUser.roleId==1)? true:false
	},{
		href:'/buc',
		title:'Business Unit Code',
		icon: 'icon-notebook',
		isShow:($scope.currUser.roleId==1)? true:false
	},{
		href:'/industrialSectors',
		title:'Industrial Sectors',
		icon: 'icon-directions',
		isShow:($scope.currUser.roleId==1)? true:false
	}]
	$scope.handleSidebarToggler = function () {
		var body = $('body');
		
		var sidebar = $('.page-sidebar');
		var sidebarMenu = $('.page-sidebar-menu');
		$(".sidebar-search", sidebar).removeClass("open");

		if (body.hasClass("page-sidebar-closed")) {
			body.removeClass("page-sidebar-closed");
			sidebarMenu.removeClass("page-sidebar-menu-closed");
			if ($.cookie) {
				$.cookie('sidebar_closed', '0');
			}
		} else {
			body.addClass("page-sidebar-closed");
			sidebarMenu.addClass("page-sidebar-menu-closed");
			if (body.hasClass("page-sidebar-fixed")) {
				sidebarMenu.trigger("mouseleave");
			}
			if ($.cookie) {
				$.cookie('sidebar_closed', '1');
			}
		}

		$(window).trigger('resize');
	};
	$scope.handleSidebarAndContentHeight = function () {
		var content = $('.page-content');
		var sidebar = $('.page-sidebar');
		var headerHeight = $('.page-header').outerHeight();
       	// console.log(headerHeight)
        // var body = $('body');
        // var height;
        
        sidebar.attr('style', 'margin-top:' + headerHeight + 'px');
        content.attr('style', 'min-height:700px;margin-top:' + headerHeight + 'px');
        var available_height = content.outerHeight() + headerHeight;        
        sidebar.attr('style', 'min-height:700px;width: 235px; margin-top:'+headerHeight+'px');
        // if (body.hasClass("page-footer-fixed") === true && body.hasClass("page-sidebar-fixed") === false) {
        //     var available_height = $scope.viewPort.height - $('.page-footer').outerHeight() - $('.page-header').outerHeight();
        //     if (content.height() < available_height) {
        //         content.attr('style', 'min-height:' + available_height + 'px');
        //     }
        // } else {
        //     if (body.hasClass('page-sidebar-fixed')) {
        //         height = _calculateFixedSidebarViewportHeight();
        //         if (body.hasClass('page-footer-fixed') === false) {
        //             height = height - $('.page-footer').outerHeight();
        //         }
        //     } else {
        //         var headerHeight = $('.page-header').outerHeight();
        //         var footerHeight = $('.page-footer').outerHeight();

        //         if ($scope.viewPort.width < $scope.resBreakpointMd) {
        //             height = $scope.viewPort.height - headerHeight - footerHeight;
        //         } else {
        //             height = sidebar.height() + 20;
        //         }

        //         if ((height + headerHeight + footerHeight) <= $scope.viewPort.height) {
        //             height = $scope.viewPort.height - headerHeight - footerHeight;
        //         }
        //     }
        //     content.attr('style', 'min-height:' + height + 'px');
        // }
    };
    $scope.handleSidebarAndContentHeight();

});
