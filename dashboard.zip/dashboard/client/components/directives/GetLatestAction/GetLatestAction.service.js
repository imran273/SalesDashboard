'use strict';

angular.module('smoApp')
  .directive('getnextaction', function () {
  return {
    template: '<span>{{nextAction}}</span>',
    restrict: 'EA',
    require: '^ngModel',
    scope: { ngModel: '='},
    controller: [
    '$scope',
    '$http',
    '$rootScope',
    function ($scope, $http, $rootScope) {
      $scope.getName = function (offeringId) {
        // console.log(offeringId)
        if (offeringId && offeringId>1) {
          $http.get($rootScope.baseApi + 'offering-actions?q[offeringId]='+offeringId).success(function (result) {
            // console.log(result)
            if(result && result.count > 0){
              var c = result.count -1;
              $scope.nextAction = result.offeringActions[c].nextAction;              
            } else {
              $scope.nextAction = 'Filled on Realization'
            }
          });
        } 
      };
    }
    ],
    link: function (scope, elm, attr, ctrl) {
      scope.getName(scope.ngModel);
    }
  }
});