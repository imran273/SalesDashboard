'use strict';

describe('Service: GetLatestAction', function () {

  // load the service's module
  beforeEach(module('smoApp'));

  // instantiate service
  var GetLatestAction;
  beforeEach(inject(function (_GetLatestAction_) {
    GetLatestAction = _GetLatestAction_;
  }));

  it('should do something', function () {
    expect(!!GetLatestAction).toBe(true);
  });

});
