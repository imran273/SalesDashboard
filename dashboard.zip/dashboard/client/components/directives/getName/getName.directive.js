'use strict';

angular.module('smoApp')
  .directive('getName', function () {
    return {
    template: '<span>{{name}}</span>',
    restrict: 'EA',
    require: '^ngModel',
    scope: { ngModel: '=',endpoint:'@',field:'@'},
    controller: [
      '$scope',
      '$http',
      '$rootScope',
      function ($scope, $http, $rootScope) {
        $scope.getName = function (endpoint,userid,field) {
          if(endpoint.search("-") != -1) {
            $scope.res = endpoint.split("-");   
            $scope.e = ''; 

            for(var i=0;i<$scope.res.length;i++){
              // console.log($scope.res[i])
              if(i>0){
                $scope.res[i]=$scope.res[i].substring(0, 1).toUpperCase() + $scope.res[i].substring(1).toLowerCase();
              }
              $scope.e +=$scope.res[i];
            }    
          } else {
            $scope.e = endpoint;
          }
          
          if (userid) {
            $http.get($rootScope.baseApi + endpoint+'/' + userid).success(function (result) {
              if(result && result.count > 0){
                // console.log($scope.e)
              	$scope.name = (field)? result[$scope.e][0][field] :result[$scope.e][0].name;
              }	else {
              	$scope.name = '-'
              	//console.log('post failed, check your endpoint names and Id')
              }
            });
          } else {
            $scope.name = '-';
          }
        };
      }
    ],
    link: function (scope, elm, attr, ctrl) {
      scope.getName(scope.endpoint, scope.ngModel,scope.field);
    }
  };
  });