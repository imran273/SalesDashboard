'use strict';

angular.module('smoApp')
.directive('clientPic', function () {
	return {
		template: '<span>{{name}} {{phone}}</span>',
		restrict: 'EA',
		require: '^ngModel',
		scope: { ngModel: '=',endpoint:'@'},
		controller: [
		'$scope',
		'$http',
		'$rootScope',
		function ($scope, $http, $rootScope) {
			$scope.getName = function (endpoint,userid) {
				if (userid && userid>1) {
					$http.get($rootScope.baseApi + endpoint+'/' + userid).success(function (result) {
						if(result && result.count > 0){
							
							$scope.name = result.clientPics[0].name;
							$scope.phone = '('+result.clientPics[0].phone+')';
						}	else {
							
						}
					});
				} 
			};
		}
		],
		link: function (scope, elm, attr, ctrl) {
			scope.getName(scope.endpoint, scope.ngModel);
		}
	}
});