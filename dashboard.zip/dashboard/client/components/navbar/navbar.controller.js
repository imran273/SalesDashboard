'use strict';

angular.module('smoApp')
  .controller('NavbarCtrl', function ($scope, $location,$cookies) {
  	$scope.currUser = $cookies.getObject('currentUser')
  	// console.log($scope.currUser)
      $scope.logout = function(){
        $cookies.remove('currentUser')
        $location.path('login')
      }
    
  });