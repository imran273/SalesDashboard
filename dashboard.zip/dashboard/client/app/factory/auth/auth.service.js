'use strict';
angular.module('smoApp').factory('Auth', function ($cookies) {
  return {
    isLogin: function () {
      return $cookies.get('currentUser') == angular.noop() ? true : false;
    }
  };
});