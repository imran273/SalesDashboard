'use strict';
describe('Filter: vidcrypt', function () {
  // load the filter's module
  beforeEach(module('smoApp'));
  // initialize a new instance of the filter before each test
  var vidcrypt;
  beforeEach(inject(function ($filter) {
    vidcrypt = $filter('vidcrypt');
  }));
  it('should return the input prefixed with "vidcrypt filter:"', function () {
    var text = 'angularjs';
    expect(vidcrypt(text)).toBe('vidcrypt filter: ' + text);
  });
});