'use strict';
angular.module('smoApp').filter('vidcrypt', function () {
  return function (input) {
    return CryptoJS.SHA1(CryptoJS.MD5(input).toString()).toString();
  };
});
angular.module('smoApp').filter('dateZero', function ($filter) {
  return function (input) {
    if (input === '0000-00-00 00:00:00') {
      return '-';
    } else {
      return $filter('date')(input, 'dd-MM-yyyy');
    }
  };
});
angular.module('smoApp').filter('dateZero2', function ($filter) {
  return function (input) {
    if (input === '0000-00-00 00:00:00' || input === null||input === undefined) {
      return 'Filled on Realization';
    } else {
      return $filter('date')(input, 'dd-MM-yyyy');
    }
  };
});
angular.module('smoApp').filter('commentFilter', function ($filter) {

  return function (input) {
    // console.log(input)
    if (input === null||input === undefined) {
      return 'No available comment yet!';
    } else {
      return input
    }
  };
});
