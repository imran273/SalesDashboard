'use strict';
angular.module('smoApp').config(function ($stateProvider) {
  $stateProvider.state('products', {
    url: '/products',
    templateUrl: 'app/products/products.html',
    controller: 'ProductsCtrl'
  });
});
angular.module('smoApp').controller('modalProducts', function ($scope, $rootScope, $modalInstance, Departements, Products, toastr, mData, $cookies) {
  $scope.input = {};
  $scope.currUser = $cookies.getObject('currentUser');
  if (mData.id) {
    $scope.title = 'Edit Products';
    Products.get({}, { id: mData.id }, function (u) {
      // console.log(u)
      $scope.input = u.products[0];
    });
  } else {
    $scope.title = 'Add Products'  //Behin Add Modal
;
  }
  $scope.types = [
    {
      id: 'cash',
      name: 'Cash'
    },
    {
      id: 'trade',
      name: 'Trade'
    },
    {
      id: 'other',
      name: 'Other'
    }
  ];
  $scope.categories = [
    {
      id: 'simple',
      name: 'Simple'
    },
    {
      id: 'medium',
      name: 'Medium'
    },
    {
      id: 'complex',
      name: 'Complex'
    }
  ];
  Departements.get(function (d) {
    $scope.departments = d.departements;
  });
  if ($scope.currUser.roleId === 1 || $scope.currUser.roleId === 2) {
    $scope.departementDisable = false;
  } else {
    $scope.departementDisable = true;
  }
  $scope.ok = function () {
    $scope.errors = [];
    //input validation		
    if ($scope.input.name === angular.noop())
      $scope.errors.push({ text: 'Name is required' });
    if ($scope.input.description === angular.noop())
      $scope.errors.push({ text: 'Description is required' });
    if ($scope.input.type === angular.noop())
      $scope.errors.push({ text: 'Product type is required' });
    if ($scope.input.category === angular.noop())
      $scope.errors.push({ text: 'Product category is required' });
    if ($scope.currUser.roleId === 1 || $scope.currUser.roleId === 2) {
      if ($scope.input.departementId === angular.noop())
        $scope.errors.push({ text: 'Department is required' });
    }
    if ($scope.errors.length === 0) {
      console.log($scope.input);
      $scope.errors = undefined;
      var product = Products.get();
      product.name = $scope.input.name;
      product.description = $scope.input.description;
      product.category = $scope.input.category;
      product.type = $scope.input.type;
      if ($scope.currUser.roleId === 1 || $scope.currUser.roleId === 2) {
        product.departementId = $scope.input.departementId;
      } else {
        product.departementId = $scope.currUser.departementId;
      }
      if (mData.id) {
        product.$update({ id: mData.id }, function (res) {
          toastr.success($scope.input.name + ' has been updated!', 'Products');
          $modalInstance.close();
        });
      } else {
        product.$save(function (res) {
          // console.log(res)
          toastr.success($scope.input.name + ' has been added!', 'Products');
          $modalInstance.close();
        });
      }
    }
  };
  $scope.cancel = function () {
    $modalInstance.dismiss('cancel');
  };
});