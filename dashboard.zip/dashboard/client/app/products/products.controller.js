'use strict';
angular.module('smoApp').controller('ProductsCtrl', function ($scope, $rootScope, $cookies, Auth, $http, Products, Departements, $modal, $location, toastr) {
  $location.path(Auth.isLogin() ? 'login' : 'products');
  $scope.page = {
    title: 'Products',
    desc: 'Products Management'
  };
  $scope.currUser = $cookies.getObject('currentUser');
  $scope.departments = Departements.get();
  $scope.getProducts = function () {
    if ($scope.currUser.roleId === 4 || $scope.currUser.roleId === 5 || $scope.currUser.roleId === 3) {
      Products.getByDeptId({}, { deptId: $scope.currUser.departementId }, function (p) {
        $scope.prd = p.products;
        $scope.dtCount = p.count;
        $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage)+1;
        $scope.offset = 0;
      });
    } else {
      Products.get(function (p) {
        $scope.prd = p.products;
        $scope.dtCount = p.count;
        $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage)+1;
        $scope.offset = 0;
      });
    }
  };
  $scope.currentPage = 1;
  $scope.prevDisable = true;
  // console.log($scope.currentPage);
  $scope.next = function(){
    $scope.currentPage  = $scope.currentPage + 1;
    if($scope.currentPage < $scope.numPages){
        // $scope.currentPage = $scope.numPages;
        $scope.nextDisable = false;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
        // console.log($scope.offset);
    } else if($scope.currentPage = $scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
    }else{
      $scope.nextDisable = false;
      $scope.prevDisable = false;
    }
    // console.log($scope.currentPage);
    // console.log($scope.numPages);
  }
  $scope.prev = function(){
    $scope.currentPage  = $scope.currentPage -1;
    if($scope.currentPage > 1){
        // $scope.currentPage = 1;
        $scope.nextDisable = false;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
        // console.log($scope.offset)
    } else if($scope.currentPage = 1){
        $scope.nextDisable = false;
        $scope.prevDisable = true;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
    }
  }
  $scope.itemByPageChange = function(){
    $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage)+1;
    if($scope.currentPage >=$scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = true;
    } else{
        $scope.nextDisable = false;
        $scope.prevDisable = false;
    }
  }
  $scope.currPageChange = function(){
    if($scope.currentPage >=$scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = false;
        $scope.currentPage = $scope.numPages;
    } else if($scope.currentPage <=1){
        $scope.prevDisable = true;
        $scope.nextDisable = false;
        $scope.currentPage = 1;
    } else{
        $scope.nextDisable = false;
        $scope.prevDisable = false;
    } 
    $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
  };

  $scope.getProducts();
  $scope.modalTemplateUrl = 'app/products/products.modal.html';
  $scope.modalSize = 'm';
  //open modal for add Item
  $scope.add = function () {
    var modalInstance = $modal.open({
      templateUrl: $scope.modalTemplateUrl,
      controller: 'modalProducts',
      size: $scope.modalSize,
      // windowClass:'devid-modal',
      resolve: {
        mData: function () {
          return false;
        }
      }
    });
    modalInstance.result.then(function (res) {
      $scope.getProducts();
    });
  };
  //open modal for edit Item
  $scope.edit = function (id) {
    var modalInstance = $modal.open({
      templateUrl: $scope.modalTemplateUrl,
      controller: 'modalProducts',
      size: $scope.modalSize,
      resolve: {
        mData: function () {
          return { id: id };
        }
      }
    });
    modalInstance.result.then(function (res) {
      $scope.getProducts();
    });
  };
  //open modal for add delete
  $scope.delete = function (id, name) {
    var modalInstance = $modal.open({
      templateUrl: 'app/app.modal.delete.html',
      controller: 'modalDelete',
      size: $scope.modalSize,
      resolve: {
        mData: function () {
          return {
            id: id,
            name: name
          };
        }
      }
    });
    modalInstance.result.then(function (res) {
      var product = Products.get();
      product.$delete({ id: res }, function (u) {
        toastr.success('Products has been deleted', 'Products');
        $scope.getProducts();
      });
    });
  };
  $scope.selectedAll = false;
  $scope.checkAll = function(){
    console.log('cek')
    $scope.selectedAll = !$scope.selectedAll;
    angular.forEach($scope.prd, function (item) {
      item.Selected = $scope.selectedAll;
    });
  };
  $scope.removeSelected = function(){
    angular.forEach($scope.prd,function(item){
      if(item.Selected){
        var i = Products.get();
        i.$delete({id:item.id});
      }
    })
    $scope.getProducts();
  };
  $scope.itemsByPage = 10;
  $scope.types = [
    {
      id: 'cash',
      name: 'Cash'
    },
    {
      id: 'trade',
      name: 'Trade'
    },
    {
      id: 'other',
      name: 'Other'
    }
  ];
  $scope.categories = [
    {
      id: 'simple',
      name: 'Simple'
    },
    {
      id: 'medium',
      name: 'Medium'
    },
    {
      id: 'complex',
      name: 'Complex'
    }
  ];
  $scope.thead = [
    {
      title: '#',
      width: 25,
      noClick:true,
      attr: 'checklist'
    },
    {
      title: 'Name',
      width: 240,
      align: 'left',
      attr: 'name'
    },
    {
      title: 'Description',
      width: 250,
      align: 'center',
      attr: 'description'
    },
    {
      title: 'Product Type',
      width: 130,
      align: 'center',
      attr: 'type'
    },
    {
      title: 'Product Category',
      width: 140,
      align: 'center',
      attr: 'category'
    },
    {
      title: 'Department',
      width: 140,
      align: 'center',
      attr: 'departementId'
    },
    {
      title: 'Actions',
      width: 60,
      align: 'center',
      attr: 'actions'
    }
  ];
   $scope.tableWidth = 0;
  angular.forEach($scope.thead, function (t) {
    $scope.tableWidth = $scope.tableWidth + t.width;
  });
});
