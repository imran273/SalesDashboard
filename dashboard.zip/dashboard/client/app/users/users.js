'use strict';
angular.module('smoApp').config(function ($stateProvider) {
  $stateProvider.state('users', {
    url: '/users',
    templateUrl: 'app/users/users.html',
    controller: 'UsersCtrl'
  });
});
angular.module('smoApp').controller('modalUsers', function ($scope, $rootScope, $modalInstance, Users, Roles, Departements, Divisions, Sales, toastr, mData, $filter) {
  $scope.input = {};
  $scope.roles = Roles.get();
  $scope.departments = Departements.get();
  $scope.divisions = Divisions.get();
  // console.log(mData.id)
  if (mData.id) {
    //Begin Edit Modal 
    $scope.title = 'Edit Users';
    Users.get({}, { id: mData.id }, function (u) {
      $scope.input = u.users[0];
    });
  } else {
    $scope.title = 'Add Users'  //Behin Add Modal
;
  }
  //get roles
  $scope.ok = function () {
    $scope.errors = [];
    //input validation		
    if ($scope.input.name === angular.noop())
      $scope.errors.push({ text: 'Name is required' });
    if ($scope.input.email === angular.noop())
      $scope.errors.push({ text: 'Email is required' });
    if ($scope.input.username === angular.noop())
      $scope.errors.push({ text: 'Username is required' });
    if (mData.id === undefined) {
      if ($scope.input.psw === angular.noop())
        $scope.errors.push({ text: 'Password is required' });
    }
    if ($scope.input.roleId === angular.noop())
      $scope.errors.push({ text: 'Roles is required' });
    if ($scope.input.departementId === angular.noop())
      $scope.errors.push({ text: 'Department is required' });
    if ($scope.input.divisionId === angular.noop())
      $scope.errors.push({ text: 'Division is required' });
    if ($scope.errors.length === 0) {
      // console.log('save')
      console.log($scope.input);
      $scope.errors = undefined;
      var user = Users.get();
      user.name = $scope.input.name;
      user.email = $scope.input.email;
      user.username = $scope.input.username;
      if ($scope.input.psw) {
        user.password = $filter('vidcrypt')($scope.input.psw);
      }
      user.roleId = $scope.input.roleId;
      user.departementId = $scope.input.departementId;
      user.divisionId = $scope.input.divisionId;
      if (mData.id) {
        user.$update({ id: mData.id }, function (res) {
          var sales = Sales.get();
          sales.$query({ userId: mData.id }, function (r) {
            if (r.sales.length > 0) {
              sales.name = $scope.input.name;
              sales.departementId = $scope.input.departementId;
              sales.divisionId = $scope.input.divisionId;
              sales.$update({ id: r.sales[0].id });
            }
          });
          toastr.success($scope.input.name + ' has been updated!', 'Users');
          $modalInstance.close();
        });
      } else {
        user.$save(function (res) {
          var userSuccess = res.users[0];
          // console.log(userSuccess)
          if (userSuccess.roleId == 4) {
            var sales = Sales.get();
            sales.name = userSuccess.name;
            sales.level = 'account';
            sales.phone = 0;
            sales.departementId = userSuccess.departementId;
            sales.divisionId = userSuccess.divisionId;
            sales.userId = userSuccess.id;
            sales.$save(function (res) {
              toastr.success($scope.input.name + ' has been added!', 'Users');
              $modalInstance.close();
            }, function (err) {
              Users.$delete({ id: userSuccess.id });
              $modalInstance.close();
            });
          } else {
            toastr.success($scope.input.name + ' has been added!', 'Users');
            $modalInstance.close();
          }
        });
      }
    } else {
      console.log($scope.input);
    }
  };
  $scope.cancel = function () {
    $modalInstance.dismiss('cancel');
  };
});