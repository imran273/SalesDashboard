'use strict';
angular.module('smoApp').controller('UsersCtrl', function ($scope, $rootScope, $cookies, $http,Auth, Users, Roles, Departements, Divisions, Sales, $modal, $location, toastr) {
  $location.path(Auth.isLogin() ? 'login' : 'users');
  $scope.page = {
    title: 'Users',
    desc: 'Users Management'
  };

  $scope.roles = Roles.get();
  $scope.departments = Departements.get();
  $scope.divisions = Divisions.get();

  $scope.getUsers = function () {
    Users.get(function (u) {
        $scope.usr = u.users;
        // console.log($scope.usr);
        $scope.dtCount = u.count;
        $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage)+1;
        $scope.offset = 0;
    });
  };

  $scope.currentPage = 1;
  $scope.prevDisable = true;
  // console.log($scope.currentPage);
  $scope.next = function(){
    $scope.currentPage  = $scope.currentPage + 1;
    if($scope.currentPage < $scope.numPages){
        $scope.nextDisable = false;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
    } else if($scope.currentPage = $scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
    }else{
      $scope.nextDisable = false;
      $scope.prevDisable = false;
    }
    console.log($scope.currentPage);
    console.log($scope.numPages);
  }
  $scope.prev = function(){
    $scope.currentPage  = $scope.currentPage -1;
    if($scope.currentPage > 1){
        // $scope.currentPage = 1;
        $scope.nextDisable = false;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
        // console.log($scope.offset)
    } else if($scope.currentPage = 1){
        $scope.nextDisable = false;
        $scope.prevDisable = true;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
    }
  }
  $scope.itemByPageChange = function(){
    $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage)+1;
    if($scope.currentPage >=$scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = true;
    } else{
        $scope.nextDisable = false;
        $scope.prevDisable = false;
    }
  }
  $scope.currPageChange = function(){
    if($scope.currentPage >=$scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = false;
        $scope.currentPage = $scope.numPages;
    } else if($scope.currentPage <=1){
        $scope.prevDisable = true;
        $scope.nextDisable = false;
        $scope.currentPage = 1;
    } else{
        $scope.nextDisable = false;
        $scope.prevDisable = false;
    } 
    $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
  };
  $scope.getUsers();
  $scope.modalTemplateUrl = 'app/users/users.modal.html';
  $scope.modalSize = 'm';
  //open modal for add Item
  $scope.add = function () {
    var modalInstance = $modal.open({
      templateUrl: $scope.modalTemplateUrl,
      controller: 'modalUsers',
      size: $scope.modalSize,
      resolve: {
        mData: function () {
          return false;
        }
      }
    });
    modalInstance.result.then(function (res) {
      $scope.getUsers();
    });
  };
  //open modal for edit Item
  $scope.edit = function (id) {
    var modalInstance = $modal.open({
      templateUrl: $scope.modalTemplateUrl,
      controller: 'modalUsers',
      size: $scope.modalSize,
      resolve: {
        mData: function () {
          return { id: id };
        }
      }
    });
    modalInstance.result.then(function (res) {
      $scope.getUsers();
    });
  };
  //open modal for add delete
  $scope.delete = function (id, name) {
    var modalInstance = $modal.open({
      templateUrl: 'app/app.modal.delete.html',
      controller: 'modalDelete',
      size: $scope.modalSize,
      resolve: {
        mData: function () {
          return {
            id: id,
            name: name
          };
        }
      }
    });
    modalInstance.result.then(function (res) {
      var user = Users.get();
      var sales = Sales.get();
      sales.$query({ userId: res }, function (r) {
        if (r.sales.length > 0) {
          sales.$delete({ id: r.sales[0].id });
        }
      });
      user.$delete({ id: res }, function (u) {
        toastr.success('User has been deleted', 'Users');
        $scope.getUsers();
      });
    });
  };

  $scope.selectedAll = false;
  $scope.checkAll = function(){
    console.log('cek')
    $scope.selectedAll = !$scope.selectedAll;
    angular.forEach($scope.usr, function (item) {
      item.Selected = $scope.selectedAll;
    });
  };
  $scope.removeSelected = function(){
    angular.forEach($scope.usr,function (item){
      if(item.Selected){
        var i = Users.get();
        i.$delete({id:item.id});
      }
    })
    $scope.getUsers();
  };
  $scope.itemsByPage = 10;
  $scope.thead = [
    {
    title: '#',
    width: 25,
    noClick:true,
    attr: 'checklist'
    },
    {
      title: 'Name',
      width: 200,
      attr: 'name'
    },
    {
      title: 'Username',
      width: 200,
      attr: 'username'
    },
    {
      title: 'Email',
      width: 200,
      attr: 'email'
    },
    {
      title: 'Role',
      width: 100,
      attr: 'roleId'
    },
    {
      title: 'Department',
      width: 200,
      attr: 'departementId'
    },
    {
      title: 'Division',
      width: 200,
      attr: 'divisionId'
    },
    {
      title: 'Last Update',
      width: 100,
      attr: 'updatedAt'
    },
    {
      title: 'Actions',
      width: 100,
      attr: 'actions'
    }
  ];
});
