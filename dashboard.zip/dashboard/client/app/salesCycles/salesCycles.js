'use strict';
angular.module('smoApp').config(function ($stateProvider) {
  $stateProvider.state('salesCycles', {
    url: '/salesCycles',
    templateUrl: 'app/salesCycles/salesCycles.html',
    controller: 'SalesCyclesCtrl'
  });
});
angular.module('smoApp').controller('modalSalesCycles', function ($scope, $rootScope, $modalInstance, SalesCycles, Departements, Status, toastr, mData, $filter) {
  $scope.input = {};
  $scope.departments = Departements.get();
  $scope.status = Status.get();
  //console.log($scope.roles)
  if (mData.id) {
    $scope.title = 'Edit Sales Cycles';
    //Begin Edit Modal 
    SalesCycles.get({}, { id: mData.id }, function (u) {
      // console.log(u)
      $scope.input = u.salesCycles[0];
      $scope.selectedDepartment = u.salesCycles[0].departementId;
      $scope.selectedStatus = u.salesCycles[0].statusId;
    });
  } else {
    $scope.title = 'Add Sales Cycles'  //Behin Add Modal
;
  }
  //get roles
  $scope.ok = function () {
    $scope.errors = [];
    //input validation		
    if ($scope.input.simple === angular.noop())
      $scope.errors.push({ text: 'Simple value is required' });
    if ($scope.input.medium === angular.noop())
      $scope.errors.push({ text: 'Medium value is required' });
    if ($scope.input.complex === angular.noop())
      $scope.errors.push({ text: 'Complex value is required' });
    if ($scope.input.departementId === angular.noop())
      $scope.errors.push({ text: 'Department is required' });
    if ($scope.input.statusId === angular.noop())
      $scope.errors.push({ text: 'Status is required' });
    if ($scope.errors.length === 0) {
      console.log('save');
      $scope.errors = undefined;
      var salesCycle = salesCycles.get();
      // salesCycle.name = $scope.input.name;
      salesCycle.simple = $scope.input.simple;
      salesCycle.medium = $scope.input.medium;
      salesCycle.complex = $scope.input.complex;
      salesCycle.departementId = $scope.input.departementId;
      salesCycle.statusId = $scope.input.statusId;
      if (mData.id) {
        salesCycle.$update({ id: mData.id }, function (res) {
          //console.log(res)
          toastr.success($scope.input.name + ' has been updated!', 'Sales Cycles');
          $modalInstance.close();
        });
      } else {
        salesCycle.$save(function (res) {
          // console.log(res)
          toastr.success($scope.input.name + ' has been added!', 'Sales Cycles');
          $modalInstance.close();
        });
      }
    }
  };
  $scope.cancel = function () {
    $modalInstance.dismiss('cancel');
  };
});