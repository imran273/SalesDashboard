'use strict';
angular.module('smoApp').controller('SalesCyclesCtrl', function ($scope, $rootScope, $cookies, $http, Auth, SalesCycles, $modal, $location, toastr) {
  $location.path(Auth.isLogin() ? 'login' : 'salesCycles');
  $scope.page = {
    title: 'Sales Cycles',
    desc: 'Sales Cycles Management'
  };
  $scope.currUser = $cookies.getObject('currentUser');

$scope.getSalesCycles = function () {
    if ($scope.currUser.roleId === 4 || $scope.currUser.roleId === 5 || $scope.currUser.roleId === 3) {
      SalesCycles.get(function (sc) {
        $scope.scy = sc.salesCycles;
        $scope.dtCount = sc.count;
        $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage)+1;
        $scope.offset = 0;
      });
    } else {
      SalesCycles.get(function (sc) {
        $scope.scy = sc.salesCycles;
        $scope.dtCount = sc.count;
        $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage)+1;
        $scope.offset = 0;
      });
    }
  };

  $scope.currentPage = 1;
  $scope.prevDisable = true;
  // console.log($scope.currentPage);
  $scope.next = function(){
    $scope.currentPage  = $scope.currentPage + 1;
    if($scope.currentPage < $scope.numPages){
        // $scope.currentPage = $scope.numPages;
        $scope.nextDisable = false;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
        // console.log($scope.offset);
    } else if($scope.currentPage = $scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
    }else{
      $scope.nextDisable = false;
      $scope.prevDisable = false;
    }
    // console.log($scope.currentPage);
    // console.log($scope.numPages);
  }
  $scope.prev = function(){
    $scope.currentPage  = $scope.currentPage -1;
    if($scope.currentPage > 1){
        // $scope.currentPage = 1;
        $scope.nextDisable = false;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
        // console.log($scope.offset)
    } else if($scope.currentPage = 1){
        $scope.nextDisable = false;
        $scope.prevDisable = true;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
    }
  }
  $scope.itemByPageChange = function(){
    $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage)+1;
    if($scope.currentPage >=$scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = true;
    } else{
        $scope.nextDisable = false;
        $scope.prevDisable = false;
    }
  }
  $scope.currPageChange = function(){
    if($scope.currentPage >=$scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = false;
        $scope.currentPage = $scope.numPages;
    } else if($scope.currentPage <=1){
        $scope.prevDisable = true;
        $scope.nextDisable = false;
        $scope.currentPage = 1;
    } else{
        $scope.nextDisable = false;
        $scope.prevDisable = false;
    } 
    $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
  };

  $scope.getSalesCycles();
  $scope.modalTemplateUrl = 'app/salesCycles/salesCycles.modal.html';
  $scope.modalSize = 'm';
  //open modal for add Item
  $scope.add = function () {
    var modalInstance = $modal.open({
      templateUrl: $scope.modalTemplateUrl,
      controller: 'modalSalesCycles',
      size: $scope.modalSize,
      resolve: {
        mData: function () {
          return false;
        }
      }
    });
    modalInstance.result.then(function (res) {
      $scope.getSalesCycles();
    });
  };
  //open modal for edit Item
  $scope.edit = function (id) {
    var modalInstance = $modal.open({
      templateUrl: $scope.modalTemplateUrl,
      controller: 'modalSalesCycles',
      size: $scope.modalSize,
      resolve: {
        mData: function () {
          return { id: id };
        }
      }
    });
    modalInstance.result.then(function (res) {
      $scope.getSalesCycles();
    });
  };
  //open modal for add delete
  $scope.delete = function (id, name) {
    var modalInstance = $modal.open({
      templateUrl: 'app/app.modal.delete.html',
      controller: 'modalDelete',
      size: $scope.modalSize,
      resolve: {
        mData: function () {
          return {
            id: id,
            name: name
          };
        }
      }
    });
    modalInstance.result.then(function (res) {
      var salesCycle = SalesCycles.get();
      salesCycle.$delete({ id: res }, function (u) {
        toastr.success('Sales Cycle has been deleted', 'Sales Cycle');
        $scope.getSalesCycles();
      });
    });
  };
  $scope.selectedAll = false;
  $scope.checkAll = function(){
    // console.log('cek')
    $scope.selectedAll = !$scope.selectedAll;
    angular.forEach($scope.scy, function (item) {
      item.Selected = $scope.selectedAll;
    });
  };
  $scope.removeSelected = function(){
    angular.forEach($scope.scy,function (item){
      if(item.Selected){
        var i = SalesCycles.get();
        i.$delete({id:item.id});
      }
    })
    $scope.getSalesCycles();
  };
  $scope.itemsByPage = 10;
  $scope.thead = [
    {
      title: '#',
      width: 25,
      noClick:true,
      attr: 'checklist'
    },
    {
      title: 'Department',
      width: 75,
      align: 'center',
      attr: 'departementId'
    },
    {
      title: 'Status',
      width: 75,
      align: 'center',
      attr: 'statusId'
    },
    {
      title: 'Simple',
      width: 75,
      align: 'center',
      attr: 'simple'
    },
    {
      title: 'Medium',
      width: 75,
      align: 'center',
      attr: 'medium'
    },
    {
      title: 'Complex',
      width: 75,
      align: 'center',
      attr: 'complex'
    },
    {
      title: 'Actions',
      width: 30,
      align: 'center',
      attr: 'actions'
    }
  ];
  $scope.tableWidth = 0;
  angular.forEach($scope.thead, function (t) {
    $scope.tableWidth = $scope.tableWidth + t.width;
  });
});
