'use strict';
describe('Controller: SalesCyclesCtrl', function () {
  // load the controller's module
  beforeEach(module('smoApp'));
  var SalesCyclesCtrl, scope;
  // Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope) {
    scope = $rootScope.$new();
    SalesCyclesCtrl = $controller('SalesCyclesCtrl', { $scope: scope });
  }));
  it('should ...', function () {
    expect(1).toEqual(1);
  });
});