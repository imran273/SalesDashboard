'use strict';
angular.module('smoApp').config(function ($stateProvider) {
  $stateProvider.state('division', {
    url: '/division',
    templateUrl: 'app/division/division.html',
    controller: 'DivisionCtrl'
  });
});
angular.module('smoApp').controller('modalDivisions', function ($scope, $rootScope, $modalInstance, Divisions, toastr, mData) {
  $scope.input = {};
  if (mData.id) {
    $scope.title = 'Edit Divisions';
    Divisions.get({}, { id: mData.id }, function (u) {
      // console.log(u)
      $scope.input = u.divisions[0];
    });
  } else {
    $scope.title = 'Add Divisions'  //Begin Add Modal
;
  }
  $scope.ok = function () {
    $scope.errors = [];
    //input validation		
    if ($scope.input.name === angular.noop())
      $scope.errors.push({ text: 'Name is required' });
    if ($scope.errors.length === 0) {
      // console.log('save')
      $scope.errors = undefined;
      var division = Divisions.get();
      division.name = $scope.input.name;
      if (mData.id) {
        division.$update({ id: mData.id }, function (res) {
          //console.log(res)
          toastr.success($scope.input.name + ' has been updated!', 'Divisions');
          $modalInstance.close();
        });
      } else {
        division.$save(function (res) {
          // console.log(res)
          toastr.success($scope.input.name + ' has been added!', 'Divisions');
          $modalInstance.close();
        });
      }
    }
  };
  $scope.cancel = function () {
    $modalInstance.dismiss('cancel');
  };
});