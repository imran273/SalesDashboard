'use strict';
angular.module('smoApp').controller('DivisionCtrl', function ($scope, $rootScope, $cookies, $modal, Auth, Divisions, toastr, $location) {
  $location.path(Auth.isLogin() ? 'login' : 'division');
  $scope.page = {
    title: 'Divisions',
    desc: 'Divisions Management'
  };
  $scope.getDivisions = function () {
    Divisions.get(function (d) {
      $scope.dvs = d.divisions;
      $scope.dtCount = d.count;
      $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage)+1;
      $scope.offset = 0;
    });
  };

$scope.currentPage = 1;
  $scope.prevDisable = true;
  $scope.next = function(){
    $scope.currentPage  = $scope.currentPage + 1;
    if($scope.currentPage >= $scope.numPages){
        $scope.currentPage = $scope.numPages;
        $scope.nextDisable = true;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage
        console.log($scope.offset)
    } else{
        $scope.nextDisable = false;
        $scope.prevDisable = true;
    }
    
  }
  $scope.prev = function(){
    $scope.currentPage  = $scope.currentPage -1;
    if($scope.currentPage <= 1){
        $scope.currentPage = 1;
        $scope.nextDisable = false;
        $scope.prevDisable = true;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage
        console.log($scope.offset)
    } else{
        $scope.nextDisable = true;
        $scope.prevDisable = false;
    }
    
  }
  $scope.itemByPageChange = function(){
    $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage)+1;
    if($scope.currentPage >=$scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = true;
    } else if($scope.itemsByPage==undefined){
        $scope.offset = 0;
        $scope.currentPage = 1;
        $scope.numPages = 1;
    } else{
        $scope.nextDisable = false;
        $scope.prevDisable = false;
    }
  }
  $scope.currPageChange = function(){
    if($scope.currentPage >=$scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = false;
        $scope.currentPage = $scope.numPages;
    } else if($scope.currentPage <=1){
        $scope.prevDisable = true;
        $scope.nextDisable = false;
        $scope.currentPage = 1;
    } else{
        $scope.nextDisable = false;
        $scope.prevDisable = false;
    } 
    $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage
  }

  $scope.getDivisions();
  $scope.modalTemplateUrl = 'app/division/division.modal.html';
  $scope.modalSize = 'm';
  //open modal for add item
  $scope.add = function () {
    var modalInstance = $modal.open({
      templateUrl: $scope.modalTemplateUrl,
      controller: 'modalDivisions',
      size: $scope.modalSize,
      windowClass: 'devid-modal',
      resolve: {
        mData: function () {
          return false;
        }
      }
    });
    modalInstance.result.then(function (res) {
      $scope.getDivisions();
    });
  };
  //open modal for edit Item
  $scope.edit = function (id) {
    var modalInstance = $modal.open({
      templateUrl: $scope.modalTemplateUrl,
      controller: 'modalDivisions',
      size: $scope.modalSize,
      resolve: {
        mData: function () {
          return { id: id };
        }
      }
    });
    modalInstance.result.then(function (res) {
      $scope.getDivisions();
    });
  };
  //open modal for add delete
  $scope.delete = function (id, name) {
    var modalInstance = $modal.open({
      templateUrl: 'app/app.modal.delete.html',
      controller: 'modalDelete',
      size: $scope.modalSize,
      resolve: {
        mData: function () {
          return {
            id: id,
            name: name
          };
        }
      }
    });
    modalInstance.result.then(function (res) {
      var division = Divisions.get();
      division.$delete({ id: res }, function (u) {
        toastr.success('Division has been deleted', 'Divisions');
        $scope.getDivisions();
      });
    });
  };
  $scope.selectedAll = false;
  $scope.checkAll = function(){
    // console.log('cek')
    $scope.selectedAll = !$scope.selectedAll;
    angular.forEach($scope.dvs, function (item) {
      item.Selected = $scope.selectedAll;
    });
  };
  $scope.removeSelected = function(){
    angular.forEach($scope.dvs,function (item){
      if(item.Selected){
        var i = Divisions.get();
        i.$delete({id:item.id});
      }
    })
    $scope.getDivisions();
  };
  $scope.itemsByPage = 10;
  $scope.thead = [
    {
      title: '#',
      width: 25,
      noClick:true,
      attr: 'checklist'
    },{
      title: 'Name',
      width: 200,
      align: 'left',
      attr: 'name'
    },
    {
      title: 'Last Update',
      width: 100,
      align: 'left',
      attr: 'updatedAt'
    },
    {
      title: 'Actions',
      width: 80,
      align: 'right',
      attr: 'actions'
    }
  ];
});