'use strict';

describe('Controller: BucCtrl', function () {

  // load the controller's module
  beforeEach(module('smoApp'));

  var BucCtrl, scope;

  // Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope) {
    scope = $rootScope.$new();
    BucCtrl = $controller('BucCtrl', {
      $scope: scope
    });
  }));

  it('should ...', function () {
    expect(1).toEqual(1);
  });
});
