'use strict';

angular.module('smoApp')
  .config(function ($stateProvider) {
    $stateProvider
      .state('buc', {
        url: '/buc',
        templateUrl: 'app/buc/buc.html',
        controller: 'BucCtrl'
      });
  });