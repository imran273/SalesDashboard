'use strict';

angular.module('smoApp')
  .controller('IndustrialSectorsCtrl', function ($scope, $rootScope, $cookies, $http, $modal, Auth, industrialSectors, $location, toastr) {
  $location.path(Auth.isLogin() ? 'login' : 'industrialSectors');
  $scope.page = {
    title: 'Industrial Sectors',
    desc: 'Industrial Sectors Management'
  };
  // $scope.currUser = $cookies.getObject('currentUser');

  $scope.getIndustrialSectors = function () {
    // if ($scope.currUser.roleId === 4 || $scope.currUser.roleId === 5 || $scope.currUser.roleId === 3) {
    //   Industrial Sectors.get(function (s) {
    //     $scope.sectors = s.products;
    //     $scope.dtCount = s.count;
    //     $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage)+1;
    //     $scope.offset = 0;
    //   });
    // } else {
    //   Industrial Sectors.get(function (s) {
    //     $scope.sectors = s.products;
    //     $scope.dtCount = s.count;
    //     $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage);
    //     $scope.offset = 0;
    //   });
    // }
    industrialSectors.get(function (s) {
    	console.log(s)
        $scope.sectors = s.industrialSectors;
        $scope.dtCount = s.count;
        $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage)+1;
        $scope.offset = 0;
      });
  };

  $scope.currentPage = 1;
  $scope.prevDisable = true;
  // console.log($scope.currentPage);
  $scope.next = function(){
    $scope.currentPage  = $scope.currentPage + 1;
    if($scope.currentPage < $scope.numPages){
        // $scope.currentPage = $scope.numPages;
        $scope.nextDisable = false;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
        // console.log($scope.offset);
    } else if($scope.currentPage = $scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
    }else{
      $scope.nextDisable = false;
      $scope.prevDisable = false;
    }
    // console.log($scope.currentPage);
    // console.log($scope.numPages);
  }
  $scope.prev = function(){
    $scope.currentPage  = $scope.currentPage -1;
    if($scope.currentPage > 1){
        // $scope.currentPage = 1;
        $scope.nextDisable = false;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
        // console.log($scope.offset)
    } else if($scope.currentPage = 1){
        $scope.nextDisable = false;
        $scope.prevDisable = true;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
    }
  }
  $scope.itemByPageChange = function(){
    $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage)+1;
    if($scope.currentPage >=$scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = true;
    } else{
        $scope.nextDisable = false;
        $scope.prevDisable = false;
    }
  }
  $scope.currPageChange = function(){
    if($scope.currentPage >=$scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = false;
        $scope.currentPage = $scope.numPages;
    } else if($scope.currentPage <=1){
        $scope.prevDisable = true;
        $scope.nextDisable = false;
        $scope.currentPage = 1;
    } else{
        $scope.nextDisable = false;
        $scope.prevDisable = false;
    } 
    $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
  };
// 
  $scope.getIndustrialSectors();
  $scope.modalTemplateUrl = 'app/IndustrialSectors/IndustrialSectors.modal.html';
  $scope.modalSize = 'm';
  //open modal for add item
  $scope.add = function () {
    var modalInstance = $modal.open({
      templateUrl: $scope.modalTemplateUrl,
      controller: 'modalIndustrialSectors',
      size: $scope.modalSize,
      // windowClass:'devid-modal',
      resolve: {
        mData: function () {
          return false;
        }
      }
    });
    modalInstance.result.then(function (res) {
      $scope.getIndustrialSectors();
    });
  };
  //open modal for edit Item
  $scope.edit = function (id) {
    var modalInstance = $modal.open({
      templateUrl: $scope.modalTemplateUrl,
      controller: 'modalIndustrialSectors',
      size: $scope.modalSize,
      resolve: {
        mData: function () {
          return { id: id };
        }
      }
    });
    modalInstance.result.then(function (res) {
      $scope.getIndustrialSectors();
    });
  };
  //open modal for add delete
  $scope.delete = function (id, name) {
    var modalInstance = $modal.open({
      templateUrl: 'app/app.modal.delete.html',
      controller: 'modalDelete',
      size: $scope.modalSize,
      resolve: {
        mData: function () {
          return {
            id: id,
            name: name
          };
        }
      }
    });
    modalInstance.result.then(function (res) {
      var IndustrialSectors = industrialSectors.get();
      IndustrialSectors.$delete({ id: res }, function (u) {
        toastr.success('Industrial Sectors has been deleted', 'Industrial Sectors');
        $scope.getIndustrialSectors();
      });
    });
  };
  $scope.selectedAll = false;
  $scope.checkAll = function(){
    // console.log('cek')
    $scope.selectedAll = !$scope.selectedAll;
    angular.forEach($scope.sectors, function (item) {
      item.Selected = $scope.selectedAll;
    });
  };
  $scope.removeSelected = function(){
    angular.forEach($scope.sectors,function (item){
      if(item.Selected){
        var i = industrialSectors.get();
        i.$delete({id:item.id});
      }
    })
    $scope.getIndustrialSectors();
  };
  $scope.itemsByPage = 10;
  $scope.thead = [
    {
      title: '#',
      width: 25,
      noClick:true,
      align: 'center',
      attr: 'checklist'
    },
    {
      title: 'Name',
      width: 800,
      align: 'center',
      attr: 'name'
    },
    {
      title: 'Actions',
      width: 100,
      align: 'center',
      attr: 'actions'
    }
  ];
  $scope.tableWidth = 0;
  angular.forEach($scope.thead, function (t) {
    $scope.tableWidth = $scope.tableWidth + t.width;
  });
});
