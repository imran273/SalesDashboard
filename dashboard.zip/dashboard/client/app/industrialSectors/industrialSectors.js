'use strict';

angular.module('smoApp')
  .config(function ($stateProvider) {
    $stateProvider
      .state('industrialSectors', {
        url: '/industrialSectors',
        templateUrl: 'app/industrialSectors/industrialSectors.html',
        controller: 'IndustrialSectorsCtrl'
      });
  });