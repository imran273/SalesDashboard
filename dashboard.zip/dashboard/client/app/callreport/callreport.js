'use strict';
angular.module('smoApp').config(function ($stateProvider) {
  $stateProvider.state('callreport', {
    url: '/callreport',
    templateUrl: 'app/callreport/callreport.html',
    controller: 'CallReportsCtrl'
  });
  $stateProvider.state('createreport', {
    url: '/createreport/:id/:method',
    templateUrl: 'app/callreport/createreport.html',
    controller: 'CreateReportCtrl'
  });
});
angular.module('smoApp').controller('modalCallReports', function ($scope, $rootScope, $modalInstance, CallReports, toastr, mData) {
  $scope.input = {};
  if (mData.id) {
    $scope.title = 'Edit Reports';
    CallReports.get({}, { id: mData.id }, function (u) {
      // // console.log(u)
      $scope.input = u.CallReports[0];
    });
  } else {
    $scope.title = 'Add Reports'  //Begin Add Modal
    ;
  }
  $scope.open1 = function ($event) {
    $event.preventDefault();
    $event.stopPropagation();
    $scope.opened1 = true;
  };
  $scope.ok = function () {
    $scope.errors = [];
    //input validation		
    if ($scope.input.actionPlan === angular.noop())
      $scope.errors.push({ text: 'Action Plan is required' });
    if ($scope.input.activity === angular.noop())
      $scope.errors.push({ text: 'Activity is required' });
    if ($scope.input.date === angular.noop())
      $scope.errors.push({ text: 'Date is required' });
    if ($scope.input.pipeline === angular.noop())
      $scope.errors.push({ text: 'Pipeline is required' });
    if ($scope.input.realization === angular.noop())
      $scope.errors.push({ text: 'Realization is required' });
    if ($scope.input.status === angular.noop())
      $scope.errors.push({ text: 'Status is required' });
    if ($scope.errors.length === 0) {
      // // console.log('save')
      $scope.errors = undefined;
      var report = CallReports.get();
      report.actionPlan = $scope.input.actionPlan;
      report.activity = $scope.input.activity;
      report.date = $scope.input.date;
      report.pipeline = $scope.input.pipeline;
      report.realization = $scope.input.realization;
      report.status = $scope.input.status;
      if (mData.id) {
        report.$update({ id: mData.id }, function (res) {
          //// console.log(res)
          toastr.success($scope.input.name + ' has been updated!', 'CallReports');
          $modalInstance.close();
        });
      } else {
        report.$save(function (res) {
          // // console.log(res)
          toastr.success($scope.input.name + ' has been added!', 'CallReports');
          $modalInstance.close();
        });
      }
    }
  };
  $scope.cancel = function () {
    $modalInstance.dismiss('cancel');
  };
});

angular.module('smoApp').controller('CreateReportCtrl', function ($scope, $rootScope,$cookies, $stateParams,CallReports,$location, Pipelines,Clients,ClientPIC, Realizations,Sales, Schedules,ReportActions,ReportPartners, toastr) {
  if($stateParams.id===undefined || $stateParams.id==='' || $stateParams.method===undefined || $stateParams.method===''){
    $location.path('callreport');
  }
  $scope.currUser = $cookies.getObject('currentUser');
  $scope.bankingPartners = [];
  $scope.actionPlans = [];
  $scope.today = moment().format('YYYY-MM-DD HH:mm:ss');
  $scope.input = {}
  $scope.input.kunjunganKe = 1;

  $scope.removeBank = function(id){
    $scope.bankingPartners.splice(id,1);
  };
  $scope.removeAP = function(id){
    $scope.actionPlans.splice(id,1);
  };
  $scope.addBank = function(){
    $scope.bankingPartners.push({name:'',description:''});
  };
  $scope.addAP = function(){
    $scope.actionPlans.push({activity:'',pic:'',dateTarget:''});
  };
  $scope.getRealisasi = function(id){
    Realizations.getJoinById({id:id},function(r){
      // console.log(r.realizations[0])
      $scope.kunjungan = r.realizations[0]
      $scope.input.mandiri = $scope.kunjungan.teamMandiri;
      $scope.input.nasabah = $scope.kunjungan.teamClient;
      $scope.getSchedule($scope.kunjungan.scheduleId)
    })
  }
  $scope.getRealisasi($stateParams.id);
  $scope.getSchedule = function(id){
    Schedules.get({id:id},function(s){
      $scope.schedule = s.schedules
      // console.log($scope.schedule)
      $scope.getPipeline($scope.schedule.offeringId)
      
    })
  }
  $scope.getPipeline = function(id){
    Pipelines.getFull({},{id:id},function(p){
      $scope.pipeline = p.offerings[0]
      // console.log($scope.pipeline)
      $scope.input.namaPerusahaan = $scope.pipeline.client.name;
      $scope.input.alamat = $scope.pipeline.client.address;
      $scope.input.product = $scope.pipeline.product.name;
      $scope.input.clientType = $scope.pipeline.offeringType;
      $scope.getPIC($scope.pipeline.client.id)
    })
  }
  $scope.getPIC = function(id){
    ClientPIC.getByClientId({},{clientId:id},function(pic){
      $scope.pics = pic.clientPics
      // console.log($scope.pics)
    })
  }
  $scope.getSales = function(){
    Sales.getJoinBySalesId({},{salesId:$scope.currUser.salesId},function(s){
      // console.log(s.sales)
      $scope.sales = s.sales[0]
    })
  }
  $scope.getSales();
  if($stateParams.method==='e'){
    $scope.inputDisabled = true;
    CallReports.getByRealisasiId({},{id:$stateParams.id},function(r){

      $scope.input = r.reports[0]

      // console.log($scope.input)
      if(r.reports[0].ReportPartners.length>0){
        $scope.bankingPartners = r.reports[0].ReportPartners
      }
      if(r.reports[0].ReportActions.length>0){
        $scope.actionPlans = r.reports[0].ReportActions
      }
    })
  }
  $scope.submit = function(){
    var r = CallReports.get();
    r.product= $scope.input.product;
    r.date= $scope.today;
    r.description= $scope.input.description || ' ';
    r.clientType = $scope.input.clientType;
    r.flagKI= $scope.input.flagKI || false;
    r.flagKMK= $scope.input.flagKMK|| false;
    r.flagTR= $scope.input.flagTR|| false;
    r.flagGiro= $scope.input.flagGiro|| false;
    r.flagTBM= $scope.input.flagTBM|| false;
    r.flagDepo= $scope.input.flagDepo|| false;
    r.flagMCM= $scope.input.flagMCM|| false;
    r.flagMGT= $scope.input.flagMGT|| false;
    r.flagETAX= $scope.input.flagETAX|| false;
    r.flagERTE= $scope.input.flagERTE|| false;
    r.flagEDC= $scope.input.flagEDC|| false;
    r.flagPayroll= $scope.input.flagPayroll|| false;
    r.flagDF= $scope.input.flagDF|| false;
    r.flagSCF= $scope.input.flagSCF|| false;
    r.flagNationalPooling= $scope.input.flagNationalPooling|| false;
    r.flagH2H= $scope.input.flagH2H|| false;
    r.flagCashPickUp= $scope.input.flagCashPickUp|| false;
    r.flagMVA= $scope.input.flagMVA|| false;
    r.flagBillAgregator= $scope.input.flagBillAgregator|| false;
    r.flagBillPayment= $scope.input.flagBillPayment|| false;
    r.flagAutoDebet= $scope.input.flagAutoDebet|| false;
    r.flagForfeiting= $scope.input.flagForfeiting|| false;
    r.flagLCSKBDN= $scope.input.flagLCSKBDN|| false;
    r.flagBankGuarante= $scope.input.flagBankGuarante|| false;
    r.flagDistributorCard= $scope.input.flagDistributorCard|| false;
    r.flagARFinancing= $scope.input.flagARFinancing|| false;
    r.flagMPos= $scope.input.flagMPos|| false;
    r.flagZBA= $scope.input.flagZBA|| false;
    r.flagGiroPengurus= $scope.input.flagGiroPengurus|| false;
    r.flagDeptPengurus= $scope.input.flagDeptPengurus|| false;
    r.flagTabPengurus= $scope.input.flagTabPengurus|| false;
    r.flagCreditCard= $scope.input.flagCreditCard|| false;
    r.flagKTA= $scope.input.flagKTA|| false;
    r.flagKendaraanMandiri= $scope.input.flagKendaraanMandiri|| false;
    r.flagKreditMitraKarya= $scope.input.flagKreditMitraKarya|| false;
    r.flagAXAMandiri= $scope.input.flaAXAMandiri|| false;
    r.flagPrepaidCard= $scope.input.flagPrepaidCard|| false;
    r.flagOthers= $scope.input.flagOthers|| false;
    r.realizationId= $stateParams.id;
    r.offeringId= $scope.pipeline.id;
    r.statusId= $scope.pipeline.statusId;
    r.salesId= $scope.currUser.salesId;
    r.attendee = $scope.input.attendee || 'none';
    r.venue = $scope.input.venue || ' ';
    r.annualSales = $scope.input.annualSales;
    if($stateParams.method==='a'){
      r.$save(function(report){
        $scope.reportId = report.reports[0].id;
        if($scope.bankingPartners.length>0){
          angular.forEach($scope.bankingPartners,function(b){
            var rp = ReportPartners.get();
            rp.name = b.name;
            rp.description = b.description || ' ';
            rp.reportId  = $scope.reportId;
            rp.$save();
          })
        }
        if($scope.actionPlans.length>0){
          angular.forEach($scope.actionPlans,function(a){
            var ap = ReportActions.get();
            ap.activity = a.activity;
            ap.pic = a.pic;
            ap.dateTarget = a.dateTarget || moment().format('YYYY-MM-DD HH:mm:ss');
            ap.reportId = $scope.reportId;
            ap.$save();
          })
        }
        $location.path('callreport')
      })
    } else{
      r.$update({id:$scope.input.id},function(report){
        $scope.reportId = $scope.input.id;
        if($scope.bankingPartners.length>0){
          angular.forEach($scope.bankingPartners,function(b){
            var rp = ReportPartners.get();
            rp.name = b.name;
            rp.description = b.description || ' ';
            rp.reportId  = $scope.reportId;
            if(b.id){
              rp.$update({id:b.id});
            } else {
              rp.$save();
            }
          })
        }
        if($scope.actionPlans.length>0){
          angular.forEach($scope.actionPlans,function(a){
            var ap = ReportActions.get();
            ap.activity = a.activity;
            ap.pic = a.pic;
            ap.dateTarget = a.dateTarget || moment().format('YYYY-MM-DD HH:mm:ss');
            ap.reportId = $scope.reportId;
            if(a.id){
              ap.$update({id:a.id});  
            } else{
              ap.$save();  
            }
          })
        }
        $location.path('callreport')
      })
}
}
});