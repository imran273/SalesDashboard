'use strict';
angular.module('smoApp').controller('CallReportsCtrl', function ($scope, $state,$rootScope, $cookies, Auth, $location, CallReports, Realizations,$modal,$filter, toastr) {
  $location.path(Auth.isLogin() ? 'login' : 'callreport');
  $scope.page = {
    title: 'Call Reports',
    desc: 'Call Reports Management'
  };
  $scope.currUser = $cookies.getObject('currentUser');
  $scope.startDate = moment().day(-2).startOf('d').format('YYYY-MM-DD HH:mm:ss');
  $scope.endDate = moment().day(4).endOf('d').format('YYYY-MM-DD HH:mm:ss');
  $scope.lastWeek = $scope.startDate +" to "+$scope.endDate;
  $scope.getLastWeekRealization = function(){
    Realizations.getLastWeekBySales({},{salesId:$scope.currUser.salesId,
      start:$scope.startDate,
      end:$scope.endDate},function(r){
      //console.log(r)
      $scope.realizations = r.realizations;
    })
  }
  $scope.getLastWeekRealization();
  $scope.getCallReports = function () {
    CallReports.getFullJoinBySalesId({},{salesId:$scope.currUser.salesId},function (report) {
      $scope.reports = report.reports;  
      //console.log($scope.reports);
      $scope.dtCount = report.count;
      $scope.numPages = parseInt($scope.dtCount / $scope.itemsByPage)+1;
      $scope.offset = 0;
    });
  };

  $scope.currentPage = 1;
  $scope.prevDisable = true;
  // console.log($scope.currentPage);
  $scope.next = function(){
    $scope.currentPage  = $scope.currentPage + 1;
    if($scope.currentPage < $scope.numPages){
        // $scope.currentPage = $scope.numPages;
        $scope.nextDisable = false;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
        // console.log($scope.offset);
    } else if($scope.currentPage = $scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
    }else{
      $scope.nextDisable = false;
      $scope.prevDisable = false;
    }
    // console.log($scope.currentPage);
    // console.log($scope.numPages);
  }
  $scope.prev = function(){
    $scope.currentPage  = $scope.currentPage -1;
    if($scope.currentPage > 1){
        // $scope.currentPage = 1;
        $scope.nextDisable = false;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
        // console.log($scope.offset)
    } else if($scope.currentPage = 1){
        $scope.nextDisable = false;
        $scope.prevDisable = true;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
    }
  }
  $scope.itemByPageChange = function(){
    $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage)+1;
    if($scope.currentPage >=$scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = true;
    } else{
        $scope.nextDisable = false;
        $scope.prevDisable = false;
    }
  }
  $scope.currPageChange = function(){
    if($scope.currentPage >=$scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = false;
        $scope.currentPage = $scope.numPages;
    } else if($scope.currentPage <=1){
        $scope.prevDisable = true;
        $scope.nextDisable = false;
        $scope.currentPage = 1;
    } else{
        $scope.nextDisable = false;
        $scope.prevDisable = false;
    } 
    $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
  };
  $scope.getCallReports();
  $scope.modalTemplateUrl = 'app/callreport/callreport.modal.html';
  $scope.modalSize = 'm';
  //open modal for add Item
  
  $scope.add = function (id) {
    $state.transitionTo('createreport',{id:id,method:'a'})
    // var modalInstance = $modal.open({
    //   templateUrl: $scope.modalTemplateUrl,
    //   controller: 'modalCallReports',
    //   size: 'lg',
    //   // windowClass:'devid-modal',
    //   resolve: {
    //     mData: function () {
    //       return {realizationId:id};
    //     }
    //   }
    // });
    // modalInstance.result.then(function (res) {
    //   $scope.getCallReports();
    // });
  };
  //open modal for edit Item
  $scope.edit = function (id) {
    $state.transitionTo('createreport',{id:id,method:'e'})
    // var modalInstance = $modal.open({
    //   templateUrl: $scope.modalTemplateUrl,
    //   controller: 'modalCallReports',
    //   size: $scope.modalSize,
    //   resolve: {
    //     mData: function () {
    //       return { id: id };
    //     }
    //   }
    // });
    // modalInstance.result.then(function (res) {
    //   $scope.getCallReports();
    // });
  };
  //open modal for add delete
  $scope.delete = function (id, name) {
    var modalInstance = $modal.open({
      templateUrl: 'app/app.modal.delete.html',
      controller: 'modalDelete',
      size: $scope.modalSize,
      resolve: {
        mData: function () {
          return {
            id: id,
            name: name
          };
        }
      }
    });
    modalInstance.result.then(function (res) {
      //action when delete
      var report = CallReports.get();
      report.$delete({ id: res }, function (u) {
        toastr.success('Reports has been deleted', 'Reports');
        $scope.getCallReports();
        $scope.getLastWeekRealization();
      });
    });
  };
  $scope.itemsByPage = 10;
  $scope.thead = [
    {
      title: 'Action Plan',
      width: 200,
      align: 'left',
      attr: 'actionPlan'
    },
    {
      title: 'Activity',
      width: 200,
      align: 'left',
      attr: 'activity'
    },
    {
      title: 'Date',
      width: 200,
      align: 'center',
      attr: 'date'
    },
    {
      title: 'Pipeline',
      width: 100,
      align: 'left',
      attr: 'offeringId'
    },
    {
      title: 'Realization',
      width: 200,
      align: 'center',
      attr: 'realizationId'
    },
    {
      title: 'Status',
      width: 100,
      align: 'center',
      attr: 'statusId'
    },
    {
      title: 'Last Update',
      width: 100,
      align: 'left',
      attr: 'updatedAt'
    },
    {
      title: 'Actions',
      width: 80,
      align: 'right',
      attr: 'actions'
    }
  ];
  $scope.tableWidth = 0;
  angular.forEach($scope.thead, function (t) {
    $scope.tableWidth = $scope.tableWidth + t.width;
  });
});