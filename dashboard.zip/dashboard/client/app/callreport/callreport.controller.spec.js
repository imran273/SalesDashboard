'use strict';
describe('Controller: CallreportCtrl', function () {
  // load the controller's module
  beforeEach(module('smoApp'));
  var CallreportCtrl, scope;
  // Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope) {
    scope = $rootScope.$new();
    CallreportCtrl = $controller('CallreportCtrl', { $scope: scope });
  }));
  it('should ...', function () {
    expect(1).toEqual(1);
  });
});