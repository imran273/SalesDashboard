'use strict';
angular.module('smoApp').controller('SchedulesCtrl', function ($scope, $rootScope, $cookies, Auth, $timeout, Schedules, Pipelines, Users, $modal, $location, toastr, Status) {
  $location.path(Auth.isLogin() ? 'login' : 'schedules');
  $scope.page = {
    title: 'Appointment',
    desc: 'Planning Appointment'
  };
  Status.get(function (s) {
    // console.log(s)
    $scope.salesCycles = s.status;
  });
  $scope.currUser = $cookies.getObject('currentUser');
  $scope.pipelineDisable = true;
  $scope.salesCycleChange = function () {
    if ($scope.input.salesCycleId) {
      Pipelines.getByStatusId({}, {
        statusId: $scope.input.salesCycleId,
        deptId: $scope.currUser.departementId,
        salesId: $scope.currUser.salesId
      }, function (p) {
        if (p.offerings.length > 0) {
          $scope.pipelineDisable = false;
          $scope.pipelines = p.offerings;
        } else {
          $scope.pipelineDisable = true;
          $scope.pipelines = [{
            id: '',
            cif:'',
            Client:{
              name: 'No pipelines found'
            },
            Product:{
              category:$scope.input.salesCycleId
            }
          }];
          $scope.input.pipelineId = '';
          // console.log('not found')
        }

      },function(){
       toastr.error('Cannot get pipelines!','GET Pipelines')
     });
    }
  };
  $scope.findColor = function (id) {
    if (id == 1) {
      $scope.color = '4CAF50';
    } else if (id == 2) {
      $scope.color = '8BC34A';
    } else if (id == 3) {
      $scope.color = 'CDDC39';
    } else if (id == 4) {
      $scope.color = 'FFEB3B';
    } else if (id == 5) {
      $scope.color = 'FFC107';
    } else if (id == 6) {
      $scope.color = 'FF9800';
    } else if (id == 7) {
      $scope.color = 'F44336';
    } else if (id == 8) {
      $scope.color = 'E91E63';
    } else if (id == 9) {
      $scope.color = '9C27B0';
    } else {
      $scope.color = '3F51B5';
    }
    return $scope.color;
  };
  $scope.events = [];
  $scope.getEvents = function () {
    $('#calendar').fullCalendar('refetchEvents');
    Schedules.getBySalesId({},{salesId:$scope.currUser.salesId},function (s) {
      
      angular.forEach(s.schedules, function (sc) {
        // console.log(sc.startDate);
        $scope.events.push({
          title: sc.plan,
          start: moment(sc.startDate).format('YYYY-MM-DD HH:mm:ss'),
          end: moment(sc.endDate).format('YYYY-MM-DD HH:mm:ss'),
          // color:$scope.findColor(sc.offeringId),
          editable:(moment(moment(sc.startDate).format('YYYY-MM-DD')).isBefore(moment().format('YYYY-MM-DD')))? false:true,
          color: '#' + sc.color,
          textColor: 'white',
          allDay:false,         
          data: sc
        });
      });
    });
  };
  $scope.getEvents();
  $scope.modalTemplateUrl = 'app/schedules/schedules.modal.html';
  $scope.modalSize = 'm';
  $scope.input = {};
  $scope.dragSchedule = [];
  $scope.dropSchedule = [];
  $scope.input.startTime = '09:00'
  $scope.input.endTime = '17:00';
  $scope.submit = function (isValid) {
    if (isValid) {
      // console.log($scope.input);
      var startTime = $scope.input.startTime.split(":");
      var endTime = $scope.input.endTime.split(":");
      $scope.dragSchedule.push({
        title: $scope.input.plan,
        location: 'unknown',
        pic: $scope.input.pic,
        teamMandiri: $scope.input.teamMandiri,
        teamClient: $scope.input.teamClient,
        offeringId: $scope.input.pipelineId,
        description: $scope.input.description,
        start: moment().set('h',startTime[0]).set('m',startTime[1]).set('s',0).format('YYYY-MM-DD HH:mm:ss'),
        end: moment().set('h',endTime[0]).set('m',endTime[1]).set('s',0).format('YYYY-MM-DD HH:mm:ss'),
        color: $scope.findColor($scope.input.salesCycleId),

        textColor: 'white'
      });
    }
  };
  $scope.newPipeline = function(){
   var modalInstance = $modal.open({
    templateUrl: 'app/pipelines/pipelines.modal.html',
    controller: 'modalPipelines',
    size: $scope.modalSize,
    resolve: {
      mData: function () {
        return false;
      }
    }
  });
   modalInstance.result.then(function (res) {
      // $scope.getPipelines();
    });
 };
 $scope.newCustomer = function(){
  var modalInstance = $modal.open({
    templateUrl: 'app/clients/clients.modal.html',
    controller: 'modalClients',
    size: $scope.modalSize,
      // windowClass:'devid-modal',
      resolve: {
        mData: function () {
          return false;
        }
      }
    });
  modalInstance.result.then(function (res) {
      // $scope.getClients();
    });
};
$scope.schedule = {};
$scope.startCallback = function (event, ui, draggedData) {
  $scope.schedule = draggedData;
    // console.log(draggedData);
  };
  $scope.dropCallback = function (event, ui) {
  };
  $scope.dayClick = function (date, jsEvent, view) {
    if(moment(date).isBefore(moment())){
      toastr.error('Schedule date must be next 7 days','Schedule');
    } else {
      var modalInstance = $modal.open({
        templateUrl: $scope.modalTemplateUrl,
        controller: 'modalSchedules',
        size: $scope.modalSize,
        resolve: {
          mData: function () {
            return { sdate: date };
          }
        }
      });
      modalInstance.result.then(function () {
        $scope.getEvents();
      });
    }
  };
  $scope.drop = function (date, allDay) {
    // retrieve the dropped element's stored Event Object
    var originalEventObject = $(this).data('eventObject');
    // console.log(originalEventObject)
    // we need to copy it, so that multiple events don't have a reference to the same object
    var copiedEventObject = $.extend({}, originalEventObject);
    // assign it the date that was reported
    copiedEventObject.start = date;
    copiedEventObject.allDay = allDay;
    var dropDate = copiedEventObject.start;
    // $scope.sch = $scope.schedule;
    // $scope.sch.start = dropDate;
    // $scope.events.push($scope.sch);
    if(moment(dropDate).isBefore(moment())){
      toastr.error('Schedule date must be next 7 days','Schedule Not Saved');
    } else {
      var sch = Schedules.get();
      sch.plan = $scope.schedule.title;
      sch.pic = $scope.schedule.pic || 'Tidak diisi';
      sch.location = $scope.schedule.location || 'Tidak diisi';
      sch.teamMandiri = $scope.schedule.teamMandiri || 'Tidak diisi';
      sch.teamClient = $scope.schedule.teamClient || 'Tidak diisi';
      sch.offeringId = $scope.schedule.offeringId;
      sch.description = $scope.schedule.description;
      sch.color = $scope.schedule.color;
      sch.salesId = $scope.currUser.salesId;
      sch.startDate = moment($scope.schedule.start).set('year',moment(dropDate).get('year')).set('month',moment(dropDate).get('month')).set('date',moment(dropDate).get('date')).format('YYYY-MM-DD HH:mm:ss');
      sch.endDate = moment($scope.schedule.end).set('year',moment(dropDate).get('year')).set('month',moment(dropDate).get('month')).set('date',moment(dropDate).get('date')).format('YYYY-MM-DD HH:mm:ss');
      $scope.schedule.start = moment($scope.schedule.start).set('year',moment(dropDate).get('year')).set('month',moment(dropDate).get('month')).set('date',moment(dropDate).get('date')).format('YYYY-MM-DD HH:mm:ss');
      $scope.events.push($scope.schedule);
      // console.log(sch)
      sch.$save(function () {
        $scope.getEvents();
      });  
    }
    
  };
  $scope.eventDrop = function(event, delta, revertFunc) {
    // console.log(event.start)
    var s = Schedules.get();
    s.startDate = moment(event.start).set('h',moment(event.data.startDate).get('hour')).set('m',moment(event.data.startDate).get('minute')).set('s',0).format('YYYY-MM-DD HH:mm:ss');
    s.endDate = moment(event.start).set('h',moment(event.data.endDate).get('hour')).set('m',moment(event.data.endDate).get('minute')).set('s',0).format('YYYY-MM-DD HH:mm:ss');
    s.$update({id:event.data.id},function(){
      $scope.getEvents();
    })
  }
  $scope.eventClick = function (event, jsEvent, view) {
    // console.log(event);
    var modalInstance = $modal.open({
      templateUrl: $scope.modalTemplateUrl,
      controller: 'modalSchedules',
      size: $scope.modalSize,
      resolve: {
        mData: function () {
          return { sc: event.data };
        }
      }
    });
    modalInstance.result.then(function () {
      $scope.getEvents();
    });
  };
  $scope.uiConfig = {
    calendar: {
      height: 450,
      editable: false,
      header: {
        left: 'month,agendaDay',
        center: '',
        right: 'today prev,next'
      },
      timeFormat: 'HH:mm',
      dayClick: $scope.dayClick,
      droppable: true,
      // this allows things to be dropped onto the calendar !!!
      dropAccept: 'div.external-event',
      drop: $scope.drop,
      eventClick: $scope.eventClick,
      eventDrop:$scope.eventDrop
    }
  };

  $scope.eventSources = [$scope.events];
});