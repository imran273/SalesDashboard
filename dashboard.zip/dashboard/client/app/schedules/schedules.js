'use strict';
angular.module('smoApp').config(function ($stateProvider) {
  $stateProvider.state('schedules', {
    url: '/schedules',
    templateUrl: 'app/schedules/schedules.html',
    controller: 'SchedulesCtrl'
  });
});
angular.module('smoApp').controller('modalSchedules', function ($scope, $rootScope, $cookies, $modal,Clients, Pipelines,$modalInstance, Schedules, toastr, mData) {
  $scope.input = {};
   $scope.currUser = $cookies.getObject('currentUser');
  if (mData.sc) {
    $scope.title = 'Edit Schedule';
    $scope.input = mData.sc;
    $scope.input.startTime = moment(mData.sc.startDate).format('HH:mm')
    $scope.input.endTime = moment(mData.sc.endDate).format('HH:mm')
    // console.log($scope.input)
  } else {
    $scope.title = 'Add schedule';
    $scope.isNew = true;
    $scope.input.startDate = mData.sdate;
    $scope.input.startTime = moment(mData.sdate).set('h','09').set('m','00').format('HH:mm');
    $scope.input.endTime = moment(mData.sdate).set('h','17').set('m','00').format('HH:mm');

  }
  Clients.getCustomer(function (c) {
    $scope.customers = c.clients;
  });
  $scope.pipelineDisable = true;
  $scope.customerChange = function () {
    console.log($scope.input.custname)
    if ($scope.input.custname.id) {
      Pipelines.getByClientId({}, {
        clientId: $scope.input.custname.id
      }, function (p) {
        if (p.offerings.length > 0) {
          $scope.pipelineDisable = false;
          $scope.pipelines = p.offerings;
        } else {
          $scope.pipelineDisable = true;
          $scope.pipelines = [{
              id: '',
              Client:{
                name: 'No pipelines found'
              },
              Product:{
                name: 'No pipelines found',
                category:0
              }
            }];
          $scope.input.pipelineId = '';
          // console.log('not found')
        }

      },function(){
         toastr.error('Cannot get pipelines!','GET Pipelines')
      });
    }
  };
  $scope.findColor = function (id) {
    if (id == 1) {
      $scope.color = '4CAF50';
    } else if (id == 2) {
      $scope.color = '8BC34A';
    } else if (id == 3) {
      $scope.color = 'CDDC39';
    } else if (id == 4) {
      $scope.color = 'FFEB3B';
    } else if (id == 5) {
      $scope.color = 'FFC107';
    } else if (id == 6) {
      $scope.color = 'FF9800';
    } else if (id == 7) {
      $scope.color = 'F44336';
    } else if (id == 8) {
      $scope.color = 'E91E63';
    } else if (id == 9) {
      $scope.color = '9C27B0';
    } else {
      $scope.color = '3F51B5';
    }
    return $scope.color;
  };
  $scope.submit = function (isValid) {
    // console.log($scope.input)
    $scope.isSubmit = true;
    if(isValid){
      var startTime = $scope.input.startTime.split(":");
      var endTime = $scope.input.endTime.split(":");
      var sc = Schedules.get();
      sc.plan = $scope.input.plan;
    // sc.date = $scope.input.date;
    sc.location = $scope.input.location;
    sc.pic = $scope.input.pic;
    sc.teamMandiri = $scope.input.teamMandiri;
    sc.teamClient = $scope.input.teamClient;
    sc.startDate = moment($scope.input.startDate).set('h',startTime[0]).set('m',startTime[1]).set('s',0).format('YYYY-MM-DD HH:mm:ss'),
    sc.endDate = moment($scope.input.startDate).set('h',endTime[0]).set('m',endTime[1]).set('s',0).format('YYYY-MM-DD HH:mm:ss'),
    sc.description = $scope.input.description;
    
    if (mData.sc) {
      sc.$update({ id: mData.sc.id }, function () {
        toastr.success('Schedule has been updated', 'Schedule');
        $modalInstance.close();
      });
    } else{
      sc.offeringId = $scope.input.pipelineId.id;
      sc.salesId = $scope.currUser.salesId;
      sc.pic = 'none';
      sc.location = 'Jakarta';
      sc.color = $scope.findColor($scope.input.pipelineId.statusId)
      console.log(sc)
      sc.$save(function () {
        toastr.success('Schedule has been added', 'Schedule');
        $modalInstance.close();
      });
    }
  }
};
$scope.cancel = function () {
  $modalInstance.dismiss('cancel');
};
$scope.delete = function (id) {
  var sc = Schedules.get();
  sc.$delete({ id: mData.sc.id }, function () {
    toastr.success('Schedule has been deleted', 'Schedule');
    $modalInstance.close();
  });
};
$scope.newPipeline = function(){
 var modalInstance = $modal.open({
  templateUrl: 'app/pipelines/pipelines.modal.html',
  controller: 'modalPipelines',
  size: $scope.modalSize,
  resolve: {
    mData: function () {
      return false;
    }
  }
});
 modalInstance.result.then(function (res) {
      // $scope.getPipelines();
    });
};
$scope.newCustomer = function(){
  var modalInstance = $modal.open({
    templateUrl: 'app/clients/clients.modal.html',
    controller: 'modalClients',
    size: $scope.modalSize,
      // windowClass:'devid-modal',
      resolve: {
        mData: function () {
          return false;
        }
      }
    });
  modalInstance.result.then(function (res) {
      // $scope.getClients();
    });
};
});