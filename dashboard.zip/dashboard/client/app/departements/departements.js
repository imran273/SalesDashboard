'use strict';
angular.module('smoApp').config(function ($stateProvider) {
  $stateProvider.state('departements', {
    url: '/departements',
    templateUrl: 'app/departements/departements.html',
    controller: 'DepartementsCtrl'
  });
});
angular.module('smoApp').controller('modalDepartements', function ($scope, $rootScope, $modalInstance, Departements, toastr, mData) {
  $scope.input = {};
  if (mData.id) {
    $scope.title = 'Edit Departements';
    Departements.get({}, { id: mData.id }, function (u) {
      // console.log(u)
      $scope.input = u.departements[0];
    });
  } else {
    $scope.title = 'Add Departements'  //Behin Add Modal
;
  }
  $scope.ok = function () {
    $scope.errors = [];
    //input validation		
    if ($scope.input.name === angular.noop())
      $scope.errors.push({ text: 'Name is required' });
    if ($scope.errors.length === 0) {
      // console.log('save')
      $scope.errors = undefined;
      var departement = Departements.get();
      departement.name = $scope.input.name;
      if (mData.id) {
        departement.$update({ id: mData.id }, function (res) {
          //console.log(res)
          toastr.success($scope.input.name + ' has been updated!', 'Departements');
          $modalInstance.close();
        });
      } else {
        departement.$save(function (res) {
          // console.log(res)
          toastr.success($scope.input.name + ' has been added!', 'Departements');
          $modalInstance.close();
        });
      }  // departement.$save(function(res){
         // 	console.log(res)
         // 	toastr.success($scope.input.name+' has been added!','Departements');
         // 	$modalInstance.close();
         // });
    }
  };
  $scope.cancel = function () {
    $modalInstance.dismiss('cancel');
  };
});