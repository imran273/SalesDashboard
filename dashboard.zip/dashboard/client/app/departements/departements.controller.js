'use strict';
angular.module('smoApp').controller('DepartementsCtrl', function ($scope, $rootScope, $cookies, $modal, Auth, Departements, $location, toastr) {
  $location.path(Auth.isLogin() ? 'login' : 'departements');
  $scope.page = {
    title: 'Departements',
    desc: 'Departements Management'
  };


  $scope.getDepartements = function () {
    // $scope.dpt = Departements.get();  // console.log($scope.dpt)
    Departements.get(function (d) {
      $scope.dpt = d.departements;
      $scope.dtCount = d.count;
      $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage)+1;
      $scope.offset = 0;
    });
  };

  $scope.currentPage = 1;
  $scope.prevDisable = true;
  // console.log($scope.currentPage);
  $scope.next = function(){
    $scope.currentPage  = $scope.currentPage + 1;
    if($scope.currentPage < $scope.numPages){
        // $scope.currentPage = $scope.numPages;
        $scope.nextDisable = false;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
        // console.log($scope.offset);
    } else if($scope.currentPage = $scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
    }else{
      $scope.nextDisable = false;
      $scope.prevDisable = false;
    }
    // console.log($scope.currentPage);
    // console.log($scope.numPages);
  }
  $scope.prev = function(){
    $scope.currentPage  = $scope.currentPage -1;
    if($scope.currentPage > 1){
        // $scope.currentPage = 1;
        $scope.nextDisable = false;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
        // console.log($scope.offset)
    } else if($scope.currentPage = 1){
        $scope.nextDisable = false;
        $scope.prevDisable = true;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
    }
  }
  $scope.itemByPageChange = function(){
    $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage)+1;
    if($scope.currentPage >=$scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = true;
    } else{
        $scope.nextDisable = false;
        $scope.prevDisable = false;
    }
  }
  $scope.currPageChange = function(){
    if($scope.currentPage >=$scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = false;
        $scope.currentPage = $scope.numPages;
    } else if($scope.currentPage <=1){
        $scope.prevDisable = true;
        $scope.nextDisable = false;
        $scope.currentPage = 1;
    } else{
        $scope.nextDisable = false;
        $scope.prevDisable = false;
    } 
    $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
  };

  $scope.getDepartements();
  $scope.modalTemplateUrl = 'app/departements/departements.modal.html';
  $scope.modalSize = 'm';
  //open modal for add item
  $scope.add = function () {
    var modalInstance = $modal.open({
      templateUrl: $scope.modalTemplateUrl,
      controller: 'modalDepartements',
      size: $scope.modalSize,
      resolve: {
        mData: function () {
          return false;
        }
      }
    });
    modalInstance.result.then(function (res) {
      $scope.getDepartements();
    });
  };
  //open modal for edit Item
  $scope.edit = function (id) {
    var modalInstance = $modal.open({
      templateUrl: $scope.modalTemplateUrl,
      controller: 'modalDepartements',
      size: $scope.modalSize,
      resolve: {
        mData: function () {
          return { id: id };
        }
      }
    });
    modalInstance.result.then(function (res) {
      $scope.getDepartements();
    });
  };
  //open modal for add delete
  $scope.delete = function (id, name) {
    var modalInstance = $modal.open({
      templateUrl: 'app/app.modal.delete.html',
      controller: 'modalDelete',
      size: $scope.modalSize,
      resolve: {
        mData: function () {
          return {
            id: id,
            name: name
          };
        }
      }
    });
    modalInstance.result.then(function (res) {
      //action when delete
      var departement = Departements.get();
      departement.$delete({ id: res }, function (u) {
        toastr.success('Departement has been deleted', 'Departements');
        $scope.getDepartements();
      });
    });
  };
  $scope.selectedAll = false;
  $scope.checkAll = function(){
    console.log('cek')
    $scope.selectedAll = !$scope.selectedAll;
    angular.forEach($scope.dpt, function (item) {
      item.Selected = $scope.selectedAll;
    });
  };
  $scope.removeSelected = function(){
    angular.forEach($scope.dpt,function (item){
      if(item.Selected){
        var i = Departements.get();
        i.$delete({id:item.id});
      }
    })
    $scope.getDepartements();
  };
  $scope.itemsByPage = 10;
  $scope.thead = [
    {
    title: '#',
    width: 25,
    noClick:true,
    attr: 'checklist'
    },
    {
      title: 'Name',
      width: 200,
      attr: 'name'
    },
    {
      title: 'Last Update',
      width: 100,
      attr: 'updatedAt'
    },
    {
      title: 'Actions',
      width: 100,
      attr: 'actions'
    }
  ];
});