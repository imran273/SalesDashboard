'use strict';
describe('Controller: DepartementsCtrl', function () {
  // load the controller's module
  beforeEach(module('smoApp'));
  var DepartementsCtrl, scope;
  // Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope) {
    scope = $rootScope.$new();
    DepartementsCtrl = $controller('DepartementsCtrl', { $scope: scope });
  }));
  it('should ...', function () {
    expect(1).toEqual(1);
  });
});