'use strict';
angular.module('smoApp').controller('LoginCtrl', function ($scope, $rootScope, $http, $timeout, $location, $filter, $cookies) {
  var body = $('body');
  body.addClass('page-md login');
  $scope.login = function () {
    $scope.errors = [];
    $scope.err = '';
    if ($scope.credential.email == '')
      $scope.errors.push({ msg: 'Email is required!' });
    if ($scope.credential.pass == '')
      $scope.errors.push({ msg: 'Password is required!' });
    if ($scope.errors.length > 0) {
      $scope.submitted = true;
      // console.log($scope.errors)
      angular.forEach($scope.errors, function (e) {
        $scope.err += '<li>' + e.msg + '</li>';
      });
    } else {
      $scope.credential.password = $filter('vidcrypt')($scope.credential.pass);
      $http.post('api/things', $scope.credential).then(function (res) {
        console.log(res);
        if (res.data == '') {
          $scope.submitted = true;
          $scope.err = 'Login failed';
        } else {
          $scope.submitted = false;
          var config = { expires: moment().add(2, 'h').format('Wdy, DD Mon YYYY HH:MM:SS GMT') };
          // console.log(config.expires)
          $cookies.putObject('currentUser', res.data, config);
          var c = $cookies.get('currentUser');
          if (c.length > 0) {
            var token = $cookies.getObject('currentUser');
            $rootScope.headerAuth = 'Bearer ' + token.token;
            $http.defaults.headers.common.Authorization = $rootScope.headerAuth;
            if (res.data.roleId) {
              if (res.data.roleId == 5) {
                $location.path('saleshead');
              } else if (res.data.roleId == 4) {
                $location.path('sales');
              } else {
                $location.path('main');
              }
            } else {
              $scope.err = 'Network Error';
            }
          }
        }
      });
    }
  };
});