'use strict';
describe('Controller: PipelinesCtrl', function () {
  // load the controller's module
  beforeEach(module('smoApp'));
  var PipelinesCtrl, scope;
  // Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope) {
    scope = $rootScope.$new();
    PipelinesCtrl = $controller('PipelinesCtrl', { $scope: scope });
  }));
  it('should ...', function () {
    expect(1).toEqual(1);
  });
});