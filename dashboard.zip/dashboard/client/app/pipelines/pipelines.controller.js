'use strict';
angular.module('smoApp').controller('PipelinesCtrl', function ($scope, $rootScope,$timeout, $cookies, Auth, $http, Pipelines, $modal, $location, toastr) {
  $location.path(Auth.isLogin() ? 'login' : 'pipelines');
  $scope.page = {
    title: 'Pipelines',
    desc: 'Pipelines Management'
  };
  $scope.currUser = $cookies.getObject('currentUser');
  $scope.getPipelines = function () {
    if ($scope.currUser.roleId === 4 || $scope.currUser.roleId === 5) {
      Pipelines.getJoin({}, { deptId: $scope.currUser.departementId,salesId:$scope.currUser.salesId}, function (p) {
        // console.log(p)
        $scope.pipelines = p.offerings;
        $scope.dtCount = p.count;
        $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage)+1;
        $scope.offset = 0;
      }, function () {
        toastr.error('Something wrong.', 'Internal Network Error!');
      });
    } else {
      Pipelines.getJoinAll(function (p) {
        $scope.pipelines = p.offerings;
        $scope.dtCount = p.count;
        // console.log($scope.dtCount);
        $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage)+1;
        $scope.offset = 0;
      }, function () {
        toastr.error('Something wrong', 'Internal Network Error!');
      });
    }
  };
  // $scope.getPipelines();

  $scope.currentPage = 1;
  $scope.prevDisable = true;
  // console.log($scope.currentPage);
  // console.log($scope.numPages);
  $scope.next = function(){
    $scope.currentPage  = $scope.currentPage + 1;
    if($scope.currentPage < $scope.numPages){
        // $scope.currentPage = $scope.numPages;
        $scope.nextDisable = false;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
        // console.log($scope.offset);
    } else if($scope.currentPage = $scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
    }else{
      $scope.nextDisable = false;
      $scope.prevDisable = false;
    }
    // console.log($scope.currentPage);
    // console.log($scope.numPages);
  }
  $scope.prev = function(){
    $scope.currentPage  = $scope.currentPage -1;
    if($scope.currentPage > 1){
        // $scope.currentPage = 1;
        $scope.nextDisable = false;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
        // console.log($scope.offset)
    } else if($scope.currentPage = 1){
        $scope.nextDisable = false;
        $scope.prevDisable = true;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
    }
  }
  $scope.itemByPageChange = function(){
    $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage)+1;
    if($scope.currentPage >=$scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = true;
    } else{
        $scope.nextDisable = false;
        $scope.prevDisable = false;
    }
  }
  $scope.currPageChange = function(){
    if($scope.currentPage >=$scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = false;
        $scope.currentPage = $scope.numPages;
    } else if($scope.currentPage <=1){
        $scope.prevDisable = true;
        $scope.nextDisable = false;
        $scope.currentPage = 1;
    } else{
        $scope.nextDisable = false;
        $scope.prevDisable = false;
    } 
    $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
  };

  $scope.getPipelines();
  $scope.modalTemplateUrl = 'app/pipelines/pipelines.modal.html';
  $scope.modalSize = 'm';
  //open modal for add Item
  $scope.add = function () {
    var modalInstance = $modal.open({
      templateUrl: $scope.modalTemplateUrl,
      controller: 'modalPipelines',
      size: $scope.modalSize,
      resolve: {
        mData: function () {
          return false;
        }
      }
    });
    modalInstance.result.then(function (res) {
      $scope.getPipelines();
    });
  };
  //open modal for edit Item
  $scope.edit = function (id) {
    var modalInstance = $modal.open({
      templateUrl: $scope.modalTemplateUrl,
      controller: 'modalPipelines',
      size: $scope.modalSize,
      resolve: {
        mData: function () {
          return { id: id };
        }
      }
    });
    modalInstance.result.then(function (res) {
      $timeout($scope.getPipelines(),500)
    });
  };
  $scope.clickRow = function(isClicked,id){
    // console.log(isClicked)
    if(isClicked===undefined || isClicked===false){
      $scope.edit(id);
    }
  }
  $scope.exportXls =function(){
    exportTableToExcel('pipelineTable',"pipelines.xlsx");
  };
  
  //open modal for add delete
  $scope.delete = function (id, name) {
    var modalInstance = $modal.open({
      templateUrl: 'app/app.modal.delete.html',
      controller: 'modalDelete',
      size: $scope.modalSize,
      resolve: {
        mData: function () {
          return {
            id: id,
            name: name
          };
        }
      }
    });
    modalInstance.result.then(function (res) {
      var pipeline = Pipelines.get();
      pipeline.$delete({ id: res }, function (u) {
        toastr.success('Pipeline has been deleted', 'Pipelines');
        $scope.getPipelines();
      });
    });
  };
  $scope.itemsByPage = 10;
  $scope.thead = [
    {
      title: 'CIF',
      width: 75,
      align: 'left',
      attr: 'cif'
    },
    // {
    //   title: 'New/Existing',
    //   width: 100,
    //   align: 'center',
    //   attr: 'offeringType'
    // },
    {
      title: 'Category',
      width: 75,
      align: 'center',
      attr: 'productType'
    },
    {
      title: 'Group Name',
      width: 100,
      align: 'left',
      attr: 'groupId'
    },
    {
      title: 'Customer Name',
      width: 125,
      align: 'left',
      attr: 'clientId'
    },{
      title: 'Group (based on BUC)',
      width: 150,
      align: 'center',
      attr: 'groupBuc'
    },
    {
      title: 'Description',
      width: 100,
      align: 'left',
      attr: 'description'
    },
    {
      title: 'Sales Name',
      width: 100,
      align: 'left',
      attr: 'salesId'
    },
    {
      title: 'Sales Cycle',
      width: 180,
      align: 'center',
      attr: 'statusId'
    },{
      title: 'Product/Solution',
      width: 125,
      align: 'center',
      attr: 'productId'
    },{
      title: 'Product Category',
      width: 125,
      align: 'center',
      attr: 'productCategory'
    },
    {
      title:'Est. Additional | FBI per Year - Cash (IDR Mn)',
      width:275,
      align:'center',
      attr:'estCash'
    },
    {
      title:'Est. Additional | FBI per Year - Trade (IDR Mn)',
      width:275,
      align:'center',
      attr:'estCash'
    },
    {
      title:'Est. Additional | AVG Balance - Cash(IDR Mn)',
      width:275,
      align:'center',
      attr:'estAvg'
    },
    {
      title:'Est. Outstanding Trade (IDR Mn)',
      width:250,
      align:'center',
      attr:'estOutstanding'
    },
    {
      title: 'Open Date',
      width: 100,
      align: 'center',
      attr: 'openDate'
    },
    {
      title: 'Expected Closed Date',
      width: 150,
      align: 'center',
      attr: 'expectedCloseDate'
    },
    {
      title: 'Expected Closed Date Revised',
      width: 200,
      align: 'center',
      attr: 'expectedCloseDateRevised'
    },
    {
      title: 'Won Date',
      width: 100,
      align: 'center',
      attr: 'wonDate'
    },
    {
      title: 'Close Implementation',
      width: 175,
      align: 'center',
      attr: 'closeImplementationDate'
    },
    {
      title: 'Deal Date',
      width: 100,
      align: 'center',
      attr: 'dealDate'
    },
    {
      title: 'Comment',
      width: 175,
      noClick:true,
      align: 'center',
      attr: 'comment'
    },
    {
      title: 'Next Action',
      width: 175,
      align: 'left',
      attr: 'nextAction'
    },
    {
      title: 'Deal Ended',
      width: 100,
      align: 'center',
      attr: 'dealEnded'
    },
    {
      title: 'Actions',
      width: 75,
      noClick:true,
      align: 'right',
      attr: 'actions'
    }
  ];
  $scope.tableWidth = 0;
  angular.forEach($scope.thead, function (t) {
    $scope.tableWidth = $scope.tableWidth + t.width;
  });
});