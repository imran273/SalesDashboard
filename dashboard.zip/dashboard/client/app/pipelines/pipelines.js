'use strict';
angular.module('smoApp').config(function ($stateProvider) {
  $stateProvider.state('pipelines', {
    url: '/pipelines',
    templateUrl: 'app/pipelines/pipelines.html',
    controller: 'PipelinesCtrl'
  }).state('pipelinesDept', {
    url: '/pipelines/dept/:deptId',
    templateUrl: 'app/pipelines/pipelines.html',
    controller: 'PipelinesCtrl'
  });
});
angular.module('smoApp').controller('modalPipelines', function ($scope, $rootScope,$modal,$location, $modalInstance, Comments,$http, Pipelines, Clients, Status, PipelineAction, Products, Sales, SalesCycles, toastr, mData, $filter, $cookies, $timeout) {
  $scope.input = {};
  $scope.viewReport = function(){
    $modalInstance.close();
    $location.path('callreport')

  }
  $scope.currUser = $cookies.getObject('currentUser');
  // console.log($scope.currUser)
  $scope.openMax = moment().add(1,'w').format('YYYY-MM-DD HH:mm:ss');
  $scope.openMin = moment().add(1,'d').format('YYYY-MM-DD HH:mm:ss');
  $scope.productType = true;
  $scope.disabledExpectedDate = true;
  $scope.productCat = true;
  $scope.salesCycle = true;
  $scope.cifDisable =true;
  if($scope.currUser.roleId===4){
  	$scope.salesName = true;
  } else {
  	$scope.salesName = false;
  }
    
  $scope.groupCustDisable = true;
  $scope.getClients = function () {
    Clients.getCustomer(function (c) {
      $scope.clients = c.clients;
    });
  };
  $scope.getClients();
  $scope.getGroupClient = function () {
    Clients.getGroup(function (c) {
      $scope.clientGroups = c.clients;
    });
  };
  $scope.getGroupClient();
  $scope.customerIdChange = function () {
    Clients.getCustomerById({},{ id: $scope.input.clientId.id }, function (c) {
      console.log($scope.input.clientId.id)
      $scope.input.clientGroupId = c.clients[0].parentId;
      $scope.input.cifs = c.clients[0].ClientInformations;
      console.log(c.clients[0])
    });
  };

  if (mData.id) {
    //Begin Edit Modal 
    $scope.title = 'Edit Pipelines';
    Pipelines.getFull({}, { id: mData.id }, function (u) {
      // console.log(u.offerings[0])
      $scope.input = u.offerings[0];
      $scope.customerIdChange();
      $scope.input.products = u.offerings[0].productId;
      $scope.productChange();
      if(u.offerings[0].comment){
        $scope.input.comment = u.offerings[0].comment.comment;
      }
      $scope.input.clientId = u.offerings[0].client;
      if($scope.input.clientId.id){
        // console.log($scope.input.clientId.id)
        $scope.customerIdChange();
      }
      if(u.offerings[0].action){
        $scope.input.nextAction = u.offerings[0].action.nextAction;
      }
      if($scope.currUser.roleId===4){
      	$scope.custDisable = true;
      	$scope.groupCustDisable = true;
      	$scope.openDateDisable = true;
      	$scope.productDisable = true;
      	$scope.groupBucDisable = true;
      	$scope.cifDisable =true;
      	$scope.offTypeDisable = true;
      }
      if($scope.input.statusId>=4){
      	$scope.fbi1 = true;
      	$scope.fbi2 = true;
      	$scope.fbi3 = true;
      	$scope.fbi4 = true;
      }
    });
  } else {
    $scope.title = 'Add Pipelines';
    $scope.input.statusId = 1;
    $scope.input.salesId = $scope.currUser.salesId;
  }
  //get roles
  $scope.getSalesCycle = function () {
    Status.get(function (s) {
      $scope.salesCycle = s.status;
    });
  };
  $scope.getSalesCycle();
  $scope.types = [
    {
      id: 'cash',
      name: 'Cash'
    },
    {
      id: 'trade',
      name: 'Trade'
    }
  ];
  $scope.categories = [
    {
      id: 'simple',
      name: 'Simple'
    },
    {
      id: 'medium',
      name: 'Medium'
    },
    {
      id: 'complex',
      name: 'Complex'
    }
  ];
  $scope.offeringTypes = [
    {
      id: 'new',
      name: 'New'
    },
    {
      id: 'existing',
      name: 'Existing'
    },
    {
      id: 'prospect',
      name: 'Prospect'
    }
  ];
  $scope.getProducts = function () {
    Products.getByDeptId({}, { deptId: $scope.currUser.departementId }, function (p) {
      $scope.products = p.products;
    });
  };
  $scope.getProducts();
  $scope.getSales = function () {
    Sales.get(function (sl) {
      $scope.sales = sl.sales;
    });
  };
  $scope.getSales();
  $scope.salesChange = function () {
  };
  
  $scope.groupChange = function () {
    // console.log($scope.input.clientGroupId);
    Clients.getParent({}, { id: $scope.input.clientGroupId }, function (c) {
      $scope.clients = c.clients;  // console.log(c)
    });
  };
  
  $scope.disabled = function (date, mode) {
    return mode === 'day' && (date.getDay() === 0 || date.getDay() === 6);
  };
  $scope.open1 = function ($event) {
    $event.preventDefault();
    $event.stopPropagation();
    if($scope.input.products===undefined || $scope.input.products===''){
      toastr.error('Select Product first','Note')
    } else{
      $scope.opened1 = true;
    }
  };
  $scope.open2 = function ($event) {
    $event.preventDefault();
    $event.stopPropagation();
    $scope.opened2 = true;
  };
  $scope.productChange = function () {
    if ($scope.input.products) {
      Products.getByProductDepartment({}, {
        id: $scope.input.products,
        deptId: $scope.currUser.departementId
      }, function (p) {
        var product = p.products[0];
        // console.log(p)
        $scope.input.category = product.category;
        $scope.input.type = product.type;
      });
    }
  };
  $scope.openDateChange = function () {
    $scope.defaultExpectedCloseDate();
  };
  $scope.productCategoryChange = function () {
    $scope.defaultExpectedCloseDate();
  };
  $scope.defaultExpectedCloseDate = function () {
    if ($scope.input.openDate && $scope.input.category) {
      var openDate = moment($filter('date')($scope.input.openDate.toLocaleDateString()), 'MM/DD/YYYY').format('YYYY-MM-DD HH:mm:ss');
      $scope.input.openDate = openDate;
      $scope.okBtn = true;
      $scope.weeks = 0;
      SalesCycles.getByDeptId({}, { deptId: $scope.currUser.departementId }, function (r) {
        $scope.simple = 0;
        $scope.medium = 0;
        $scope.complex = 0;
        angular.forEach(r.salesCycles, function (s) {
          $scope.simple += s.simple;
          $scope.medium += s.medium;
          $scope.complex += s.complex;
        });
        $timeout(function () {
          if ($scope.input.category === 'simple') {
            $scope.input.expectedCloseDate = moment(openDate, 'YYYY-MM-DD HH:mm:ss').add($scope.simple, 'w').format('YYYY-MM-DD HH:mm:ss');
          } else if ($scope.input.category === 'medium') {
            $scope.input.expectedCloseDate = moment(openDate, 'YYYY-MM-DD HH:mm:ss').add($scope.medium, 'w').format('YYYY-MM-DD HH:mm:ss');
          } else if ($scope.input.category === 'complex') {
            $scope.input.expectedCloseDate = moment(openDate, 'YYYY-MM-DD HH:mm:ss').add($scope.complex, 'w').format('YYYY-MM-DD HH:mm:ss');
          }
          $scope.okBtn = false;
        }, 100);
      }, function () {
        toastr.error('Check your connection', 'Network Problem');
      });
    }
  };
  $scope.dateOptions = {
    startingDay: 1,
    showWeeks: false
  };
  $scope.minDate = new Date();
  $scope.maxDate = undefined;
  $scope.ok = function () {
    $scope.errors = [];
    //input validation		
    // if ($scope.input.cif === angular.noop())
    //   $scope.errors.push({ text: 'CIF is required' });
    if ($scope.input.clientId === angular.noop())
      $scope.errors.push({ text: 'Customer Name is required' });
    if ($scope.input.clientGroupId === angular.noop())
      $scope.errors.push({ text: 'Group Customer is required' });
    // if($scope.input.type===angular.noop()) $scope.errors.push({text:'Category is required'});
    if ($scope.input.category === angular.noop())
      $scope.errors.push({ text: 'Solution Category is required' });
    if ($scope.input.statusId === angular.noop())
      $scope.errors.push({ text: 'Sales Cycle is required' });
    if ($scope.input.openDate === angular.noop())
      $scope.errors.push({ text: 'Open Date is required' });
    if ($scope.input.expectedCloseDate === angular.noop())
      $scope.errors.push({ text: 'Expected Closed Date is required' });
    // if($scope.input.description===angular.noop()) $scope.errors.push({text:'Description is required'});
    if ($scope.input.products === angular.noop())
      $scope.errors.push({ text: 'Product is required' });
    if ($scope.input.salesId === angular.noop())
      $scope.errors.push({ text: 'Sales is required' });
    if ($scope.errors.length === 0) {
      //console.log($scope.input)
      $scope.errors = undefined;
      var pipeline = Pipelines.get();
      pipeline.name = $scope.input.clientId.name;
      pipeline.description = $scope.input.description;
      pipeline.cif = $scope.input.cif;
      pipeline.openDate = $scope.input.openDate;
      pipeline.expectedCloseDate = $scope.input.expectedCloseDate;
      pipeline.clientId = $scope.input.clientId.id;
      pipeline.statusId = $scope.input.statusId;
      pipeline.salesId = $scope.input.salesId;
      // pipeline.groupBuc = $scope.input.groupBuc;
      pipeline.productId = $scope.input.products;
      pipeline.offeringType = $scope.input.offeringType || 'existing';
      pipeline.departementId = $scope.currUser.departementId;
      pipeline.estCash = $scope.input.estCash || 0;
      pipeline.estTrade = $scope.input.estTrade || 0;
      pipeline.estAvg = $scope.input.estAvg || 0;
      pipeline.estOutstanding = $scope.input.estOutstanding || 0;
      if (mData.id) {
        pipeline.$update({ id: mData.id }, function (res) {
          // console.log($scope.input)
          var pa = PipelineAction.get();
          pa.nextAction = $scope.input.nextAction || ' ';
          // pa.offeringId = mData.id;
          // pa.statusId = $scope.input.statusId;
          pa.$update({id:$scope.input.action.id},function(){
            if($scope.input.comment){
              var c = Comments.get();
              c.comment = $scope.input.comment
              c.offeringId = mData.id;
              c.userId = $scope.currUser.userId;
              c.$save(function(){
                return true;  
              },function(){
                toastr.error('Comment can\'t be saved', 'Pipeline');
              });
            }
          }, function(){
             toastr.error('Next Action can\'t be updated', 'Pipeline');
          });
          toastr.success('Pipeline has been updated!', 'Pipeline');
          $modalInstance.close();
        },function(){
          toastr.success('Pipeline can\'t been updated!', 'Pipeline');
          $modalInstance.close();
        });
      } else {
        pipeline.$save(function (res) {
          var pp = res.offerings[0];
          var pa = PipelineAction.get();
          pa.nextAction = $scope.input.nextAction || ' ';
          pa.offeringId = pp.id;
          pa.statusId = pp.statusId;
          pa.$save().then(function(){
            if($scope.input.comment){
              var c = Comments.get();
              c.comment = $scope.input.comment;
              c.offeringId = res.offerings[0].id;
              c.userId = $scope.currUser.userId;
              c.$save(function(){
                return true;  
              },function(){
                toastr.error('Comment can\'t be saved', 'Pipeline');
              });
            }
          },function(){
            toastr.error('Next Action can\'t be saved', 'Pipeline');
          });
          toastr.success('Pipeline has been added!', 'Pipeline');
          $modalInstance.close();
        },function(){
          toastr.success('Pipeline can\'t been added!', 'Pipeline');
          $modalInstance.close();
        });
      }
    }
  };
  $scope.addCustomer = function(){
    var modalInstance = $modal.open({
      templateUrl: 'app/clients/clients.modal.html',
      controller: 'modalClients',
      size: 'md',
      // windowClass:'devid-modal',
      resolve: {
        mData: function () {
          return false;
        }
      }
    });
    modalInstance.result.then(function (res) {
      $scope.getClients();
    });
  }
  $scope.cancel = function () {
    $modalInstance.dismiss('cancel');
  };
});