'use strict';
angular.module('smoApp', [
  'ngCookies',
  'ngResource',
  'ngSanitize',
  'ui.router',
  'ui.bootstrap',
  'ui.calendar',
  'ui.select',
  'smart-table',
  'angular-loading-bar',
  'angular.filter',
  'leaflet-directive',
  'ngDragDrop',
  'toastr',
  'tc.chartjs'
  ]).config(function ($stateProvider, $urlRouterProvider, $locationProvider,cfpLoadingBarProvider) {
    $urlRouterProvider.otherwise('/');
    cfpLoadingBarProvider.includeBar = false;
    cfpLoadingBarProvider.latencyThreshold = 500;
    $locationProvider.html5Mode(true);
  }).run(function ($rootScope, $cookies, $http) {
    var token;
    $rootScope.baseApi = 'http://45.64.96.237:3000/api/v1/';
    $rootScope.headerAuth = null;
    if ($cookies.getObject('currentUser')) {
      token = $cookies.getObject('currentUser');
      $rootScope.headerAuth = 'Bearer ' + token.token;
      $http.defaults.headers.common.Authorization = $rootScope.headerAuth;
    }
    $rootScope.getViewPort = function () {
      var e = window, a = 'inner';
      if (!('innerWidth' in window)) {
        a = 'client';
        e = document.documentElement || document.body;
      }
      return {
        width: e[a + 'Width'],
        height: e[a + 'Height']
      };
    };
    $rootScope.getResponsiveBreakpoint = function (size) {
    // bootstrap responsive breakpoints
    var sizes = {
      'xs': 480,
      // extra small
      'sm': 768,
      // small
      'md': 992,
      // medium
      'lg': 1200  // large
    };
    return sizes[size] ? sizes[size] : 0;
  };
});
//Controller for delete confirmation modal
angular.module('smoApp').controller('modalDelete', function ($scope, $modalInstance, mData) {
  $scope.id = mData.id || undefined;
  $scope.name = mData.name || ' ';
  $scope.ok = function () {
    $modalInstance.close($scope.id);
  };
  $scope.cancel = function () {
    $modalInstance.dismiss('cancel');
  };
});

angular.module('smoApp').directive('fixedhead',function($timeout){
  return {
    restrict: 'A',
    link: link
  };

  function link($scope, $elem, $attrs, $ctrl) {
    var elem = $elem[0];
    // wait for data to load and then transform the table
    $scope.$watch(tableDataLoaded, function(isTableDataLoaded) {
      if (isTableDataLoaded) {
        transformTable();
      }

    });
    function tableDataLoaded() {
          // first cell in the tbody exists when data is loaded but doesn't have a width
        // until after the table is transformed
        var firstCell = elem.querySelector('tbody tr:last-child td:last-child');
        return firstCell && !firstCell.style.width;
    }

    function transformTable() {
       $timeout(function() {
          var tbody = elem.querySelector('tbody');
          // angular.forEach(elem.querySelector('tbody > tr'),function(td){
          //         console.log(td)
          //     });
         
          var scrollBarWidth = tbody.offsetWidth - tbody.clientWidth;
          if (scrollBarWidth > 0) {
              // for some reason trimming the width by 2px lines everything up better
              scrollBarWidth -= 2;
              
              // var firstTh = elem.querySelector('thead tr:first-child th:last-child');
              // firstTh.style.width =(firstTh.offsetWidth + scrollBarWidth) + 'px';
              var nTh1 = elem.querySelector('thead tr:nth-child(1) th:last-child');
              if(nTh1){
                nTh1.style.width =(nTh1.offsetWidth + scrollBarWidth) + 'px';
              }
              var nTh2 = elem.querySelector('thead tr:nth-child(2) th:last-child');
              if(nTh2){
                nTh2.style.width =(nTh2.offsetWidth + scrollBarWidth) + 'px';
              }
              var nTh3 = elem.querySelector('thead tr:nth-child(3) th:last-child');
              if(nTh3){
                nTh3.style.width =(nTh3.offsetWidth + scrollBarWidth) + 'px';
              }
              // var lastTh = elem.querySelector('thead tr:last-child th:last-child');
              // lastTh.style.width =(lastTh.offsetWidth + scrollBarWidth) + 'px';
          }
       });
    }
  }
});
function generateArray(table) {
    var out = [];
    var rows = table.querySelectorAll('tr');
    var ranges = [];
    for (var R = 0; R < rows.length; ++R) {
        var outRow = [];
        var row = rows[R];
        var header = row.querySelectorAll('th');
        for (var H = 0; H < header.length; ++H) {
            var cell = header[H];
            var colspan = cell.getAttribute('colspan');
            var rowspan = cell.getAttribute('rowspan');
            var cellValue = cell.innerText;
            if(cellValue !== "" && cellValue == +cellValue) cellValue = +cellValue;

            //Skip ranges
            ranges.forEach(function(range) {
                if(R >= range.s.r && R <= range.e.r && outRow.length >= range.s.c && outRow.length <= range.e.c) {
                    for(var i = 0; i <= range.e.c - range.s.c; ++i) outRow.push(null);
                }
            });

            //Handle Row Span
            if (rowspan || colspan) {
                rowspan = rowspan || 1;
                colspan = colspan || 1;
                ranges.push({s:{r:R, c:outRow.length},e:{r:R+rowspan-1, c:outRow.length+colspan-1}});
            };
            
            //Handle Value
            outRow.push(cellValue !== "" ? cellValue : null);
            
            //Handle Colspan
            if (colspan) for (var k = 0; k < colspan - 1; ++k) outRow.push(null);
        }
        var columns = row.querySelectorAll('td');
        for (var C = 0; C < columns.length; ++C) {
            var cell = columns[C];
            var colspan = cell.getAttribute('colspan');
            var rowspan = cell.getAttribute('rowspan');
            var cellValue = cell.innerText;
            if(cellValue !== "" && cellValue == +cellValue) cellValue = +cellValue;

            //Skip ranges
            ranges.forEach(function(range) {
                if(R >= range.s.r && R <= range.e.r && outRow.length >= range.s.c && outRow.length <= range.e.c) {
                    for(var i = 0; i <= range.e.c - range.s.c; ++i) outRow.push(null);
                }
            });

            //Handle Row Span
            if (rowspan || colspan) {
                rowspan = rowspan || 1;
                colspan = colspan || 1;
                ranges.push({s:{r:R, c:outRow.length},e:{r:R+rowspan-1, c:outRow.length+colspan-1}});
            };
            
            //Handle Value
            outRow.push(cellValue !== "" ? cellValue : null);
            
            //Handle Colspan
            if (colspan) for (var k = 0; k < colspan - 1; ++k) outRow.push(null);
        }
        out.push(outRow);
    }
    return [out, ranges];
};

function datenum(v, date1904) {
  if(date1904) v+=1462;
  var epoch = Date.parse(v);
  return (epoch - new Date(Date.UTC(1899, 11, 30))) / (24 * 60 * 60 * 1000);
}
 
function sheetFromArrayOfArrays(data, opts) {
  var ws = {};
  var range = {s: {c:10000000, r:10000000}, e: {c:0, r:0 }};
  for(var R = 0; R != data.length; ++R) {
    for(var C = 0; C != data[R].length; ++C) {
      if(range.s.r > R) range.s.r = R;
      if(range.s.c > C) range.s.c = C;
      if(range.e.r < R) range.e.r = R;
      if(range.e.c < C) range.e.c = C;
      var cell = {v: data[R][C] };
      if(cell.v == null) continue;
      var cell_ref = XLSX.utils.encode_cell({c:C,r:R});
      
      if(typeof cell.v === 'number') cell.t = 'n';
      else if(typeof cell.v === 'boolean') cell.t = 'b';
      else if(cell.v instanceof Date) {
        cell.t = 'n'; cell.z = XLSX.SSF._table[14];
        cell.v = datenum(cell.v);
      }
      else cell.t = 's';
      
      ws[cell_ref] = cell;
    }
  }
  if(range.s.c < 10000000) ws['!ref'] = XLSX.utils.encode_range(range);
  return ws;
}
 
function Workbook() {
  if(!(this instanceof Workbook)) return new Workbook();
  this.SheetNames = [];
  this.Sheets = {};
}
 
function s2ab(s) {
  var buf = new ArrayBuffer(s.length);
  var view = new Uint8Array(buf);
  for (var i=0; i!=s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
  return buf;
}

function exportTableToExcel(id,name) {
var theTable = document.getElementById(id);
var oo = generateArray(theTable);
var ranges = oo[2];

/* original data */
var data = oo[0]; 
var ws_name = "SheetJS";
console.log(data); 

var wb = new Workbook(), ws = sheetFromArrayOfArrays(data);
 
/* add ranges to worksheet */
ws['!merges'] = ranges;

/* add worksheet to workbook */
wb.SheetNames.push(ws_name);
wb.Sheets[ws_name] = ws;

var wbout = XLSX.write(wb, {bookType:'xlsx', bookSST:false, type: 'binary'});

saveAs(new Blob([s2ab(wbout)],{type:"application/octet-stream"}), name)
}
