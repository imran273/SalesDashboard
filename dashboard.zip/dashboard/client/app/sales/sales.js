'use strict';
angular.module('smoApp').config(function ($stateProvider) {
  $stateProvider.state('sales', {
    url: '/sales',
    templateUrl: 'app/sales/sales.html',
    controller: 'SalesCtrl'
  });
});
angular.module('smoApp').controller('modalSales', function ($scope, $rootScope, $modalInstance, Sales, Departements, Divisions, Users, toastr, mData, $filter) {
  $scope.input = {};
  $scope.departements = Departements.get();
  $scope.divisions = Divisions.get();
  $scope.users = Users.get();
  //console.log($scope.roles)
  // console.log(mData.id)
  if (mData.id) {
    //Begin Edit Modal 
    $scope.title = 'Edit Sales';
    Sales.get({}, { id: mData.id }, function (u) {
      console.log(u);
      $scope.input = u.sales[0];
      $scope.selectedDepartements = u.sales[0].departementId;
      $scope.selectedDivisions = u.sales[0].divisionId;
      $scope.selectedUsers = u.sales[0].userId;
    });
  } else {
    $scope.title = 'Add Sales'  //Behin Add Modal
;
  }
  //get roles
  $scope.ok = function () {
    $scope.errors = [];
    //input validation		
    if ($scope.input.name === angular.noop())
      $scope.errors.push({ text: 'Name is required' });
    if ($scope.input.level === angular.noop())
      $scope.errors.push({ text: 'Level is required' });
    if ($scope.input.phone === angular.noop())
      $scope.errors.push({ text: 'Phone is required' });
    if ($scope.input.departementId === angular.noop())
      $scope.errors.push({ text: 'Department is required' });
    if ($scope.input.divisionId === angular.noop())
      $scope.errors.push({ text: 'Division is required' });
    if ($scope.input.userId === angular.noop())
      $scope.errors.push({ text: 'User is required' });
    if ($scope.errors.length === 0) {
      // console.log('save')
      $scope.errors = undefined;
      var sales = Sales.get();
      sales.name = $scope.input.name;
      sales.level = $scope.input.level;
      sales.departementId = $scope.input.departementId;
      sales.divisionId = $scope.input.divisionId;
      sales.userId = $scope.input.userId;
      if (mData.id) {
        sales.$update({ id: mData.id }, function (res) {
          //console.log(res)
          toastr.success($scope.input.name + ' has been updated!', 'Sales');
          $modalInstance.close();
        });
      } else {
        sales.$save(function (res) {
          // console.log(res)
          toastr.success($scope.input.name + ' has been added!', 'Sales');
          $modalInstance.close();
        });
      }
    }
  };
  $scope.cancel = function () {
    $modalInstance.dismiss('cancel');
  };
});