'use strict';
angular.module('smoApp').controller('SalesCtrl', function ($scope, $rootScope, $cookies, Auth, Sales, $modal, $location, toastr) {
  $location.path(Auth.isLogin() ? 'login' : 'sales');
  $scope.page = {
    title: 'Sales Summary',
    desc: ''
  };
});