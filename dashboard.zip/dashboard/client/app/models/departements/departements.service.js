'use strict';
angular.module('smoApp').factory('Departements', function ($rootScope, $resource) {
  return $resource($rootScope.baseApi + 'departements/:id', {}, {
    update: {
      method: 'PUT',
      params: { id: '@id' }
    },
    get: {
      method: 'GET',
      params: { id: '@id' }
    }
  });
});