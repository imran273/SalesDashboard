'use strict';
angular.module('smoApp').factory('Realizations', function ($rootScope, $resource) {
  return $resource($rootScope.baseApi + 'realizations/:id', {}, {
    update: {
      method: 'PUT',
      params: { id: '@id'}
    },
    get: {
      method: 'GET',
      params: { id: '@id' }
    },
    getJoinBySalesId:{
    	method:'GET',
    	params:{'q[salesId]':'@salesId'},
    	url:$rootScope.baseApi+'realizations?join[model]=Schedule'
    },
    getJoinById:{
      method:'GET',
      params:{'q[id]':'@id'},
      url:$rootScope.baseApi+'realizations?join[model]=Schedule'
    },
    getJoin:{
    	method:'GET',
    	url:$rootScope.baseApi+'realizations?join[model]=Schedule'
    },
    getLastWeekBySales:{
      method: 'GET',
      params: {
        'q[salesId]':'@salesId',
        'q[range][date][start]':'@start',
        'q[range][date][end]':'@end'
      },
      url:$rootScope.baseApi+'realizations?join[model]=Schedule&join[model]=Report'
    },
    statByDh:{
      method:'GET',
      params:{dhId:'@dhId'},
      url:$rootScope.baseApi+'realizations/:dhId/statistics'
    }
  });
  // return Realization;
});