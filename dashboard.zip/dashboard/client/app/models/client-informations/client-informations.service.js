'use strict';

angular.module('smoApp')
  .factory('clientInformations',function ($rootScope, $resource) {
  return $resource($rootScope.baseApi + 'client-informations/:id', {}, {
    update: {
      method: 'PUT',
      params: { id: '@id' }
    },
    get: {
      method: 'GET',
      params: { id: '@id' }
    },
    postBulk:{
      method: 'POST',
      params: {},
      url: $rootScope.baseApi+'client-informations/bulk-create'
    }

  });
});