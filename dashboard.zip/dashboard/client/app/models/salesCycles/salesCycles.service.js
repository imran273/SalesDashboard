'use strict';
angular.module('smoApp').factory('SalesCycles', function ($rootScope, $resource) {
  return $resource($rootScope.baseApi + 'sales-cycles/:id', {}, {
    update: {
      method: 'PUT',
      params: { id: '@id' }
    },
    get: {
      method: 'GET',
      params: { id: '@id' }
    },
    getByDeptId: {
      method: 'GET',
      params: { 'q[departementId]': '@deptId' },
      url: $rootScope.baseApi + 'sales-cycles'
    }
  });
});