'use strict';

angular.module('smoApp')
  .factory('ReportPartners', function ($rootScope,$resource) {
  return $resource($rootScope.baseApi + 'report-partners/:id', {}, {
  update: {
    method: 'PUT',
    params: { id: '@id' }
  },
  get: {
    method: 'GET',
    params: { id: '@id' }
  }
});
});
