'use strict';
angular.module('smoApp').factory('Clients', function ($rootScope, $resource) {
  return $resource($rootScope.baseApi + 'clients/:id', {}, {
    update: {
      method: 'PUT',
      params: { id: '@id' }
    },
    get: {
      method: 'GET',
      params: { id: '@id' }
    },
    getGroup: {
      method: 'GET',
      params: { 'q[parentId]': 'NULL' },
      url: $rootScope.baseApi + 'clients'
    },
    getGroupById: {
      method: 'GET',
      params: { 'q[parentId]': 'NULL','q[id]':'@id' },
      url: $rootScope.baseApi + 'clients'
    },
    getCustomer: {
      method: 'GET',
      params: { 'q[parentId][$not]': 'NULL' },
      url: $rootScope.baseApi + 'clients?join[model]=ClientPic&join[model]=ClientInformation'
    },
    getCustomerById: {
      method: 'GET',
      params: { 'q[parentId][$not]': 'NULL','q[id]':'@id' },
      url: $rootScope.baseApi + 'clients?join[model]=ClientPic&join[model]=ClientInformation'
    },
    getParent: {
      method: 'GET',
      params: { 'q[parentId]': '@id' },
      url: $rootScope.baseApi + 'clients'
    }
  });
});