'use strict';
angular.module('smoApp').factory('Users', function ($rootScope, $resource) {
  return $resource($rootScope.baseApi + 'users/:id', {}, {
    update: {
      method: 'PUT',
      params: { id: '@id' }
    },
    get: {
      method: 'GET',
      params: { id: '@id' }
    }
    
  });
});