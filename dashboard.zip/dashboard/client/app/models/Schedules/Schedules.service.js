'use strict';
angular.module('smoApp').factory('Schedules', function ($rootScope, $resource) {
  return $resource($rootScope.baseApi + 'schedules/:id', {}, {
    update: {
      method: 'PUT',
      params: { id: '@id' }
    },
    get: {
      method: 'GET',
      params: { id: '@id' }
    },
    getLastWeekBySales:{
      method: 'GET',
      params: {
        'q[salesId]':'@salesId',
        'q[range][startDate][start]':'@start',
        'q[range][startDate][end]':'@end'
      },
      url:$rootScope.baseApi+'schedules'
    },
    getBySalesId:{
      method: 'GET',
      params: {
        'q[salesId]':'@salesId',
      },
      url:$rootScope.baseApi+'schedules'
    }
  });
});