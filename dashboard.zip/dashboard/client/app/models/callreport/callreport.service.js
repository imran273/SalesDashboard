'use strict';
angular.module('smoApp').factory('CallReports', function ($rootScope, $resource) {
  return $resource($rootScope.baseApi + 'reports/:id', {}, {
    update: { method: 'PUT' },
    get: {
      method: 'GET',
      params: { id: '@id' }
    },
    getByRealisasiId :{
    	method:'GET',
    	params:{'q[realizationId]':'@id'},
    	url:$rootScope.baseApi + 'reports?join[model]=ReportAction&join[model]=ReportPartner'
    },
    getFullJoin:{
    	method:'GET',
    	params:{},
    	url:$rootScope.baseApi + 'reports?join[model]=Realization&join[model]=Offering'
    },
    getFullJoinBySalesId:{
    	method:'GET',
    	params:{'q[salesId]':'@salesId'},
    	url:$rootScope.baseApi + 'reports?join[model]=Realization&join[model]=Offering'
    },
    getStatByDept:{
    	method:'GET',
    	params:{deptId:'@deptId',date:'@date'},
    	url:$rootScope.baseApi+'reports/:deptId/dh-cycle-statistics/:date'
    }
  });
});