'use strict';

angular.module('smoApp')
.factory('OfferingCycleDeals', function ($rootScope,$resource) {
  return $resource($rootScope.baseApi + 'offering-cycle-deals/:id', {}, {
  update: {
    method: 'PUT',
    params: { id: '@id' }
  },
  get: {
    method: 'GET',
    params: { id: '@id' }
  }
});
});
