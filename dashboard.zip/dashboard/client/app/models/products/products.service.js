'use strict';
angular.module('smoApp').factory('Products', function ($rootScope, $resource) {
  return $resource($rootScope.baseApi + 'products/:id', {}, {
    update: {
      method: 'PUT',
      params: { id: '@id' }
    },
    get: {
      method: 'GET',
      params: { id: '@id' }
    },
    getByDeptId: {
      method: 'GET',
      params: { 'q[departementId]': '@deptId' },
      url: $rootScope.baseApi + 'products'
    },
    getByProductDepartment: {
      method: 'GET',
      params: {
        'q[id]': '@id',
        'q[departementId]': '@deptId'
      },
      url: $rootScope.baseApi + 'products'
    }
  });
});