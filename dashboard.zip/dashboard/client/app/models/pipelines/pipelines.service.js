'use strict';
angular.module('smoApp').factory('Pipelines', function ($rootScope, $resource) {
  return $resource($rootScope.baseApi + 'offerings/:id', {}, {
    update: {
      method: 'PUT',
      params: { id: '@id' }
    },
    get: {
      method: 'GET',
      params: { id: '@id' }
    },
    getFull: {
      method: 'GET',
      params: { id: '@id' },
      url: $rootScope.baseApi + 'offerings/:id/full'
    },
    getByDeptId: {
      method: 'GET',
      params: { 'q[departementId]': '@deptId' },
      url: $rootScope.baseApi + 'offerings'
    },
    getByClientId: {
      method: 'GET',
      params: { 'q[clientId]': '@clientId' },
      url: $rootScope.baseApi + 'offerings?join[model]=Client&join[model]=Product'
    },
    getByStatusId: {
      method: 'GET',
      params: {
        'q[departementId]': '@deptId',
        'q[statusId]': '@statusId',
        'q[salesId]':'@salesId'
      },
      url: $rootScope.baseApi + 'offerings?join[model]=Client&join[model]=Product'
    },
    postProduct: {
      method: 'PUT',
      params: { pipeId: '@pipeId' },
      url: $rootScope.baseApi + 'offerings/:pipeId/products'
    },
    getJoin: {
      method: 'GET',
      params: { 'q[departementId]': '@deptId','q[salesId]':'@salesId' },
      url: $rootScope.baseApi + 'offerings?join[model]=Client&join[model]=Product&join[model]=Comment&join[model]=OfferingCycleDeal'
    },
    getJoinAll: {
      method: 'GET',
      params: {},
      url: $rootScope.baseApi + 'offerings?join[model]=Client&join[model]=Departement&join[model]=Comment&join[model]=OfferingCycleDeal'
    },
    setRealization:{
       method:'POST',
       params:{offeringId:'@offeringId'},
       url:$rootScope.baseApi+ 'offerings/:offeringId/set-realization'
    },
    giveComment:{
      method:'POST',
      params:{},
      url:$rootScope.baseApi+'comments'
    }
  });
});