'use strict';

angular.module('smoApp')
  .factory('businessUnitCodes', function ($rootScope, $resource) {
  return $resource($rootScope.baseApi + 'business-unit-codes/:id', {}, {
    update: {
      method: 'PUT',
      params: { id: '@id' }
    },
    get: {
      method: 'GET',
      params: { id: '@id' }
    },
    getByDeptId:{
      method:'GET',
      params:{'q[departementId]':'@id'},
      url:$rootScope.baseApi+'business-unit-codes'
    },
  });
});