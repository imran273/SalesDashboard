'use strict';
angular.module('smoApp').factory('Sales', function ($rootScope, $resource) {
  var Sales = $resource($rootScope.baseApi + 'sales/:id', {}, {
    update: {
      method: 'PUT',
      params: { id: '@id' }
    },
    get: {
      method: 'GET',
      params: { id: '@id' }
    },
    query: {
      method: 'GET',
      params: { 'q[userId]': '@userId' }
    },
    getSalesId: {
      method: 'GET',
      params: { 'q[userId]': '@userid' },
      url: $rootScope.baseApi + 'sales'
    },
    getJoinBySalesId:{
      method:'GET',
      params:{'q[id]':'@salesId'},
      url:$rootScope.baseApi+'sales?join[model]=Division&join[model]=Departement'
    },
    getByDeptId:{
      method:'GET',
      params:{'q[departementId]':'@id'},
      url:$rootScope.baseApi+'sales'
    },
    getPerformance:{
      method:'GET',
      params:{},
      url:$rootScope.baseApi+'sales/performances'
    }
  });
  return Sales;
});