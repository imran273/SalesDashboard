'use strict';
angular.module('smoApp').factory('PipelineAction', function ($rootScope, $resource) {
  return $resource($rootScope.baseApi + 'offering-actions/:id', {}, {
    update: {
      method: 'PUT',
      params: { id: '@id' }
    },
    get: {
      method: 'GET',
      params: { id: '@id' }
    }
  });
});