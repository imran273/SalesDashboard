'use strict';
angular.module('smoApp').factory('Roles', function ($resource, $rootScope) {
  return $resource($rootScope.baseApi + 'roles/:id', {}, {
    update: {
      method: 'PUT',
      params: { id: '@id' }
    },
    get: {
      method: 'GET',
      params: { id: '@id' }
    }
  });
});