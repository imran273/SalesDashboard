'use strict';
angular.module('smoApp').factory('Divisions', function ($rootScope, $resource) {
  return $resource($rootScope.baseApi + 'divisions/:id', {}, {
    update: { method: 'PUT' },
    get: {
      method: 'GET',
      params: { id: '@id' }
    }
  });
});