'use strict';
angular.module('smoApp').factory('ClientPIC', function ($rootScope, $resource) {
  return $resource($rootScope.baseApi + 'client-pics/:id', {}, {
    update: {
      method: 'PUT',
      params: { id: '@id' }
    },
    get: {
      method: 'GET',
      params: { id: '@id' }
    },
    getByClientId:{
      method:'GET',
      params:{'q[clientId]':'@clientId'},
      url:$rootScope.baseApi+'client-pics'
    },
    postBulk:{
      method:'POST',
      params:{},
      url:$rootScope.baseApi+'client-pics/bulk-create'
    }
  });
});