'use strict';
angular.module('smoApp').controller('SettingsCtrl', function ($scope, $rootScope, $cookies, Auth, Users, $modal, $location, toastr) {
  $location.path(Auth.isLogin() ? 'login' : 'settings');
  $scope.page = {
    title: 'Master Settings',
    desc: 'Default System Settings'
  };
});