'use strict';
describe('Controller: SettingsCtrl', function () {
  // load the controller's module
  beforeEach(module('smoApp'));
  var SettingsCtrl, scope;
  // Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope) {
    scope = $rootScope.$new();
    SettingsCtrl = $controller('SettingsCtrl', { $scope: scope });
  }));
  it('should ...', function () {
    expect(1).toEqual(1);
  });
});