'use strict';
angular.module('smoApp').config(function ($stateProvider) {
  $stateProvider.state('realization', {
    url: '/realization',
    templateUrl: 'app/realization/realization.html',
    controller: 'RealizationsCtrl'
  });
});
angular.module('smoApp').controller('modalRealizations', function ($scope, $cookies, $http, $rootScope,$filter, $modalInstance,Pipelines, PipelineAction,Realizations,Schedules,OfferingCycleDeals,Status, toastr, mData) {
  $scope.input = {};
  $scope.currUser = $cookies.getObject('currentUser');
  if (mData.id) {
    $scope.title = 'Edit Realization';
    Realizations.get({}, { id: mData.id }, function (u) {
      console.log(u)
      $scope.input = u.realizations[0];
    });
  } else {
    $scope.title = 'Add Realizations';
    $scope.input.date = moment().format('YYYY-MM-DD HH:mm:ss');
    $scope.input.flagUpdateCycle = false;
  }
  $scope.schedules = [];

  $scope.startDate = moment().day(-2).startOf('d').format('YYYY-MM-DD HH:mm:ss');
  $scope.endDate = moment().day(5).endOf('d').format('YYYY-MM-DD HH:mm:ss');
  $scope.lastWeek = $scope.startDate +" To "+$scope.endDate
  $scope.getSchedules = function(){
    Schedules.getLastWeekBySales({},{salesId:$scope.currUser.salesId,start:$scope.startDate,end:$scope.endDate},function(s){
     angular.forEach(s.schedules,function(sc){
      $scope.schedules.push({
        plan:sc.plan,
        id:sc.id,        
        date:$filter('date')(sc.startDate,'dd/MM/yyyy')
      })      
    })
   })
  }
  $scope.getSchedules();
  $scope.dateOptions = {
    startingDay: 1,
    showWeeks: false
  };
  $scope.minDate = $scope.startDate;
  $scope.maxDate = undefined;
  $scope.open1 = function ($event) {
    $event.preventDefault();
    $event.stopPropagation();
    $scope.opened1 = true;
  };
  $scope.getStatus = function(){
    Status.get(function (s) {    
      $scope.salesCycles = s.status;
    });
  }
  $scope.scheduleChange = function(){
    Schedules.get({},{id:$scope.input.schedule},function(s){
      console.log(s)
      $scope.getStatus();
      $scope.input.teamMandiri = s.schedules.teamMandiri;
      $scope.input.teamClient = s.schedules.teamClient;
      $scope.input.description = s.schedules.description;
      $scope.input.offeringId = s.schedules.offeringId;      
      $scope.input.agenda = s.schedules.plan;
      Pipelines.get({},{id:s.schedules.offeringId},function(p){
        $scope.input.statusId = p.offerings[0].statusId;
        // console.log($scope.input.statusId)
        // console.log($scope.salesCycles)

        if($scope.salesCycles.length===9){
          $scope.salesCycles = $scope.salesCycles.slice($scope.input.statusId,9);
        }
        $scope.input.nextStatusId = $scope.input.statusId+1;
      })
    })
  };
  
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);    
  } else {
    console.log('geolocation not supported') 
  }
  $scope.center = {
    lat: 6.175,
    lng: 106.8283,
    zoom: 12
  };
  $scope.markers = {
    currentPoint:{
      lat: 6.175,
      lng: 106.8283,
      zoom: 12,
      focus: true,
      draggable: false
    }
  }
  $scope.layers = {
    baselayers: {


      googleRoadmap: {
        name: 'Google Streets',
        layerType: 'ROADMAP',
        type: 'google'
      },googleTerrain: {
        name: 'Google Terrain',
        layerType: 'TERRAIN',
        type: 'google'
      },googleHybrid: {
        name: 'Google Hybrid',
        layerType: 'HYBRID',
        type: 'google'
      }
    }
  };
  $scope.getLocation = function() {
    var geocoder = new google.maps.Geocoder();
    geocoder.geocode( { 'address': $scope.input.venue}, function(results, status) {
    if (status == google.maps.GeocoderStatus.OK) {
      
      $scope.center.lat = results[0].geometry.location.A;
      $scope.center.lng = results[0].geometry.location.F;
      $scope.markers.currentPoint.lat= results[0].geometry.location.A;
      $scope.markers.currentPoint.lng=results[0].geometry.location.F;
      // console.log($scope.center,results[0].geometry.location)
    } 
  });
  };
  $scope.events= {
    map: {
      enable: ['zoomstart', 'drag', 'click', 'mousemove'],
      logic: 'emit'
    }
  }
  $scope.defaults= {
    scrollWheelZoom: false
  };
  $scope.$on('leafletDirectiveMap.drag', function(event){
    $scope.markers.currentPoint = $scope.center;
  });

  $scope.$on('leafletDirectiveMap.click', function(event,args){
   var coords = args.leafletEvent.latlng;
   $scope.markers.currentPoint = {
    lat:coords.lat,
    lng:coords.lng,
    focus:true
  }
     // $scope.center = coords;
   });
  function showPosition(position) {
    $scope.center = {
      lat: position.coords.latitude,
      lng: position.coords.longitude,
      zoom: 12
    };
    $scope.markers = {
      currentPoint:{
        lat: position.coords.latitude ,
        lng: position.coords.longitude,
        zoom: 12,
        focus: true,
        draggable: false
      }
    }
  };

  $scope.ok = function () {
    $scope.errors = [];
    //input validation		
    if ($scope.input.schedule === angular.noop())
      $scope.errors.push({ text: 'Schedule is required' });
    if ($scope.input.date === angular.noop())
      $scope.errors.push({ text: 'Realization Date is required' });
    if ($scope.input.teamMandiri === angular.noop())
      $scope.errors.push({ text: 'Mandiri\'s team is required' });
    if ($scope.input.teamClient === angular.noop())
      $scope.errors.push({ text: 'Client\'s team is required' });
    if ($scope.input.nextAction === angular.noop())
      $scope.errors.push({ text: 'Next Action is required' });
    if ($scope.errors.length === 0) {
      $scope.okDisable = true
      // console.log($scope.input);
      $scope.errors = undefined;
      // var realization = Realizations.get();
      // realization.date = $scope.input.date;
      // realization.teamMandiri = $scope.input.teamMandiri;
      // realization.teamClient = $scope.input.teamClient;
      // realization.location = 'unavailable';
      // realization.description = $scope.input.description;
      // realization.lat = $scope.markers.currentPoint.lat;
      // realization.lng = $scope.markers.currentPoint.lng;
      // realization.flagUpdateCycle = $scope.input.flagUpdateCycle;
      // realization.scheduleId = $scope.input.schedule;
      // realization.salesId = $scope.currUser.salesId;
      var pipe = Pipelines.get();
      pipe.date = $scope.input.date;
      pipe.teamMandiri = $scope.input.teamMandiri;
      pipe.teamClient = $scope.input.teamClient;
      pipe.location = $scope.input.venue;
      pipe.description = $scope.input.description || " ";
      pipe.lat = $scope.markers.currentPoint.lat;
      pipe.lng = $scope.markers.currentPoint.lng;
      pipe.flagUpdateCycle = $scope.input.flagUpdateCycle;
      pipe.scheduleId = $scope.input.schedule;
      pipe.salesId = $scope.currUser.salesId;
      pipe.nextStatusId = $scope.input.nextStatusId;
      pipe.nextAction = $scope.input.nextAction;
      // pipe.offeringId = $scope.input.offeringId;


      if (mData.id) {
        realization.$update({ id: mData.id }, function (res) {
          //console.log(res)
          toastr.success($scope.input.openDate + ' has been updated!', 'Realizations');
          $modalInstance.close();
        });
      } else {
        pipe.$setRealization({offeringId:$scope.input.offeringId},function(){
          toastr.success('Realization has been submitted!', 'Realizations');
          $modalInstance.close();
        })
        // if($scope.input.flagUpdateCycle){
          // var ocd = OfferingCycleDeals.get();
          // ocd.statusId = $scope.input.statusId;
          // ocd.dealDate = $scope.input.date;
          // ocd.offeringId = $scope.input.offeringId;
          // ocd.$save(function(){
          //   console.log('OfferingCycleDeals saved')
          // })
          // var p = Pipelines.get();
          // p.statusId = $scope.input.statusId+1;          
          // if($scope.input.statusId===8){
          //   p.closeImplementationDate = $scope.input.date;
          // }
          // if($scope.input.statusId===7){
          //   p.wonDate = $scope.input.date;
          // }
          // p.$update({id:$scope.input.offeringId},function(){
          //   console.log('Pipeline updated!')
          // })
        // }
        // realization.$save(function (res) {
        //   // console.log(res)
        //   var p2 = PipelineAction.get();
        //   p2.nextAction = $scope.input.nextAction;
        //   p2.offeringId = $scope.input.offeringId;
        //   p2.statusId = $scope.input.statusId;
        //   p2.$save(function(){
        //     toastr.success('Realization has been submitted!', 'Realizations');
        //     $modalInstance.close();
        //   },function(){
        //     var R = Realizations.get();
        //     R.$delete({id:res.realizations[0].id});
        //   })
        // });
}
} else {
  $scope.okDisable = false
}
};
$scope.cancel = function () {
  $modalInstance.dismiss('cancel');
};
});