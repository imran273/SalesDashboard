'use strict';
describe('Controller: RealizationCtrl', function () {
  // load the controller's module
  beforeEach(module('smoApp'));
  var RealizationCtrl, scope;
  // Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope) {
    scope = $rootScope.$new();
    RealizationCtrl = $controller('RealizationCtrl', { $scope: scope });
  }));
  it('should ...', function () {
    expect(1).toEqual(1);
  });
});