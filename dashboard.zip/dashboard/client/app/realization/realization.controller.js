'use strict';
angular.module('smoApp').controller('RealizationsCtrl', function ($scope, $rootScope, $location,$cookies, Auth, Realizations, Schedules, $modal, toastr) {
  $location.path(Auth.isLogin() ? 'login' : 'realization');
  $scope.currUser = $cookies.getObject('currentUser');
  $scope.page = {
    title: 'Realizations',
    desc: 'Realizations Management'
  };
  $scope.getRealizations = function () {
    
    Realizations.getJoinBySalesId({},{id:$scope.currUser.salesId},function (rz) {
        $scope.realization = rz.realizations;
        $scope.dtCount = rz.count;
        $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage)+1;
        $scope.offset = 0;
    });
  };

  $scope.currentPage = 1;
  $scope.prevDisable = true;
  // console.log($scope.currentPage);
  $scope.next = function(){
    $scope.currentPage  = $scope.currentPage + 1;
    if($scope.currentPage < $scope.numPages){
        // $scope.currentPage = $scope.numPages;
        $scope.nextDisable = false;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
        // console.log($scope.offset);
    } else if($scope.currentPage = $scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
    }else{
      $scope.nextDisable = false;
      $scope.prevDisable = false;
    }
    // console.log($scope.currentPage);
    // console.log($scope.numPages);
  }
  $scope.prev = function(){
    $scope.currentPage  = $scope.currentPage -1;
    if($scope.currentPage > 1){
        // $scope.currentPage = 1;
        $scope.nextDisable = false;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
        // console.log($scope.offset)
    } else if($scope.currentPage = 1){
        $scope.nextDisable = false;
        $scope.prevDisable = true;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
    }
  }
  $scope.itemByPageChange = function(){
    $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage)+1;
    if($scope.currentPage >=$scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = true;
    } else{
        $scope.nextDisable = false;
        $scope.prevDisable = false;
    }
  }
  $scope.currPageChange = function(){
    if($scope.currentPage >=$scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = false;
        $scope.currentPage = $scope.numPages;
    } else if($scope.currentPage <=1){
        $scope.prevDisable = true;
        $scope.nextDisable = false;
        $scope.currentPage = 1;
    } else{
        $scope.nextDisable = false;
        $scope.prevDisable = false;
    } 
    $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
  };
  $scope.getStatistic = function(){
    Realizations.statByDh({},{dhId:$scope.currUser.departementId},function(s){
      console.log(s)
    })
  }
  if($scope.currUser.roleId===4){
    $scope.getRealizations();
  }
  if($scope.currUser.roleId===3){
    $scope.getStatistic();
  }
  $scope.modalTemplateUrl = 'app/realization/realization.modal.html';
  $scope.modalSize = 'm';
  //open modal for add Item
  $scope.add = function () {
    var modalInstance = $modal.open({
      templateUrl: $scope.modalTemplateUrl,
      controller: 'modalRealizations',
      size: $scope.modalSize,
      // windowClass:'devid-modal',
      resolve: {
        mData: function () {
          return false;
        }
      }
    });
    modalInstance.result.then(function (res) {
      $scope.getRealizations();
    });
  };
  //open modal for edit Item
  $scope.edit = function (id) {
    var modalInstance = $modal.open({
      templateUrl: $scope.modalTemplateUrl,
      controller: 'modalRealizations',
      size: $scope.modalSize,
      resolve: {
        mData: function () {
          return { id: id };
        }
      }
    });
    modalInstance.result.then(function (res) {
      $scope.getRealizations();
    });
  };
  //open modal for add delete
  $scope.delete = function (id, name) {
    var modalInstance = $modal.open({
      templateUrl: 'app/app.modal.delete.html',
      controller: 'modalDelete',
      size: $scope.modalSize,
      resolve: {
        mData: function () {
          return {
            id: id,
            name: name
          };
        }
      }
    });
    modalInstance.result.then(function (res) {
      //action when delete
      var rz = Realizations.get();
      rz.$delete({ id: res }, function (u) {
        toastr.success('Realizations has been deleted', 'Realizations');
        $scope.getRealizations();
      });
    });
  };
   $scope.select = {
    realization : [$scope.realization]
  }
  //select item
  $scope.checkAll = function(){
    $scope.select.realization = angular.copy($scope.realization);
  };
  $scope.uncheckAll = function(){
    $scope.select.realization = [];
  }
  // $scope.deleteBySelected = function(){

  // }
  $scope.itemsByPage = 10;
  $scope.thead = [
    {
      title: 'Appointment Plan Date',
      width: 100,
      align: 'center',
      attr: 'scheduleId'
    },{
      title: 'Realization Date',
      width: 100,
      align: 'center',
      attr: 'date'
    },
    {
      title: 'Mandiri\'s Team',
      width: 200,
      align: 'left',
      attr: 'teamMandiriPlan'
    },
    {
      title: 'Mandiri\'s Team',
      width: 200,
      align: 'left',
      attr: 'teamMandiri'
    },
    {
      title: 'Client\'s Team',
      width: 200,
      align: 'left',
      attr: 'teamClientPlan'
    },
    {
      title: 'Client\'s Team',
      width: 200,
      align: 'left',
      attr: 'teamClient'
    },
    {
      title: 'Description',
      width: 200,
      align: 'left',
      attr: 'description'
    },
    {
      title: 'Actions',
      width: 80,
      align: 'right',
      attr: 'actions'
    }]
    $scope.tableWidth = 0
    angular.forEach($scope.thead, function(t){
        $scope.tableWidth = $scope.tableWidth+ t.width
    })
  });
