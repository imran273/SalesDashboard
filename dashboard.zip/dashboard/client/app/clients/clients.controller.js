'use strict';
angular.module('smoApp').controller('ClientsCtrl', function ($scope, $rootScope, $timeout,$cookies, Auth, $location, Clients, ClientPIC, $modal, toastr) {
  $location.path(Auth.isLogin() ? 'login' : 'clients');
  $scope.page = {
    title: 'Customer',
    desc: 'Customer Management'
  };

  $scope.getClients = function () {
    Clients.getCustomer(function (c) {
      $scope.clients = c.clients;
      $scope.dtCount = c.count;
      $scope.numPages = parseInt($scope.dtCount / $scope.itemsByPage)+1;
      $scope.offset = 0;
      // console.log(c)
    }, function () {
        toastr.error('Something wrong.', 'Internal Server Error!');
      });
  };

  $scope.currentPage = 1;
  $scope.prevDisable = true;
  // console.log($scope.currentPage);
  $scope.next = function(){
    $scope.currentPage  = $scope.currentPage + 1;
    if($scope.currentPage < $scope.numPages){
        // $scope.currentPage = $scope.numPages;
        $scope.nextDisable = false;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
        // console.log($scope.offset);
      } else if($scope.currentPage = $scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
      }else{
        $scope.nextDisable = false;
        $scope.prevDisable = false;
      }
    // console.log($scope.currentPage);
    // console.log($scope.numPages);
  }
  $scope.prev = function(){
    $scope.currentPage  = $scope.currentPage -1;
    if($scope.currentPage > 1){
        // $scope.currentPage = 1;
        $scope.nextDisable = false;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
        // console.log($scope.offset)
      } else if($scope.currentPage = 1){
        $scope.nextDisable = false;
        $scope.prevDisable = true;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
      }
    }
    $scope.itemByPageChange = function(){
      $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage)+1;
      if($scope.currentPage >=$scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = true;
      } else{
        $scope.nextDisable = false;
        $scope.prevDisable = false;
      }
    }
    $scope.currPageChange = function(){
      if($scope.currentPage >=$scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = false;
        $scope.currentPage = $scope.numPages;
      } else if($scope.currentPage <=1){
        $scope.prevDisable = true;
        $scope.nextDisable = false;
        $scope.currentPage = 1;
      } else{
        $scope.nextDisable = false;
        $scope.prevDisable = false;
      } 
      $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
    };


    $scope.getClients();
    $scope.modalTemplateUrl = 'app/clients/clients.modal.html';
    $scope.modalSize = 'm';
  //open modal for add Item
  $scope.add = function () {
    var modalInstance = $modal.open({
      templateUrl: $scope.modalTemplateUrl,
      controller: 'modalClients',
      size: $scope.modalSize,
      // windowClass:'devid-modal',
      resolve: {
        mData: function () {
          return false;
        }
      }
    });
    modalInstance.result.then(function (res) {
      $scope.getClients();
    });
  };
  //open modal for edit Item
  $scope.edit = function (id) {
    var modalInstance = $modal.open({
      templateUrl: $scope.modalTemplateUrl,
      controller: 'modalClients',
      size: $scope.modalSize,
      resolve: {
        mData: function () {
          return { id: id };
        }
      }
    });
    modalInstance.result.then(function (res) {
      // $scope.getClients();
      $timeout($scope.getClients(),500);
    });
  };
  $scope.clickRow = function(isClicked,id){
    // console.log(isClicked)
    if(isClicked===undefined || isClicked===false){
      $scope.edit(id);
    }
  }
  //open modal for add delete
  $scope.delete = function (id, name) {
    var modalInstance = $modal.open({
      templateUrl: 'app/app.modal.delete.html',
      controller: 'modalDelete',
      size: $scope.modalSize,
      resolve: {
        mData: function () {
          return {
            id: id,
            name: name
          };
        }
      }
    });
    modalInstance.result.then(function (res) {
      //action when delete
      var client = Clients.get({}, { id: res }, function (c) {
        if (c.clients[0].clientPicId > 1) {
          var clientPIC = ClientPIC.get();
          clientPIC.$delete({ id: c.clients[0].clientPicId });
        }
        client.$delete({ id: res }, function () {
          toastr.success('Client has been deleted', 'Clients');
          $scope.getClients();
        });
      });
    });
  };
  $scope.selectedAll = false;
  $scope.checkAll = function(){
    console.log('cek')
    $scope.selectedAll = !$scope.selectedAll;
    angular.forEach($scope.clients, function (item) {
      item.Selected = $scope.selectedAll;
    });
  };
  $scope.removeSelected = function(){
    angular.forEach($scope.clients,function(item){
      if(item.Selected){
        var i = Clients.get();
        i.$delete({id:item.id});
      }
    })
    $scope.getClients();
  };
  $scope.itemsByPage = 10;
  $scope.thead = [
  {
    title: '#',
    width: 25,
    noClick:true,
    attr: 'checklist'
  },
  {
    title: 'Group Customer',
    width: 150,
    attr: 'parentId'
  },{
    title: 'Customer\'s Category',
    width: 150,
    align:'center',
    attr: 'clientCategory'
  },
  {
    title: 'Customer Name',
    width: 150,
    attr: 'name'
  },
  {
    title: 'Address',
    width: 150,
    attr: 'address'
  },
  {
    title: 'Phone',
    width: 150,
    attr: 'phone'
  },
  {
    title: 'Segmentation',
    width: 75,
    attr: 'type'
  },
  {
    title: 'Industrial Sector',
    width: 75,
    attr: 'industrialSectorId'
  },
  {
    title: 'Kanwil',
    width: 75,
    attr: 'businessUnitCodeId'
  },
  {
    title: 'CIF',
    width: 75,
    attr: 'cif'
  },
  {
    title: 'No. Rekening',
    width: 125,
    attr: 'account'
  },
  {
    title: 'PIC Name',
    width: 175,
    attr: 'picName'
  },
  {
    title: 'PIC Position',
    width: 175,
    attr: 'picPosition'
  },
  {
    title: 'PIC Phone/Mobile',
    width: 175,
    attr: 'picPhone'
  },
  {
    title: 'PIC Email',
    width: 175,
    attr: 'picEmail'
  },
  {
    title: 'Actions',
    width: 75,
    noClick:true,
    attr: 'actions'
  }
  ];
  $scope.tableWidth = 0;
  angular.forEach($scope.thead, function (t) {
    $scope.tableWidth = $scope.tableWidth + t.width;
  });
});