'use strict';
angular.module('smoApp').config(function ($stateProvider) {
  $stateProvider.state('clients', {
    url: '/clients',
    templateUrl: 'app/clients/clients.html',
    controller: 'ClientsCtrl'
  });
});
angular.module('smoApp').controller('modalClients', function ($scope, $rootScope, $cookies, clientInformations,$timeout,$modal,$modalInstance, industrialSectors, businessUnitCodes,Clients, ClientPIC, toastr, mData) {
  $scope.input = {};
  $scope.currUser = $cookies.getObject('currentUser');
  $scope.getGroup = function(){
    Clients.getGroup({}, function (g) {
      $scope.groups = g.clients;
    });
  }
  $scope.getGroup();
  $scope.types = [
  {
    id: 'commercial',
    name: 'Commercial Department'
  },
  {
    id: 'financial',
    name: 'Financial Public Department'
  },
  {
    id: 'corporate',
    name: 'Corporate Banking'
  }
  ];
  industrialSectors.get(function(i){
    $scope.sectors = i.industrialSectors;
  });
  businessUnitCodes.getByDeptId({id:$scope.currUser.departementId},function(b){
    // console.log(b)
    $scope.bucs = b.businessUnitCodes;
  })
  $scope.pics = []
  $scope.cifs = []
  if (mData.id) {
    $scope.title = 'Edit Clients';
    //Begin Edit Modal 
    Clients.getCustomerById({}, { id: mData.id }, function (cl) {
      var c = cl.clients[0];
      // console.log(c)
      $scope.input = c;
      for(var i=0; i<$scope.groups.length;i++){
        // console.log($scope.groups[i].id)
        if($scope.groups[i].id = c.parentId){
          $scope.input.parentId = $scope.groups[i];
          break;
        }
      }
      if(c.ClientPics.length>0){
        $scope.pics = c.ClientPics;
        // console.log($scope.pics)
      }
      if(c.ClientInformations.length>0){
        $scope.cifs = c.ClientInformations;
      }
    });
    // $scope.groupNameDisable = true;
  } else {
    $scope.title = 'Add Clients';
    //Begin Add Modal
    // $scope.groupNameDisable = true;
    $scope.input.address = 'unavailable';
    $scope.input.type = 'corporate';
    $scope.input.phone = '62';
  }
  // $scope.groupChange = function () {
  //   if ($scope.input.parentId === 'other') {
  //     $scope.groupNameDisable = false;
  //   } else {
  //     $scope.groupNameDisable = true;
  //   }
  // };
  

  

  $scope.addPIC = function(){
    $scope.pics.push({name:'',position:'',email:'',phone:''});
    
  }
  
  // $scope.noRek = [{rek:''}]
  // $scope.cifs.push({});
  $scope.addCIF = function(){
    $scope.cifs.push({cif:'',account:''});
  }
  // $scope.addRek = function(){
  //   $scope.noRek.push({rek:''});
  // }
  $scope.removeCif = function(id){
    var p = $scope.cifs.splice(id,1)
  }
  // $scope.removeRek = function(id){
  //   var p = $scope.noRek.splice(id,1)
  // }
  $scope.ok = function () {
    $scope.errors = [];
    //input validation		
    if ($scope.input.name === undefined || $scope.input.name ==='')
      $scope.errors.push({ text: 'Name is required' });
    if ($scope.input.address === undefined || $scope.input.address === '')
      $scope.errors.push({ text: 'Address is required' });
    if ($scope.input.phone === undefined || $scope.input.phone ==='')
      $scope.errors.push({ text: 'Phone is required' });
    if ($scope.input.parentId === angular.noop())
      $scope.errors.push({ text: 'Group is required' });
    if ($scope.input.clientCategory === angular.noop())
      $scope.errors.push({ text: 'Customer\'s Category is required' });
    if ($scope.input.industrialSectorId === angular.noop())
      $scope.errors.push({ text: 'Industrial Sector is required' });
    if($scope.input.businessUnitCodeId ===angular.noop())
      $scope.errors.push({ text: 'Kanwil is required' });
    if ($scope.input.type === angular.noop())
      $scope.errors.push({ text: 'Segmentation is required' });
    
    angular.forEach($scope.pics,function(pic,i){
      // console.log(pic)
      if(pic.name==undefined){
        $scope.errors.push({text:'PIC '+(i+1)+'\'s name is required'})
      }
      if(pic.position==undefined){
        $scope.errors.push({text:'PIC '+(i+1)+'\'s position is required'})
      }
      if(pic.email==undefined){
        $scope.errors.push({text:'PIC '+(i+1)+'\'s email is required/invalid'})
      }
      if(pic.phone==undefined){
        $scope.errors.push({text:'PIC '+(i+1)+'\'s phone is required/invalid'})
      }
    })
    if ($scope.errors.length === 0) {
      //console.log('save')
      $scope.errors = undefined;
      var client = Clients.get();
      client.name = $scope.input.name;
      client.address = $scope.input.address;
      client.clientCategory = $scope.input.clientCategory;
      client.parentId = $scope.input.parentId.id;
      client.type = $scope.input.type;
      client.phone = $scope.input.phone;
      client.industrialSectorId = $scope.input.industrialSectorId;
      client.businessUnitCodeId = $scope.input.businessUnitCodeId;
      if(mData.id){
          // console.log('update')
          client.$update({id:mData.id},function(g){
            if($scope.pics.length>0){
              angular.forEach($scope.pics,function(p){
                var pic = ClientPIC.get();
                pic.name = p.name;
                pic.email = p.email;
                pic.phone = p.phone;
                pic.position = p.position;
                if(p.id){
                  pic.$update({id:p.id},function(){
                    return true;
                  }, function(){
                     toastr.error('Customer\'s PIC can\'t be saved','Internal Server Error');
                  })
                } else {
                  pic.clientId = mData.id;
                  pic.$save(function(){
                     return true;
                  },function(){
                      toastr.error('Customer\'s PIC can\'t be saved','Internal Server Error');
                  })
                }              
              })
            }
            if($scope.cifs.length>0){
              angular.forEach($scope.cifs,function(cf){
                var cif = clientInformations.get();
                cif.cif = cf.cif;
                cif.account = cf.account;
                if(cf.id){
                  cif.$update({id:cf.id},function(){
                    return true;
                  }, function(){
                     toastr.error('Customer\'s Informations can\'t be saved','Internal Server Error');
                  })
                } else {
                  cif.clientId = mData.id;
                  cif.$save(function(){
                     return true;
                  },function(){
                      toastr.error('Customer\'s Informations can\'t be saved','Internal Server Error');
                  })
                }       
              });
            }
            toastr.success('Customer '+$scope.input.name+' has been successfuly updated','Success');
            $modalInstance.close(); 
         },function(){
            toastr.error('Customer '+$scope.input.name+' can\'t be saved','Internal Server Error');
            $modalInstance.close();
         })
        } else {
          // console.log('save')
          client.$save(function(c){
            $scope.clientId = c.clients[0].id;
            $scope.bulkPics = []
            if($scope.pics.length>0){
              angular.forEach($scope.pics,function(p){
                $scope.bulkPics.push({
                  'name':p.name,
                  'email':p.email,
                  'phone':p.phone,
                  'position':p.position,
                  'clientId':$scope.clientId
                })
                // console.log($scope.clientId)
                // var pic = ClientPIC.get();
                // pic.name = p.name;
                // pic.email = p.email;
                // pic.phone = p.phone;
                // pic.position = p.position;
                // pic.clientId = $scope.clientId;
                // pic.$save(function(){
                //   return true
                // },function(){
                //   toastr.error('Customer\'s PIC can\'t be saved','Internal Server Error');
                // })
              })
              $timeout(function(){
                ClientPIC.postBulk($scope.bulkPics, function(){
                  return true;
                }, function(){
                  toastr.error('Customer\'s PIC can\'t be saved','Internal Server Error');
                })
              })
            } 
            $scope.bulkCifs = []
            if($scope.cifs.length>0){
              angular.forEach($scope.cifs,function(cf){
                $scope.bulkCifs.push({
                  'cif': cf.cif,
                  'account':cf.account,
                  'clientId':$scope.clientId
                })
              })
              $timeout(function(){
                clientInformations.postBulk($scope.bulkCifs, function(){
                  return true;
                }, function(){
                  toastr.error('Customer\'s Informations can\'t be saved','Internal Server Error');
                })
              });
            }
            toastr.success('Customer '+$scope.input.name+' has been successfuly added','Success');
            $modalInstance.close();
          },function(){
            toastr.error('Customer '+$scope.input.name+' can\'t be saved','Internal Server Error');
            $modalInstance.close();
          })
        }
      };
    };
    $scope.remove = function(id){
      var p = $scope.pics.splice(id,1)
    // console.log(p)
  }
  $scope.createGroup = function () {
    var modalInstance = $modal.open({
      templateUrl: 'app/clients/clients.modal.group.html',
      controller: 'modalCreateGroups',
      size: 'sm',
      // windowClass:'devid-modal',
      resolve: {
        mData: function () {
          return {groups:$scope.groups}
        }
      }
    });
    modalInstance.result.then(function (res) {
      $scope.getGroup();
    });
  };
  $scope.cancel = function () {
    $modalInstance.dismiss('cancel');
  };
});
angular.module('smoApp').controller('modalCreateGroups', function ($scope, $timeout,$rootScope, $cookies, $modalInstance, Clients, ClientPIC, toastr, mData) {
  $scope.input = {};
  $scope.title = 'Create Groups';
  $scope.currUser = $cookies.getObject('currentUser');
  $scope.groups = mData.groups;
  $scope.getGroup = function(){
    Clients.getGroup({}, function (g) {
      $scope.groups = g.clients;
    });
  }
  // $scope.getGroup();
  $scope.delete = function(id){
    var groups = Clients.get();
    // console.log(id)
    groups.$delete({id:id},function(){
      $scope.getGroup();
    })
  }
  $scope.ok = function () {
    var g = Clients.get();
    g.name = $scope.input.name;
    g.parentId = null;
    g.address = 'kosong';
    g.phone = '62';
    g.businessUnitCodeId = 1;
    g.industrialSectorId = 1;
    g.industryCategories = ' ';
    // g.cif = 'kosong';
    g.clientCategory = 'gold';
    g.type = 'corporate';
    g.$save(function(){
      toastr.success('Group '+$scope.input.name+' has been successfuly added','Success');
      $modalInstance.close();
    },function(){
      toastr.error('Your group can\'t be saved','Internal Server Error');
      $modalInstance.close();
    })
  };
  $scope.gname = function(){
    $timeout(function(){
      for(var i=0; i<$scope.groups.length;i++){
        if($scope.input.name==$scope.groups[i].name){
          $scope.isAvailable = true;
          break;
        } 
        $scope.isAvailable = false;
      }
      // console.log($scope.isAvailable)
    },1000)
  }
  $scope.cancel = function () {
    $modalInstance.dismiss('cancel');
  };
});