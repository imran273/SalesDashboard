'use strict';
angular.module('smoApp').controller('StatusCtrl', function ($scope, $rootScope, $cookies, $http, $modal, Auth, Status, $location, toastr) {
  $location.path(Auth.isLogin() ? 'login' : 'status');
  $scope.page = {
    title: 'Status',
    desc: 'Status Management'
  };
  // $scope.currUser = $cookies.getObject('currentUser');

  $scope.getStatus = function () {
    // if ($scope.currUser.roleId === 4 || $scope.currUser.roleId === 5 || $scope.currUser.roleId === 3) {
    //   Status.get(function (s) {
    //     $scope.stat = s.products;
    //     $scope.dtCount = s.count;
    //     $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage)+1;
    //     $scope.offset = 0;
    //   });
    // } else {
    //   Status.get(function (s) {
    //     $scope.stat = s.products;
    //     $scope.dtCount = s.count;
    //     $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage);
    //     $scope.offset = 0;
    //   });
    // }
    Status.get(function (s) {
        $scope.stat = s.status;
        $scope.dtCount = s.count;
        $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage)+1;
        $scope.offset = 0;
      });
  };

  $scope.currentPage = 1;
  $scope.prevDisable = true;
  // console.log($scope.currentPage);
  $scope.next = function(){
    $scope.currentPage  = $scope.currentPage + 1;
    if($scope.currentPage < $scope.numPages){
        // $scope.currentPage = $scope.numPages;
        $scope.nextDisable = false;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
        // console.log($scope.offset);
    } else if($scope.currentPage = $scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
    }else{
      $scope.nextDisable = false;
      $scope.prevDisable = false;
    }
    // console.log($scope.currentPage);
    // console.log($scope.numPages);
  }
  $scope.prev = function(){
    $scope.currentPage  = $scope.currentPage -1;
    if($scope.currentPage > 1){
        // $scope.currentPage = 1;
        $scope.nextDisable = false;
        $scope.prevDisable = false;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
        // console.log($scope.offset)
    } else if($scope.currentPage = 1){
        $scope.nextDisable = false;
        $scope.prevDisable = true;
        $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
    }
  }
  $scope.itemByPageChange = function(){
    $scope.numPages = parseInt($scope.dtCount /$scope.itemsByPage)+1;
    if($scope.currentPage >=$scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = true;
    } else{
        $scope.nextDisable = false;
        $scope.prevDisable = false;
    }
  }
  $scope.currPageChange = function(){
    if($scope.currentPage >=$scope.numPages){
        $scope.nextDisable = true;
        $scope.prevDisable = false;
        $scope.currentPage = $scope.numPages;
    } else if($scope.currentPage <=1){
        $scope.prevDisable = true;
        $scope.nextDisable = false;
        $scope.currentPage = 1;
    } else{
        $scope.nextDisable = false;
        $scope.prevDisable = false;
    } 
    $scope.offset = ($scope.currentPage-1) * $scope.itemsByPage;
  };
// 
  $scope.getStatus();
  $scope.modalTemplateUrl = 'app/status/status.modal.html';
  $scope.modalSize = 'm';
  //open modal for add item
  $scope.add = function () {
    var modalInstance = $modal.open({
      templateUrl: $scope.modalTemplateUrl,
      controller: 'modalStatus',
      size: $scope.modalSize,
      // windowClass:'devid-modal',
      resolve: {
        mData: function () {
          return false;
        }
      }
    });
    modalInstance.result.then(function (res) {
      $scope.getStatus();
    });
  };
  //open modal for edit Item
  $scope.edit = function (id) {
    var modalInstance = $modal.open({
      templateUrl: $scope.modalTemplateUrl,
      controller: 'modalStatus',
      size: $scope.modalSize,
      resolve: {
        mData: function () {
          return { id: id };
        }
      }
    });
    modalInstance.result.then(function (res) {
      $scope.getStatus();
    });
  };
  //open modal for add delete
  $scope.delete = function (id, name) {
    var modalInstance = $modal.open({
      templateUrl: 'app/app.modal.delete.html',
      controller: 'modalDelete',
      size: $scope.modalSize,
      resolve: {
        mData: function () {
          return {
            id: id,
            name: name
          };
        }
      }
    });
    modalInstance.result.then(function (res) {
      var status = Status.get();
      status.$delete({ id: res }, function (u) {
        toastr.success('Status has been deleted', 'Status');
        $scope.getStatus();
      });
    });
  };
  $scope.selectedAll = false;
  $scope.checkAll = function(){
    // console.log('cek')
    $scope.selectedAll = !$scope.selectedAll;
    angular.forEach($scope.stat, function (item) {
      item.Selected = $scope.selectedAll;
    });
  };
  $scope.removeSelected = function(){
    angular.forEach($scope.stat,function (item){
      if(item.Selected){
        var i = Status.get();
        i.$delete({id:item.id});
      }
    })
    $scope.getStatus();
  };
  $scope.itemsByPage = 10;
  $scope.thead = [
    {
      title: '#',
      width: 25,
      noClick:true,
      attr: 'checklist'
    },
    {
      title: 'Name',
      width: 200,
      align: 'center',
      attr: 'name'
    },
    {
      title: 'Last Update',
      width: 100,
      align: 'center',
      attr: 'updatedAt'
    },
    {
      title: 'Actions',
      width: 100,
      align: 'center',
      attr: 'actions'
    }
  ];
  $scope.tableWidth = 0;
  angular.forEach($scope.thead, function (t) {
    $scope.tableWidth = $scope.tableWidth + t.width;
  });
});
