'use strict';
angular.module('smoApp').config(function ($stateProvider) {
  $stateProvider.state('status', {
    url: '/status',
    templateUrl: 'app/status/status.html',
    controller: 'StatusCtrl'
  });
});
angular.module('smoApp').controller('modalStatus', function ($scope, $rootScope, $modalInstance, Status, toastr, mData) {
  $scope.input = {};
  if (mData.id) {
    $scope.title = 'Edit Status';
    Status.get({}, { id: mData.id }, function (u) {
      // console.log(u)
      $scope.input = u.status[0];
    });
  } else {
    $scope.title = 'Add Status'  //Begin Add Modal
;
  }
  $scope.ok = function () {
    $scope.errors = [];
    //input validation		
    if ($scope.input.name === angular.noop())
      $scope.errors.push({ text: 'Name is required' });
    if ($scope.errors.length === 0) {
      console.log('save');
      $scope.errors = undefined;
      var status = Status.get();
      status.name = $scope.input.name;
      if (mData.id) {
        status.$update({ id: mData.id }, function (res) {
          //console.log(res)
          toastr.success($scope.input.name + ' has been updated!', 'Status');
          $modalInstance.close();
        });
      } else {
        status.$save(function (res) {
          // console.log(res)
          toastr.success($scope.input.name + ' has been added!', 'Status');
          $modalInstance.close();
        });
      }
    }
  };
  $scope.cancel = function () {
    $modalInstance.dismiss('cancel');
  };
});