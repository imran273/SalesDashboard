'use strict';
angular.module('smoApp').controller('MainCtrl', function ($scope, $http, $filter, $location,Sales, Auth, $cookies,CallReports,Realizations) {
  $location.path(Auth.isLogin() ? 'login' : '/');
  $scope.currUser = $cookies.getObject('currentUser');
  // console.log($scope.currUser)
  $scope.page = {
    title: 'Dashboard',
    desc: 'Executive Summary'
  };
  if($scope.currUser.roleId===4){
    $scope.dashboardSales = true;
    $scope.dashboardHead = false;
  } else{
    $scope.dashboardSales = false;
    $scope.dashboardHead = true;
  }
  $scope.center = {
    lat: 6.175,
    lng: 106.8283,
    zoom: 4
  };
  $scope.markers = [];
  $scope.getLocationByDept = function(){
     Sales.getByDeptId({},{id:$scope.currUser.departementId},function(s){
        angular.forEach(s.sales,function(u){
          Realizations.getJoinBySalesId({},{salesId:u.id},function(r){
             var lastRow = r.realizations.length -1;
             // console.log(lastRow)
             if(lastRow>=0){
                var lat = r.realizations[lastRow].lat;
                var lng = r.realizations[lastRow].lng;
                $scope.markers.push({
                  lat: lat,
                  lng:lng,
                  message: u.name,
                  draggable:false
                })
             }
          })
        })
     })
  }
  $scope.getLocationByDept();
  $scope.getTopSales = function(){
    Sales.getPerformance(function(s){
      $scope.topSales = s.statistics;
      // console.log($scope.topSales)
    })
  }
  $scope.getTopSales();
  $scope.getReportStatByDept = function(){
   CallReports.getStatByDept({},{deptId:$scope.currUser.departementId,date:moment().format('YYYY-MM-DD HH:mm:ss')},function(stat){
    // console.log(stat);
   })
  }
   $scope.getReportStatByDept();
});