'use strict';
angular.module('smoApp').controller('SalesheadCtrl', function ($scope, $rootScope, $cookies, Auth, Sales, $modal, $location, toastr) {
  $location.path(Auth.isLogin() ? 'login' : 'saleshead');
  $scope.page = {
    title: 'Sales Head Summary',
    desc: ''
  };
});