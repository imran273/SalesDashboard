'use strict';
angular.module('smoApp').config(function ($stateProvider) {
  $stateProvider.state('saleshead', {
    url: '/saleshead',
    templateUrl: 'app/saleshead/saleshead.html',
    controller: 'SalesheadCtrl'
  });
});