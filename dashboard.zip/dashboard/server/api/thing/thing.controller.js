/**
 * Using Rails-like standard naming convention for endpoints.
 * GET     /things              ->  index
 * POST    /things              ->  create
 * GET     /things/:id          ->  show
 * PUT     /things/:id          ->  update
 * DELETE  /things/:id          ->  destroy
 */

 'use strict';

 var _ = require('lodash');

// Get list of things
exports.index = function(req, res) {
  
       

};
exports.auth = function(req, res){
  //console.log(req.body)
  var http = require('http');
  var postData = req.body;

  var options = {
    hostname: '45.64.96.237',
    agent:false,
    port: 3000,
    path: '/auth/login',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json', 
      'Auth-Key':'098m4dD0g6123geT!@#$'
    },    
  };

  var reqOut = http.request(options, function(resOut) {
    // console.log('STATUS: ' + resOut.statusCode);
    //console.log('HEADERS: ' + JSON.stringify(resOut.headers));
    resOut.setEncoding('utf8');
    resOut.on('data', function (data) {
      //console.log('BODY: ' + data);
      res.json(JSON.parse(data).users[0])
    });
  });

  reqOut.on('error', function(e) {
    // res.json(JSON.parse(e));
  });
  reqOut.on('timeout', function () {
    // res.json({'error':'Request timeout'})
    reqOut.abort();
  });

  reqOut.setTimeout(5000);
  // write data to request body
  reqOut.write(JSON.stringify(postData));
  reqOut.end();

}