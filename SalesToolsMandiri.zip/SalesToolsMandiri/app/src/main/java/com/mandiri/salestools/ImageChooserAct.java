package com.mandiri.salestools;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.GridView;

import com.balysv.materialmenu.MaterialMenuDrawable;
import com.mandiri.salestools.adapter.PhoneGalleryAdapter;
import com.mandiri.salestools.fragments.BaseFragment;
import com.mandiri.salestools.fragments.dialog.AlertDialogFragment;
import com.mandiri.salestools.model.DeviceImage;
import com.mandiri.salestools.utils.FileUtils;
import com.mandiri.salestools.utils.helper.MediaStoreHelper;
import com.mandiri.salestools.widget.HeaderGridView;

import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnItemClick;

/**
 * Created by esa on 18/03/15, with awesomeness
 */
public class ImageChooserAct extends BaseActivity {

	public static final String ARG_IMAGE_RESULT = "image_result";
	public static final String ARG_ACTIVITY = "is_activity";
	public static final int REQ_CODE = 29;
	@InjectView(R.id.lvContent)
	HeaderGridView mLvContent;

	private Handler mHandler = new Handler(Looper.getMainLooper());

	private PhoneGalleryAdapter mListAdapter;
	private DeviceImage mDeviceImage;
	private boolean isAct;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_social_image_chooser);
		ButterKnife.inject(this);
		setupGridView();
		materialMenuIcon.setState(MaterialMenuDrawable.IconState.ARROW);

		Intent intent = getIntent();
		isAct = intent.getBooleanExtra(ARG_ACTIVITY, false);
	}

	private void setupGridView() {

		final Point point = new Point();
		getWindowManager().getDefaultDisplay().getSize(point);

		new Thread(new Runnable() {
			@Override
			public void run() {
				final List<DeviceImage> deviceImages = MediaStoreHelper.getDeviceImages(ImageChooserAct.this);
				mHandler.post(new Runnable() {
					@Override
					public void run() {
						mListAdapter = new PhoneGalleryAdapter(mLvContent, true, point.x / 3, null);

						View headerPlaceHolder = getLayoutInflater().inflate(R.layout.list_item_phone_gallery_camera, mLvContent, false);
						headerPlaceHolder.setPadding(headerPlaceHolder.getPaddingLeft(), headerPlaceHolder.getPaddingTop(), headerPlaceHolder.getPaddingLeft(), headerPlaceHolder.getPaddingBottom());
						headerPlaceHolder.setLayoutParams(new GridView.LayoutParams(point.x, point.x / 2));
						FrameLayout container = (FrameLayout) headerPlaceHolder.findViewById(R.id.lyContainer);
						container.addView(mListAdapter.getCameraPreview());

						mLvContent.addHeaderView(headerPlaceHolder, null, true);
						mLvContent.setAdapter(mListAdapter);
						mListAdapter.pushData(deviceImages);
					}
				});
			}
		}).start();
	}

	@OnItemClick(R.id.lvContent)
	public void onItemGridClick(int position) {
		if (position == 0) {
			takeImage();
			return;
		}

		position = position - mLvContent.getNumColumns() + mLvContent.getHeaderViewCount();
		DeviceImage deviceImage = mListAdapter.getItem(position);
		if (deviceImage.isCoruppted())
			showCorupptedAlertDialog();
		else {
			Intent data = new Intent();
			data.putExtra(ARG_IMAGE_RESULT, deviceImage);
			if (isAct)
				setResult(RESULT_OK, data);
			else
				setResult(RESULT_OK, data);
			finish();
		}
	}

	private void takeImage() {
		mListAdapter.releaseCamera();
		Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		intent.putExtra(MediaStore.EXTRA_OUTPUT, FileUtils.getTempUri(ImageChooserAct.this));
		intent.putExtra("return-data", "true");
		startActivityForResult(intent, 0x123);
	}

	private void showCorupptedAlertDialog() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage(getString(R.string.medianotfound));
		builder.setPositiveButton("OK", null);

		AlertDialogFragment alertDialogFragment = AlertDialogFragment.newInstance();
		alertDialogFragment.setDialog(builder.create());
		alertDialogFragment.show(getSupportFragmentManager(), AlertDialogFragment.TAG);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == RESULT_OK && requestCode == 0x123) {
			DeviceImage deviceImage = new DeviceImage();
			deviceImage.setFilePath(FileUtils.getTempFile(this).getPath());

			data = new Intent();
			data.putExtra(ARG_IMAGE_RESULT, deviceImage);
			if (isAct)
				setResult(RESULT_OK, data);
			else
				setResult(RESULT_OK, data);
			finish();
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case android.R.id.home:
				finish();
				break;
		}
		return super.onOptionsItemSelected(item);
	}

	public static void startActivityForResult(BaseFragment ctx) {
		Intent intent = new Intent(ctx.getActivity(), ImageChooserAct.class);
		ctx.startActivityForResult(intent, ImageChooserAct.REQ_CODE);
	}

	public static void startActivityForResult(Activity ctx) {
		Intent intent = new Intent(ctx, ImageChooserAct.class);
		intent.putExtra(ARG_ACTIVITY, true);
		ctx.startActivityForResult(intent, ImageChooserAct.REQ_CODE);
	}
}
