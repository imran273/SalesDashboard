package com.mandiri.salestools.apiservice;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import com.loopj.android.http.TextHttpResponseHandler;
import com.mandiri.salestools.constants.URLCons;
import com.mandiri.salestools.http.MandiriClient;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.users.User;
import com.mandiri.salestools.model.users.UserDao;
import com.mandiri.salestools.utils.CommonUtils;
import com.mandiri.salestools.utils.Logger;
import com.mandiri.salestools.utils.Preferences;

import org.apache.http.Header;
import org.json.JSONObject;

public class AuthApiService extends BaseApiService {

	public AuthApiService(Context mContext) {
		super(mContext);
	}

	public void doLogin(final String email, final String password,
	                    final EventCallback<User> eventCallback) {

		JSONObject jsonObject = new JSONObject();
		try {
			jsonObject.put("email", email);
			jsonObject.put("password", CommonUtils.md5SHA1(password));
		} catch (Exception e) {
			Logger.log(e);
		}

		MandiriClient.postJSON(mContext, URLCons.AUTH_LOGIN, jsonObject.toString(), new TextHttpResponseHandler() {
			@Override
			public void onSuccess(int statusCode, Header[] headers, String response) {
				Logger.log(Log.DEBUG, "Response :" + response);
				try {
					UserDao userDao = getGson().fromJson(response, UserDao.class);
					if (userDao.getError().getMessage() == null) {
						User user = userDao.getUsers().get(0);

                        if (user.getRole().equals("Sales")){
                            Preferences.saveProfile(mContext, getGson().toJson(user));

                            Preferences.saveUserId(mContext, user.getUserId());
                            Preferences.saveName(mContext, user.getName());
                            Preferences.saveEmail(mContext, user.getEmail());
                            Preferences.saveRole(mContext, user.getRole());
                            Preferences.saveRoleId(mContext, user.getRoleId());
                            Preferences.saveSalesId(mContext, user.getSalesId());
                            Preferences.saveDepartementId(mContext, user.getDepartementId());
                            Preferences.saveToken(mContext, user.getToken());

                            eventCallback.onEvent(user);
                        } else {
                            Bundle bundle = new Bundle();
                            bundle.putString("message", "Maaf, aplikasi ini hanya untuk sales.");

                            eventCallback.onEvent(null, bundle);
                        }
					} else {
						eventCallback.onEvent(null);
					}
				} catch (Exception e) {
					onFailure(statusCode, headers, response, e);
				}
			}

			@Override
			public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
				Logger.log(throwable);
				eventCallback.onEvent(null);
			}
		});
	}

}
