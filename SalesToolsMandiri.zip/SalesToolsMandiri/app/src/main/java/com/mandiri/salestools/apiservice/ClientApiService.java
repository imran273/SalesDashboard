package com.mandiri.salestools.apiservice;

import android.content.Context;
import android.os.Bundle;

import com.loopj.android.http.TextHttpResponseHandler;
import com.mandiri.salestools.constants.ApiCons;
import com.mandiri.salestools.constants.URLCons;
import com.mandiri.salestools.http.MandiriClient;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.clients.Client;
import com.mandiri.salestools.model.clients.ClientResponse;

import org.apache.http.Header;

import java.util.List;

/**
 * Created by esa on 09/06/15, with awesomeness
 */
public class ClientApiService extends BaseApiService {

	public ClientApiService(Context mContext) {
		super(mContext);
	}

	public void loadClient(String clientId, final EventCallback<List<Client>> eventCallback) {
		String url = URLCons.CLIENTS + "/" + clientId;
		MandiriClient.get(mContext, url, new TextHttpResponseHandler() {
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                onHandleError(eventCallback, throwable);
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, String responseString) {
                onHandleSuccess(responseString);
                ClientResponse clientResponse = getGson().fromJson(responseString, ClientResponse.class);
                if (clientResponse.getError().isNotError()) {
                    eventCallback.onEvent(clientResponse.getClients());
                } else
                    onFailure(statusCode, null, responseString, new Exception(clientResponse
                            .getError().getMessage()));
            }
        });
	}

	public void loadClients(final EventCallback<List<Client>> eventCallback) {
		MandiriClient.get(mContext, URLCons.CLIENTS, new TextHttpResponseHandler() {
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                onHandleError(eventCallback, throwable);
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, String responseString) {
                onHandleSuccess(responseString);
                ClientResponse clientResponse = getGson().fromJson(responseString, ClientResponse.class);
                if (clientResponse.getError().isNotError()) {
                    eventCallback.onEvent(clientResponse.getClients());
                } else
                    onFailure(statusCode, null, responseString, new Exception(clientResponse
                            .getError().getMessage()));

            }
        });
	}

	public void loadClientsWeb(final EventCallback<List<Client>> eventCallback) {
        String URL = URLCons.CLIENTS;
        //http://103.23.22.220:3000/api/v1/clients?join[model]=ClientPic&q[parentId][$not]=NULL
        URL = URL + "?join[model]=ClientPic&q[parentId][$not]=NULL";
		MandiriClient.get(mContext, URL, new TextHttpResponseHandler() {
			@Override
			public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
				onHandleError(eventCallback, throwable);
			}

			@Override
			public void onSuccess(int statusCode, Header[] headers, String responseString) {
				onHandleSuccess(responseString);
				ClientResponse clientResponse = getGson().fromJson(responseString, ClientResponse.class);
				if (clientResponse.getError().isNotError()) {
					eventCallback.onEvent(clientResponse.getClients());
				} else
					onFailure(statusCode, null, responseString, new Exception(clientResponse
							.getError().getMessage()));

			}
		});
	}

	public void addClient(final Client client, final EventCallback<Boolean> eventCallback) {
		String json = getGson().toJson(client);

		MandiriClient.postJSON(mContext, URLCons.CLIENTS, json, new TextHttpResponseHandler() {
			@Override
			public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
				onHandleError(eventCallback, throwable);
			}

			@Override
			public void onSuccess(int statusCode, Header[] headers, String responseString) {
				onHandleSuccess(responseString);

				ClientResponse clientResponse = getGson().fromJson(responseString, ClientResponse.class);
				if (clientResponse.getError().isNotError()) {

					Bundle bundle = new Bundle();
					bundle.putParcelable(Client.class.getSimpleName(), clientResponse.getClients().get(0));
					bundle.putInt(ApiCons.STATUS_CODE, statusCode);
					eventCallback.onEvent(true, bundle);

				} else
					onFailure(statusCode, null, responseString, new Exception(clientResponse
							.getError().getMessage()));

			}
		});
	}
}
