package com.mandiri.salestools.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.mandiri.salestools.R;
import com.mandiri.salestools.activities.add.AddProductAct;
import com.mandiri.salestools.activities.add.BaseInputAct;
import com.mandiri.salestools.adapter.BaseListAdapter;
import com.mandiri.salestools.apiservice.ProductApiService;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.products.Product;
import com.mandiri.salestools.utils.CommonUtils;

import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

/**
 * Created by esa on 09/06/15, with awesomeness
 */
public class ProductListFragment extends BaseFragment {

	@InjectView(R.id.lyRefresh) SwipeRefreshLayout mSwipeRefreshLayout;
	@InjectView(R.id.lvContent) ListView mLvContent;
	@InjectView(R.id.pbLoad) ProgressBar mPbLoad;
	@InjectView(R.id.txtNoData) TextView mTxtNoData;

	private ProductApiService mApiService;
	private ProductListAdapter mListAdapter;

	public static ProductListFragment newInstance() {
		return new ProductListFragment();
	}

	@Override
	public void onCreate(@Nullable Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);
		getActionBar().setTitle(R.string.products);
	}

	@Nullable
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = mInflater.inflate(R.layout.fragment_common_list, container, false);
		ButterKnife.inject(this, view);
		return view;
	}

	@Override
	public void onActivityCreated(@Nullable Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		mListAdapter = new ProductListAdapter(mContext);
		mLvContent.setAdapter(mListAdapter);

		mSwipeRefreshLayout.setColorSchemeResources(R.color.primary);
		mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
			@Override
			public void onRefresh() {
				loadData();
			}
		});
		loadData();
	}

	private void loadData() {
		if (mApiService == null)
			mApiService = new ProductApiService(mContext);
		mApiService.loadProducts(new EventCallback<List<Product>>() {
			@Override
			public void onEvent(List<Product> data, Bundle bundle) {
				resetLoadingUI();
				if (data == null) {
					CommonUtils.toastShort(mContext, R.string.error_string);
                    mTxtNoData.setVisibility(View.VISIBLE);
					return;
				}
                if (data.size() == 0){
                    mTxtNoData.setVisibility(View.VISIBLE);
                    return;
                }
                mTxtNoData.setVisibility(View.GONE);
				mListAdapter.pushData(data);
			}
		});

	}

	private void resetLoadingUI() {
		mSwipeRefreshLayout.setRefreshing(false);
		mPbLoad.setVisibility(View.GONE);
	}

	@OnClick(R.id.btnSubmit)
	public void onAddClick() {
		AddProductAct.startForResult(this);
	}

	@Override
	public void onDestroyView() {
		super.onDestroyView();
		ButterKnife.reset(this);
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == Activity.RESULT_OK && requestCode == BaseInputAct.BASE_INPUT_CODE) {
			Product product = data.getExtras().getParcelable(Product.class.getSimpleName());
			mListAdapter.getListData().add(product);
			mListAdapter.notifyDataSetChanged();
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	private class ProductListAdapter extends BaseListAdapter<Product> {

		public ProductListAdapter(Context context) {
			super(context);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {

			if (convertView == null)
				convertView = mInflater.inflate(R.layout.list_item_product, parent, false);

            Product item = mListData.get(position);

			ProductViewHolder viewHolder = ProductViewHolder.getInstance(convertView);
			viewHolder.mTxtTitle.setText(item.getName());
			viewHolder.mTxtSubTitle.setText(item.getDescription());
			viewHolder.mTxtCategory.setText(item.getUpdatedAt());

			return convertView;
		}
	}

	static class ProductViewHolder {

		@InjectView(R.id.txtTitle) TextView mTxtTitle;
        @InjectView(R.id.txtSubTitle) TextView mTxtSubTitle;
        @InjectView(R.id.txtPhone) TextView mTxtCategory;

		public ProductViewHolder(View view) {
			ButterKnife.inject(this, view);
			view.setTag(this);
		}

		static ProductViewHolder getInstance(View view) {
			if (view.getTag() != null)
				return (ProductViewHolder) view.getTag();
			return new ProductViewHolder(view);
		}
	}
}
