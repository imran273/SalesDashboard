package com.mandiri.salestools.model.pic;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by esa on 11/06/15, with awesomeness
 */
public class PIC implements Parcelable {

	/**
	 * createdAt : 2015-06-08T19:07:19.000Z
	 * deletedAt : null
	 * phone : 0000
	 * name : NN
	 * id : 1
	 * updatedAt : 2015-06-08T19:07:19.000Z
	 */
	private String createdAt;
	private String deletedAt;
	private String phone;
	private String name;
	private String email;
	private String position;
	private String clientId;
	private int id;
	private String updatedAt;

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public void setDeletedAt(String deletedAt) {
		this.deletedAt = deletedAt;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public String getDeletedAt() {
		return deletedAt;
	}

	public String getPhone() {
		return phone;
	}

	public String getName() {
		return name;
	}

	public int getId() {
		return id;
	}

	public String getUpdatedAt() {
		return updatedAt;
	}

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(this.createdAt);
		dest.writeString(this.deletedAt);
		dest.writeString(this.phone);
		dest.writeString(this.name);
		dest.writeInt(this.id);
		dest.writeString(this.updatedAt);
		dest.writeString(this.email);
		dest.writeString(this.position);
		dest.writeString(this.clientId);
	}

	public PIC() {
	}

	protected PIC(Parcel in) {
		this.createdAt = in.readString();
		this.deletedAt = in.readString();
		this.phone = in.readString();
		this.name = in.readString();
		this.id = in.readInt();
		this.updatedAt = in.readString();
		this.email = in.readString();
		this.position = in.readString();
		this.clientId = in.readString();
	}

	public static final Parcelable.Creator<PIC> CREATOR = new Parcelable.Creator<PIC>() {
		public PIC createFromParcel(Parcel source) {
			return new PIC(source);
		}

		public PIC[] newArray(int size) {
			return new PIC[size];
		}
	};

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
}
