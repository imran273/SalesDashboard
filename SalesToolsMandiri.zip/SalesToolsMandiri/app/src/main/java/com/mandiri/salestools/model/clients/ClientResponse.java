package com.mandiri.salestools.model.clients;

import android.os.Parcel;

import com.mandiri.salestools.model.BaseDao;

import java.util.List;

/**
 * Created by esa on 04/06/15, with awesomeness
 */
public class ClientResponse extends BaseDao {

	public List<Client> getClients() {
		return clients;
	}

	public void setClients(List<Client> clients) {
		this.clients = clients;
	}

	private List<Client> clients;

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		super.writeToParcel(dest, flags);
		dest.writeTypedList(clients);
	}

	public ClientResponse() {
	}

	protected ClientResponse(Parcel in) {
		this.clients = in.createTypedArrayList(Client.CREATOR);
	}

	public static final Creator<ClientResponse> CREATOR = new Creator<ClientResponse>() {
		public ClientResponse createFromParcel(Parcel source) {
			return new ClientResponse(source);
		}

		public ClientResponse[] newArray(int size) {
			return new ClientResponse[size];
		}
	};
}
