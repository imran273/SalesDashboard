package com.mandiri.salestools.model.division;

import android.os.Parcel;
import android.os.Parcelable;

public class Division implements Parcelable {

    /**
     * createdAt : 2015-06-08T19:07:19.000Z
     * deletedAt : null
     * name : Non Divisi [Admin]
     * id : 1
     * updatedAt : 2015-06-08T19:07:19.000Z
     */
    private String createdAt;
    private String deletedAt;
    private String name;
    private int id;
    private String updatedAt;

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public void setDeletedAt(String deletedAt) {
        this.deletedAt = deletedAt;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public String getDeletedAt() {
        return deletedAt;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.createdAt);
        dest.writeString(this.deletedAt);
        dest.writeString(this.name);
        dest.writeInt(this.id);
        dest.writeString(this.updatedAt);
    }

    public Division() {
    }

    protected Division(Parcel in) {
        this.createdAt = in.readString();
        this.deletedAt = in.readString();
        this.name = in.readString();
        this.id = in.readInt();
        this.updatedAt = in.readString();
    }

    public static final Creator<Division> CREATOR = new Creator<Division>() {
        public Division createFromParcel(Parcel source) {
            return new Division(source);
        }

        public Division[] newArray(int size) {
            return new Division[size];
        }
    };
}