package com.mandiri.salestools.apiservice;

import android.content.Context;
import android.os.Bundle;

import com.loopj.android.http.TextHttpResponseHandler;
import com.mandiri.salestools.constants.ApiCons;
import com.mandiri.salestools.constants.URLCons;
import com.mandiri.salestools.http.MandiriClient;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.pic.PIC;
import com.mandiri.salestools.model.pic.PICResponse;

import org.apache.http.Header;

import java.util.List;

/**
 * Created by esa on 11/06/15, with awesomeness
 */
public class PicApiService extends BaseApiService {

	public PicApiService(Context mContext) {
		super(mContext);
	}

	public void loadPIC(final EventCallback<List<PIC>> eventCallback) {
		MandiriClient.get(mContext, URLCons.CLIENT_PICS, new TextHttpResponseHandler() {
			@Override
			public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
				onHandleError(eventCallback, throwable);
			}

			@Override
			public void onSuccess(int statusCode, Header[] headers, String responseString) {
				onHandleSuccess(responseString);

				PICResponse response = getGson().fromJson(responseString, PICResponse.class);
				if (response.getError().isNotError()) {
					eventCallback.onEvent(response.getPicList());
				} else
					onFailure(statusCode, null, responseString, new Exception(response.getError
							  ().getMessage()));
			}
		});
	}

	public void addPIC(PIC pic, final EventCallback<Boolean> eventCallback) {
		String json = getGson().toJson(pic);
		MandiriClient.postJSON(mContext, URLCons.CLIENT_PICS, json, new TextHttpResponseHandler() {
			@Override
			public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
				onHandleError(eventCallback, throwable);
			}

			@Override
			public void onSuccess(int statusCode, Header[] headers, String responseString) {
				onHandleSuccess(responseString);

				PICResponse response = getGson().fromJson(responseString, PICResponse.class);
				if (response.getError().isNotError()) {

					Bundle bundle = new Bundle();
					bundle.putParcelable(PIC.class.getSimpleName(), response.getPicList().get(0));
					bundle.putInt(ApiCons.STATUS_CODE, statusCode);
					eventCallback.onEvent(true, bundle);

				} else
					onFailure(statusCode, null, responseString, new Exception(response
							  .getError().getMessage()));
			}
		});
	}

	public void addBulkPIC(List<PIC> pics, final EventCallback<Boolean> eventCallback) {

		String json = getGson().toJson(pics.toArray());

		MandiriClient.postJSON(mContext, URLCons.CLIENT_PICS_BULK, json, new TextHttpResponseHandler() {
			@Override
			public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
				onHandleError(eventCallback, throwable);
			}

			@Override
			public void onSuccess(int statusCode, Header[] headers, String responseString) {
				onHandleSuccess(responseString);

				PICResponse response = getGson().fromJson(responseString, PICResponse.class);
				if (response.getError().isNotError()) {

					Bundle bundle = new Bundle();
					bundle.putParcelable(PIC.class.getSimpleName(), response.getPicList().get(0));
					bundle.putInt(ApiCons.STATUS_CODE, statusCode);
					eventCallback.onEvent(true, bundle);

				} else
					onFailure(statusCode, null, responseString, new Exception(response
							  .getError().getMessage()));
			}
		});
	}
}
