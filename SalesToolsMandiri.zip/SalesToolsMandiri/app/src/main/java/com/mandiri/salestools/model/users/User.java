package com.mandiri.salestools.model.users;

import android.os.Parcel;
import android.os.Parcelable;

import com.mandiri.salestools.model.BaseDao;

/**
 * Created by deni on 01/06/15.
 */
public class User extends BaseDao implements Parcelable {

	/**
	 * role : Sales
	 * roleId : 4
	 * name : Sales
	 * departementId : 2
	 * divisionId : 2
	 * userId : 4
	 * email : sales@dummy.com
	 * departement : Corporate Sales
     * division : Pemasaran Kawasan Jabodetabek 1
     * salesId : 1
     * salesDeptId : 2
     * salesDivId : 2
     * email : sales@dummy.com
	 * token : eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VySWQiOjQsIm5hbWUiOiJTYWxlcyIsImVtYWlsIjoic2FsZXNAZHVtbXkuY29tIiwicGFzc3dvcmQiOiJmZTcwM2QyNThjN2VmNWY1MGI3MWUwNjU2NWE2NWFhMDcxOTQ5MDdmIiwicm9sZUlkIjo0LCJkZXBhcnRlbWVudElkIjoyLCJkaXZpc2lvbklkIjoyLCJyb2xlIjoiU2FsZXMiLCJpYXQiOjE0MzM5ODQ3MjF9.dEU_klacemwakAjD74_asa1QwEitM5wmCBI1bgJO0c8
	 */
	private String role;
	private int roleId;
	private String name;
	private String departementId;
	private int divisionId;
	private int userId;
	private String email;
	private String token;
	private String departement;
	private String division;
	private String salesId;
	private String salesDeptId;
	private String salesDivId;

	public void setRole(String role) {
		this.role = role;
	}

	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setDepartementId(String departementId) {
		this.departementId = departementId;
	}

	public void setDivisionId(int divisionId) {
		this.divisionId = divisionId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getRole() {
		return role;
	}

	public int getRoleId() {
		return roleId;
	}

	public String getName() {
		return name;
	}

	public String getDepartementId() {
		return departementId;
	}

	public int getDivisionId() {
		return divisionId;
	}

	public int getUserId() {
		return userId;
	}

	public String getEmail() {
		return email;
	}

	public String getToken() {
		return token;
	}

    public String getDepartement() {
        return departement;
    }

    public void setDepartement(String departement) {
        this.departement = departement;
    }

    public String getDivision() {
        return division;
    }

    public void setDivision(String division) {
        this.division = division;
    }

    public String getSalesId() {
        return salesId;
    }

    public void setSalesId(String salesId) {
        this.salesId = salesId;
    }

    public String getSalesDeptId() {
        return salesDeptId;
    }

    public void setSalesDeptId(String salesDeptId) {
        this.salesDeptId = salesDeptId;
    }

    public String getSalesDivId() {
        return salesDivId;
    }

    public void setSalesDivId(String salesDivId) {
        this.salesDivId = salesDivId;
    }

    public User() {
	}

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeString(this.role);
        dest.writeInt(this.roleId);
        dest.writeString(this.name);
        dest.writeString(this.departementId);
        dest.writeInt(this.divisionId);
        dest.writeInt(this.userId);
        dest.writeString(this.email);
        dest.writeString(this.token);
        dest.writeString(this.departement);
        dest.writeString(this.division);
        dest.writeString(this.salesId);
        dest.writeString(this.salesDeptId);
        dest.writeString(this.salesDivId);
    }

    protected User(Parcel in) {
        this.role = in.readString();
        this.roleId = in.readInt();
        this.name = in.readString();
        this.departementId = in.readString();
        this.divisionId = in.readInt();
        this.userId = in.readInt();
        this.email = in.readString();
        this.token = in.readString();
        this.departement = in.readString();
        this.division = in.readString();
        this.salesId = in.readString();
        this.salesDeptId = in.readString();
        this.salesDivId = in.readString();
    }

    public static final Creator<User> CREATOR = new Creator<User>() {
        public User createFromParcel(Parcel source) {
            return new User(source);
        }

        public User[] newArray(int size) {
            return new User[size];
        }
    };
}
