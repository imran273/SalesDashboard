package com.mandiri.salestools.adapter;

import android.content.Context;
import android.support.v4.app.FragmentManager;

import com.mandiri.salestools.R;
import com.mandiri.salestools.fragments.BaseFragment;
import com.mandiri.salestools.fragments.CardListFragment;
import com.mandiri.salestools.fragments.EventListFragment;


public class MessengerPagerAdapter extends SmartFragmentStatePagerAdapter {

	private Context mContext;

	public MessengerPagerAdapter(Context context, FragmentManager fm) {
		super(fm);
		mContext = context;
	}

	@Override
	public int getItemPosition(Object object) {
		return POSITION_UNCHANGED;
	}

	@Override
	public BaseFragment getItem(int position) {
		if (position == 0) {
			return EventListFragment.newInstance();
		} else {
			return CardListFragment.newInstance();
		}
	}

	@Override
	public int getCount() {
		return 2;
	}

	public CharSequence getPageTitle(int position) {
		if (position == 0)
			return mContext.getString(R.string.members);
		else
			return mContext.getString(R.string.chats);
	}
}