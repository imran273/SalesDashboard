package com.mandiri.salestools.fragments;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mandiri.salestools.R;
import com.mandiri.salestools.apiservice.SchedulesApiService;
import com.mandiri.salestools.fragments.dialog.AddScheduleDialog;
import com.mandiri.salestools.fragments.dialog.ScheduleDialog;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.schedule.Schedule;
import com.mandiri.salestools.utils.CommonUtils;
import com.mandiri.salestools.utils.MandiriDateUtils;
import com.mandiri.salestools.widget.MandiriCalendarView;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import butterknife.ButterKnife;
import butterknife.InjectView;

/**
 * Created by esa on 03/06/15, with awesomeness
 */
public class ScheduleFragment extends BaseFragment implements MandiriCalendarView.CalendarListener {

	@InjectView(R.id.calendarView) MandiriCalendarView mCalendarView;

	private Calendar mCurrentCalendar;

	private int mCurrentMonthIndex;

	public static ScheduleFragment newInstance() {
		return new ScheduleFragment();
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		setHasOptionsMenu(true);
		super.onCreate(savedInstanceState);
		getActionBar().setTitle(R.string.appointments);
	}

	@Nullable
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = mInflater.inflate(R.layout.fragment_calendar, container, false);
		ButterKnife.inject(this, view);
		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		mCurrentMonthIndex = 0;
		mCurrentCalendar = Calendar.getInstance(Locale.getDefault());

		mCalendarView.setCalendarListener(this);
		mCalendarView.markDayAsCurrentDay(mCurrentCalendar.getTime());

        SchedulesApiService mApiService = new SchedulesApiService(mContext);
		mApiService.loadSchedules(new EventCallback<List<Schedule>>() {
            @Override
            public void onEvent(List<Schedule> schedules, Bundle bundle) {
                if (schedules == null) {
                    CommonUtils.toastShort(mContext, R.string.error_string);
                    return;
                }
                for (Schedule schedule : schedules)
                    markCalendar(schedule);
            }
        });
	}

	@Override
	public void onDateSelected(Date date) {
		Schedule schedule = mCalendarView.getSchedule(date);
		if (schedule != null) {
			ScheduleDialog.show(getFragmentManager(), schedule);
		} else {
            Date today = new Date();
            if (date.after(today)){
                AddScheduleDialog.show(this, getFragmentManager(), date);
            }else {
                showStockToast("Can't add Appointment, because out of Date.");
            }
        }
	}

	@Override
	public void onRightButtonClick() {
		mCurrentMonthIndex++;
		updateCalendar();
	}

	@Override
	public void onLeftButtonClick() {
		mCurrentMonthIndex--;
		updateCalendar();
	}

	private void updateCalendar() {
		mCurrentCalendar = Calendar.getInstance(Locale.getDefault());
		mCurrentCalendar.add(Calendar.MONTH, mCurrentMonthIndex);
		mCalendarView.initializeCalendar(mCurrentCalendar);

		if (mCalendarView.hasSchedule()) {
			for (Schedule schedule : mCalendarView.getSchedules())
				markCalendar(schedule);
		}
	}

	private void markCalendar(Schedule schedule) {
		if (!MandiriDateUtils.isSameMonth(mCurrentCalendar.getTime(), MandiriDateUtils
				.getFormattedDate(schedule.getStartDate())))
			return;

		mCalendarView.pushSchedule(MandiriDateUtils.getFormattedDate(schedule.getStartDate()), schedule);
		mCalendarView.markFirstUnderlineWithStyle(MandiriCalendarView.RED_COLOR,
				MandiriDateUtils.getFormattedDate(schedule.getStartDate()));
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == AddScheduleDialog.ADD_SCHEDULE_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
			Bundle bundle = data.getExtras();
			Schedule schedule = bundle.getParcelable(Schedule.class.getSimpleName());
			markCalendar(schedule);
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
}
