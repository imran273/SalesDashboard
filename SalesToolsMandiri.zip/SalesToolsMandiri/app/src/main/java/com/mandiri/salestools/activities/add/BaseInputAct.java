package com.mandiri.salestools.activities.add;

import android.view.MenuItem;

import com.mandiri.salestools.BaseActivity;

/**
 * Created by esa on 09/06/15, with awesomeness
 */
public class BaseInputAct extends BaseActivity {

	public static final int BASE_INPUT_CODE = 0x154;
	public static final String ARG_SCHEDULE = "BaseInputAct.Schedule";

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case android.R.id.home:
				finish();
				break;
		}
		return super.onOptionsItemSelected(item);
	}
}
