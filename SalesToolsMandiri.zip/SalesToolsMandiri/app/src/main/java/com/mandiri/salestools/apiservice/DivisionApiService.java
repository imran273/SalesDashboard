package com.mandiri.salestools.apiservice;

import android.content.Context;
import android.util.Log;

import com.loopj.android.http.TextHttpResponseHandler;
import com.mandiri.salestools.constants.URLCons;
import com.mandiri.salestools.http.MandiriClient;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.division.Division;
import com.mandiri.salestools.model.division.DivisionDao;
import com.mandiri.salestools.model.sales.Sales;
import com.mandiri.salestools.utils.Logger;

import org.apache.http.Header;

import java.util.List;

public class DivisionApiService extends BaseApiService {

	public DivisionApiService(Context mContext) {
		super(mContext);
	}

//    public void loadSalesFull(final EventCallback<List<Sales>> eventCallback) {
//        loadDepartement(URLCons.SALES_FULL, eventCallback);
//    }

    public void loadDivision(final EventCallback<List<Division>> eventCallback) {
        loadDivision(URLCons.DIVISIONS, eventCallback);
    }

	private void loadDivision(final String url,
                              final EventCallback<List<Division>> eventCallback) {

		MandiriClient.get(mContext, url, new TextHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, String response) {
                Logger.log(Log.DEBUG, "Response :" + response);
                try {
                    DivisionDao baseApiDao = getGson().fromJson(response, DivisionDao.class);
                    if (baseApiDao.getError().getMessage() == null) {
                        List<Division> report = baseApiDao.getDivisions();

                        eventCallback.onEvent(report);
                    } else {
                        eventCallback.onEvent(null);
                    }
                } catch (Exception e) {
                    onFailure(statusCode, headers, response, e);
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                Logger.log(throwable);
                eventCallback.onEvent(null);
            }
        });
	}

	public void doAddSales(final Sales sales,
                           final EventCallback<Division> eventCallback) {

//        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        String date = df.format(Calendar.getInstance().getTime());
//        sales.setStartDate(date);
        String json = getGson().toJson(sales);

		MandiriClient.postJSON(mContext, URLCons.DIVISIONS, json, new TextHttpResponseHandler() {
			@Override
			public void onSuccess(int statusCode, Header[] headers, String response) {
				Logger.log(Log.DEBUG, "Response :" + response);
				try {
                    DivisionDao baseApiDao = getGson().fromJson(response, DivisionDao.class);
                    if (baseApiDao.getError().getMessage() == null) {
                        Division user = baseApiDao.getDivisions().get(0);

                        eventCallback.onEvent(user);
                    } else {
                        eventCallback.onEvent(null);
                    }
				} catch (Exception e) {
					onFailure(statusCode, headers, response, e);
				}
			}

			@Override
			public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
				Logger.log(throwable);
				eventCallback.onEvent(null);
			}
		});
	}
}
