package com.mandiri.salestools.model.schedule;

import android.os.Parcel;

import com.mandiri.salestools.model.BaseDao;

import java.util.List;

/**
 * Created by esa on 04/06/15, with awesomeness
 */
public class SchedulesResponse extends BaseDao {

	private List<Schedule> schedules;

	public void setSchedules(List<Schedule> schedules) {
		this.schedules = schedules;
	}

	public List<Schedule> getSchedules() {
		return schedules;
	}

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		super.writeToParcel(dest, flags);
		dest.writeTypedList(schedules);
	}

	public SchedulesResponse() {
	}

	protected SchedulesResponse(Parcel in) {
		this.schedules = in.createTypedArrayList(Schedule.CREATOR);
	}

	public static final Creator<SchedulesResponse> CREATOR = new Creator<SchedulesResponse>() {
		public SchedulesResponse createFromParcel(Parcel source) {
			return new SchedulesResponse(source);
		}

		public SchedulesResponse[] newArray(int size) {
			return new SchedulesResponse[size];
		}
	};
}
