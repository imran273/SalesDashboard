/*
 * Copyright (c) 2015. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.
 * Vestibulum commodo. Ut rhoncus gravida arcu.
 */

package com.mandiri.salestools.apiservice;

import android.content.Context;
import android.util.Log;

import com.loopj.android.http.TextHttpResponseHandler;
import com.mandiri.salestools.constants.URLCons;
import com.mandiri.salestools.http.MandiriClient;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.sales.Sales;
import com.mandiri.salestools.model.status.Status;
import com.mandiri.salestools.model.status.StatusDao;
import com.mandiri.salestools.utils.Logger;

import org.apache.http.Header;

import java.util.List;

public class StatusApiService extends BaseApiService {

	public StatusApiService(Context mContext) {
		super(mContext);
	}

//    public void loadSalesFull(final EventCallback<List<Sales>> eventCallback) {
//        loadDepartement(URLCons.SALES_FULL, eventCallback);
//    }

    public void loadStatus(final EventCallback<List<Status>> eventCallback) {
        loadStatus(URLCons.STATUS, eventCallback);
    }

	private void loadStatus(final String url,
                            final EventCallback<List<Status>> eventCallback) {

		MandiriClient.get(mContext, url, new TextHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, String response) {
                Logger.log(Log.DEBUG, "Response :" + response);
                try {
                    StatusDao baseApiDao = getGson().fromJson(response, StatusDao.class);
                    if (baseApiDao.getError().getMessage() == null) {
                        List<Status> report = baseApiDao.getStatus();

                        eventCallback.onEvent(report);
                    } else {
                        eventCallback.onEvent(null);
                    }
                } catch (Exception e) {
                    onFailure(statusCode, headers, response, e);
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                Logger.log(throwable);
                eventCallback.onEvent(null);
            }
        });
	}

	public void doAddStatus(final Sales sales,
                           final EventCallback<Status> eventCallback) {

//        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        String date = df.format(Calendar.getInstance().getTime());
//        sales.setStartDate(date);
        String json = getGson().toJson(sales);

		MandiriClient.postJSON(mContext, URLCons.USER, json, new TextHttpResponseHandler() {
			@Override
			public void onSuccess(int statusCode, Header[] headers, String response) {
				Logger.log(Log.DEBUG, "Response :" + response);
				try {
                    StatusDao baseApiDao = getGson().fromJson(response, StatusDao.class);
                    if (baseApiDao.getError().getMessage() == null) {
                        Status status = baseApiDao.getStatus().get(0);

                        eventCallback.onEvent(status);
                    } else {
                        eventCallback.onEvent(null);
                    }
				} catch (Exception e) {
					onFailure(statusCode, headers, response, e);
				}
			}

			@Override
			public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
				Logger.log(throwable);
				eventCallback.onEvent(null);
			}
		});
	}
}
