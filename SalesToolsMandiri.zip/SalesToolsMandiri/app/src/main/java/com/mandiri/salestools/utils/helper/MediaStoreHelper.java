package com.mandiri.salestools.utils.helper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Log;

import com.mandiri.salestools.model.DeviceImage;
import com.mandiri.salestools.utils.Logger;

import java.util.ArrayList;
import java.util.List;


public class MediaStoreHelper {

	public static List<String> getCameraImages(Context context) {

		// which image properties are we querying
		String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DATA,
				MediaStore.Images.Media.DATE_TAKEN};

		// Get the base URI for the People table in the Contacts content
		// provider.
		Uri images = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;

		Cursor cur = context.getContentResolver().query(images, projection, "", null, "");

		Logger.log(Log.INFO, "query count:" + cur.getCount());

		List<String> listData = new ArrayList<>();

		if (cur.moveToLast()) {
			String bucket;
			String date;

			int bucketColumn = cur.getColumnIndex(MediaStore.Images.Media.DATA);
			int dateColumn = cur.getColumnIndex(MediaStore.Images.Media.DATE_TAKEN);

			do {
				// Get the field values
				bucket = "file://" + cur.getString(bucketColumn);
				date = cur.getString(dateColumn);

				listData.add(bucket);

				// Do something with the values.
				Logger.log(Log.INFO, "bucket" + bucket);
			} while (cur.moveToPrevious());
		}
		return listData;
	}

	public static List<DeviceImage> getDeviceImages(Context context) {

		String[] projection = new String[]{MediaStore.Images.Media.DATA, MediaStore.Images.Media._ID,
				MediaStore.Images.Media.BUCKET_ID, MediaStore.Images.Media.ORIENTATION};
		Uri images = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
		Cursor cur = context.getContentResolver().query(images, projection, "", null, "");

		Logger.log(Log.INFO, "query count:" + cur.getCount());

		List<DeviceImage> listData = new ArrayList<>();
		if (cur.moveToLast()) {
			do {
				DeviceImage deviceImage = new DeviceImage();
				deviceImage.setFilePath(cur.getString(0));
				deviceImage.setId(cur.getString(1));
				deviceImage.setBucketId(cur.getString(2));
				deviceImage.setOrientation(cur.getInt(3));
				listData.add(deviceImage);
			} while (cur.moveToPrevious());
		}
		cur.close();

		return listData;
	}

	public static String getThumbnailImages(Context context, String id, String bucketID) {

		String[] projection = new String[]{MediaStore.Images.Thumbnails.DATA};
		Uri images = MediaStore.Images.Thumbnails.EXTERNAL_CONTENT_URI;

		Cursor cur = context.getContentResolver().query(images, projection,
				MediaStore.Images.Thumbnails.IMAGE_ID + "=" + id, null, "");

		if (cur == null)
			return null;
		if (cur.getCount() == 0)
			return null;

		cur.moveToLast();
		return cur.getString(0);
	}

	public static String getImages(Context context, String id) {

		Logger.log(Log.INFO, "Get id:" + id);

		String[] projection = new String[]{MediaStore.Images.Media.DATA, MediaStore.Images.Media._ID};
		Uri images = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
		Cursor cur = context.getContentResolver().query(images, projection, MediaStore.Images.Media._ID + "=" + id,
				null, "");

		Logger.log(Log.INFO, "query count:" + cur.getCount());

		if (cur.getCount() == 0)
			return null;

		cur.moveToLast();
		return cur.getString(1);
	}

	public static void addImageToGallery(final String filePath, final Context context) {

		ContentValues values = new ContentValues();

		values.put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis());
		values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
		values.put(MediaStore.MediaColumns.DATA, filePath);
		values.put(MediaStore.Images.Media.ORIENTATION, 0);

		context.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
	}
}
