package com.mandiri.salestools.model.division;

import android.os.Parcel;

import com.mandiri.salestools.model.BaseDao;

import java.util.List;

/**
 * Created by deni on 04/06/15
 */
public class DivisionDao extends BaseDao {

	private List<Division> divisions;

    public List<Division> getDivisions() {
        return divisions;
    }

    public void setDivisions(List<Division> divisions) {
        this.divisions = divisions;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeTypedList(divisions);
    }

    public DivisionDao() {
    }

    protected DivisionDao(Parcel in) {
        this.divisions = in.createTypedArrayList(Division.CREATOR);
    }

    public static final Creator<DivisionDao> CREATOR = new Creator<DivisionDao>() {
        public DivisionDao createFromParcel(Parcel source) {
            return new DivisionDao(source);
        }

        public DivisionDao[] newArray(int size) {
            return new DivisionDao[size];
        }
    };
}
