package com.mandiri.salestools.utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;

@SuppressWarnings("ResultOfMethodCallIgnored")
@SuppressLint("SdCardPath")
public class FileUtils {

	public static final String IMAGE_DIR = "/Pictures/PDIP";
	public static final String FILE_EXTENSION = "jpg";
	public static final String SDCARD1 = "/sdcard1";

	public static File getAppDir(Context context) {

		boolean isSDPresent = Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED);
		File parent = isSDPresent ? Environment.getExternalStorageDirectory() : context.getFilesDir();

		if (!isSDPresent && isHaveSDCard1())
			parent = new File(SDCARD1);

		File dir = new File(parent, IMAGE_DIR);
		if (!dir.exists())
			dir.mkdirs();
		return dir;
	}

	public static boolean isHaveSDCard1() {
		File file = new File(SDCARD1);
		return file.exists();
	}

	public static File getFile(Context context, String name) {
		return getFile(context, name, FILE_EXTENSION);
	}

	public static File getFile(Context context, String name, String extension) {
		extension = ".".concat(extension.trim().toLowerCase(Locale.getDefault()));
		File dir = getAppDir(context);
		return new File(dir, name + extension);
	}

	public static File getTempFile(Context context) {
		return getFile(context, "temp");
	}

	public static Uri getTempUri(Context context) {
		return Uri.fromFile(getTempFile(context));
	}

	public static void copyFile(File afile, File bfile) {
		InputStream inStream;
		OutputStream outStream;

		try {
			inStream = new FileInputStream(afile);
			outStream = new FileOutputStream(bfile);

			byte[] buffer = new byte[1024];

			int length;
			while ((length = inStream.read(buffer)) > 0) {
				outStream.write(buffer, 0, length);
			}

			inStream.close();
			outStream.close();

			Logger.log(Log.INFO, "File is copied successful!");

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
