package com.mandiri.salestools.activities.add;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Spinner;

import com.balysv.materialmenu.MaterialMenuDrawable;
import com.mandiri.salestools.R;
import com.mandiri.salestools.apiservice.ProductApiService;
import com.mandiri.salestools.fragments.BaseFragment;
import com.mandiri.salestools.fragments.dialog.ProgressDialogFragment;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.products.Product;
import com.mandiri.salestools.utils.CommonUtils;
import com.mandiri.salestools.utils.Preferences;
import com.mandiri.salestools.utils.helper.BundleHelper;

import butterknife.ButterKnife;
import butterknife.InjectView;

/**
 * Created by esa on 09/06/15, with awesomeness
 */
public class AddProductAct extends BaseInputAct {

	@InjectView(R.id.toolbar) Toolbar mToolbar;
	@InjectView(R.id.inpTitle) EditText mInpTitle;
	@InjectView(R.id.inpContent) EditText mInpContent;
	@InjectView(R.id.spnSolutionCategory) Spinner mSpnSolutionCategory;
	@InjectView(R.id.spnCategory) Spinner mSpnCategory;

	private ProductApiService mProductApiService;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add_product);
		ButterKnife.inject(this);

		setupToolbar(mToolbar);
		setTitle(R.string.add_product);
		materialMenuIcon.setState(MaterialMenuDrawable.IconState.ARROW);

		mProductApiService = new ProductApiService(mContext);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.menu_submit, menu);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case R.id.menu_add:
				doSubmitProduct();
				break;
		}
		return super.onOptionsItemSelected(item);
	}

	private void doSubmitProduct() {
		final ProgressDialogFragment progressDialogFragment = ProgressDialogFragment.newInstance
				("Adding...").show(getSupportFragmentManager());

		final Product product = new Product();
		product.setName(mInpTitle.getText().toString().trim());
		product.setDescription(mInpContent.getText().toString().trim());
		product.setCategory(String.valueOf(mSpnSolutionCategory.getSelectedItem()).toLowerCase());
		product.setType(String.valueOf(mSpnCategory.getSelectedItem()).toLowerCase());
		product.setDepartementId(Preferences.getProfile(mContext).getDepartementId());

		mProductApiService.addProduct(product, new EventCallback<Boolean>() {
			@Override
			public void onEvent(Boolean data, Bundle bundle) {
				progressDialogFragment.dismissAllowingStateLoss();

				if (data == null) {
					CommonUtils.toastShort(mContext, R.string.error_string);
					return;
				}
				setResult(Activity.RESULT_OK, BundleHelper.createIntentWithBundle(bundle));
				finish();
			}
		});
	}

	/* ---------- LAUNCHER ------------ */

	public static void startForResult(BaseFragment baseFragment) {
		baseFragment.startActivityForResult(new Intent(baseFragment.getActivity(), AddProductAct
				.class), BaseInputAct.BASE_INPUT_CODE);
	}
}
