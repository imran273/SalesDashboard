package com.mandiri.salestools;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import com.astuetz.PagerSlidingTabStrip;
import com.balysv.materialmenu.MaterialMenuDrawable;
import com.makeramen.roundedimageview.RoundedImageView;
import com.mandiri.salestools.adapter.ProfilePagerAdapter;
import com.mandiri.salestools.model.DeviceImage;
import com.mandiri.salestools.utils.BitmapUtils;
import com.mandiri.salestools.widget.RippleDrawable;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

/**
 * Created by deni on 11/04/15
 */
@Deprecated
public class ProfileOldAct extends BaseActivity implements ViewPager.OnPageChangeListener {

    @InjectView(R.id.toolbar)
    Toolbar mToolbar;
	@InjectView(R.id.imgContent)
	RoundedImageView imgUser;
	@InjectView(R.id.pager)
	ViewPager mViewPager;
	@InjectView(R.id.indicator)
	PagerSlidingTabStrip mPagerSlidingTabStrip;

	private Bitmap mBitmap;
	private DeviceImage mDeviceImage;


	private ProfilePagerAdapter mPagerAdapter;
	private int lastPosition;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_profile);
		ButterKnife.inject(this);

        setupToolbar(mToolbar);
		materialMenuIcon.setState(MaterialMenuDrawable.IconState.ARROW);

		mPagerAdapter = new ProfilePagerAdapter(mContext, getSupportFragmentManager());
		mViewPager.setAdapter(mPagerAdapter);
		mPagerSlidingTabStrip.setTextColor(Color.WHITE);
		mPagerSlidingTabStrip.setOnPageChangeListener(this);

		mViewPager.setOffscreenPageLimit(2);
		mPagerSlidingTabStrip.setViewPager(mViewPager);

		RippleDrawable.createRipple(imgUser, getResources().getColor(R.color.grey));
	}

	@OnClick(R.id.imgContent)
	public void onImageUserClick() {
		ImageChooserAct.startActivityForResult(this);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.activity_profile, menu);
		return super.onCreateOptionsMenu(menu);
	}


	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		switch (requestCode) {
			case ImageChooserAct.REQ_CODE:
				if (resultCode == RESULT_OK) {
					Bundle bundle = data.getExtras();
					mDeviceImage = bundle.getParcelable(ImageChooserAct.ARG_IMAGE_RESULT);
					mBitmap = BitmapUtils.getScaledDeviceImage(mDeviceImage, 500);

					imgUser.setImageBitmap(mBitmap);
				}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case R.id.menu_logout:
				LoginAct.start(this);
				finish();
				break;
//			case R.id.menu_edit:
//				UpdateProfileAct.start(mContext);
//				break;
		}
		return super.onOptionsItemSelected(item);
	}

	public static void start(Context context) {
		Intent intent = new Intent(context, ProfileOldAct.class);
		context.startActivity(intent);
	}

	@Override
	public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

	}

	@Override
	public void onPageSelected(int position) {
		lastPosition = position;
	}

	@Override
	public void onPageScrollStateChanged(int state) {

	}
}
