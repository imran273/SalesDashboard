package com.mandiri.salestools.model.pic;

import android.os.Parcel;

import com.google.gson.annotations.SerializedName;
import com.mandiri.salestools.model.BaseDao;

import java.util.ArrayList;
import java.util.List;

public class PICResponse extends BaseDao {

	public List<PIC> getPicList() {
		return picList;
	}

	public void setPicList(List<PIC> picList) {
		this.picList = picList;
	}

	@SerializedName("clientPics")
	public List<PIC> picList = new ArrayList<>();

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		super.writeToParcel(dest, flags);
		dest.writeTypedList(picList);
	}

	public PICResponse() {
	}

	protected PICResponse(Parcel in) {
		this.picList = in.createTypedArrayList(PIC.CREATOR);
	}

	public static final Creator<PICResponse> CREATOR = new Creator<PICResponse>() {
		public PICResponse createFromParcel(Parcel source) {
			return new PICResponse(source);
		}

		public PICResponse[] newArray(int size) {
			return new PICResponse[size];
		}
	};
}
