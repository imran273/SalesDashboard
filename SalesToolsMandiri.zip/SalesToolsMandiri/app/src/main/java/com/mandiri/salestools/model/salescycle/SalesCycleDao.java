package com.mandiri.salestools.model.salescycle;

import android.os.Parcel;

import com.mandiri.salestools.model.BaseDao;

import java.util.List;

/**
 * Created by deni on 09/06/15
 */
public class SalesCycleDao extends BaseDao {

	private List<SalesCycle> salesCycles;

    public List<SalesCycle> getSalesCycles() {
        return salesCycles;
    }

    public void setSalesCycles(List<SalesCycle> salesCycles) {
        this.salesCycles = salesCycles;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeTypedList(salesCycles);
    }

    public SalesCycleDao() {
    }

    protected SalesCycleDao(Parcel in) {
        this.salesCycles = in.createTypedArrayList(SalesCycle.CREATOR);
    }

    public static final Creator<SalesCycleDao> CREATOR = new Creator<SalesCycleDao>() {
        public SalesCycleDao createFromParcel(Parcel source) {
            return new SalesCycleDao(source);
        }

        public SalesCycleDao[] newArray(int size) {
            return new SalesCycleDao[size];
        }
    };
}
