package com.mandiri.salestools.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * Created by esa on 05/06/15, with awesomeness
 */
public class MandiriDateUtils {

	public static boolean beforeNow(String time) {
		Date date = toDate(time);
		if (date == null)
			return false;

		Calendar calendar = Calendar.getInstance(Locale.getDefault());
		calendar.setTime(date);
		return calendar.before(Calendar.getInstance(Locale.getDefault()));
	}

	public static Date toDate(String time) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
		try {
			return simpleDateFormat.parse(time);
		} catch (ParseException e) {
			return null;
		}
	}

	public static String getStringFormattedDate(Date date) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale
				  .getDefault());
		return simpleDateFormat.format(date);
	}

	public static String getStringSimpleFormattedDate(Date date) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale
				  .getDefault());
		return simpleDateFormat.format(date);
	}

	public static Date getFormattedDate(String dateString) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",
				  Locale.getDefault());
		try {
			return simpleDateFormat.parse(dateString);
		} catch (ParseException e) {
			Logger.log(e);
			return null;
		}
	}

	public static boolean isSameMonth(Date date1, Date date2) {
		Calendar calendar1 = Calendar.getInstance();
		calendar1.setTime(date1);

		Calendar calendar2 = Calendar.getInstance();
		calendar2.setTime(date2);

		return calendar1.get(Calendar.YEAR) == calendar2.get(Calendar.YEAR) && calendar1.get(Calendar
				  .MONTH) == calendar2.get(Calendar.MONTH);
	}
}
