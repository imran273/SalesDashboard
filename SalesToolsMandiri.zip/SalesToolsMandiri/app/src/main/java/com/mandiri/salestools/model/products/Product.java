package com.mandiri.salestools.model.products;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by esa on 09/06/15, with awesomeness
 */
public class Product implements Parcelable {

	/**
	 * createdAt : 2015-06-15T11:17:58.000Z
	 * deletedAt : null
	 * color :
	 * name : MCM
	 * description :
	 * id : 1
	 * departementId : 2
	 * category : simple
	 * type : cash
	 * updatedAt : 2015-06-15T11:17:58.000Z
	 */

	private String createdAt;
	private String deletedAt;
	private String color;
	private String name;
	private String description;
	private String id;
	private String departementId;
	private String category;
	private String type;
	private String updatedAt;

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public void setDeletedAt(String deletedAt) {
		this.deletedAt = deletedAt;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setDepartementId(String departementId) {
		this.departementId = departementId;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public String getDeletedAt() {
		return deletedAt;
	}

	public String getColor() {
		return color;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	public String getId() {
		return id;
	}

	public String getDepartementId() {
		return departementId;
	}

	public String getCategory() {
		return category;
	}

	public String getType() {
		return type;
	}

	public String getUpdatedAt() {
		return updatedAt;
	}

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(this.createdAt);
		dest.writeString(this.deletedAt);
		dest.writeString(this.color);
		dest.writeString(this.name);
		dest.writeString(this.description);
		dest.writeString(this.id);
		dest.writeString(this.departementId);
		dest.writeString(this.category);
		dest.writeString(this.type);
		dest.writeString(this.updatedAt);
	}

	public Product() {
	}

	protected Product(Parcel in) {
		this.createdAt = in.readString();
		this.deletedAt = in.readString();
		this.color = in.readString();
		this.name = in.readString();
		this.description = in.readString();
		this.id = in.readString();
		this.departementId = in.readString();
		this.category = in.readString();
		this.type = in.readString();
		this.updatedAt = in.readString();
	}

	public static final Creator<Product> CREATOR = new Creator<Product>() {
		public Product createFromParcel(Parcel source) {
			return new Product(source);
		}

		public Product[] newArray(int size) {
			return new Product[size];
		}
	};
}
