package com.mandiri.salestools.apiservice;

import android.content.Context;
import android.os.Bundle;

import com.loopj.android.http.TextHttpResponseHandler;
import com.mandiri.salestools.constants.ApiCons;
import com.mandiri.salestools.constants.URLCons;
import com.mandiri.salestools.http.MandiriClient;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.action.Action;
import com.mandiri.salestools.model.action.ActionsResponse;
import com.mandiri.salestools.model.comment.Comment;
import com.mandiri.salestools.model.comment.CommentsResponse;
import com.mandiri.salestools.model.pipeline.Pipeline;
import com.mandiri.salestools.model.pipeline.PipelinesResponse;
import com.mandiri.salestools.model.users.User;
import com.mandiri.salestools.utils.Preferences;

import org.apache.http.Header;

import java.util.List;
import java.util.Locale;

/**
 * Created by esa on 04/06/15, with awesomeness
 */
public class PipelineApiService extends BaseApiService {

	public PipelineApiService(Context mContext) {
		super(mContext);
	}

	public void loadPipelineForStatus(String departementId, String statusId, final EventCallback<List<Pipeline>> eventCallback) {

		User user = Preferences.getProfile(mContext);
		String url = URLCons.PIPELINE +
				"?join[model]=Client&join[model]=Product" +
				"&q[departementId]=%s" +
				"&q[salesId]=%s" +
				"&q[statusId]=%s";

		loadPiplines(String.format(Locale.getDefault(), url, departementId, user.getSalesId(),
                statusId), eventCallback);
	}

	public void loadPiplines(final EventCallback<List<Pipeline>> eventCallback) {
//        "http://45.64.96.237:3000/api/v1/offerings?join[model]=Client&join[model]=Product&join[model]=Comment&join[model]=OfferingCycleDeal&q[departementId]=2&q[salesId]=1"
//		loadPiplines(URLCons.PIPELINE + "?join[model]=Client&join[model]=Product&" +
//						"join[model]=Comment&join[model]=OfferingCycleDeal" +
//						"&q[departementId]=" + Preferences.getProfile(mContext).getDepartementId() +
//						"&q[salesId]=" + Preferences.getSalesId(mContext),
//				eventCallback);
		loadPiplines(URLCons.PIPELINE + "?join[model]=Client&join[model]=Product&join[model]=Comment&join[model]=OfferingCycleDeal" +
                        "&q[departementId]=" + Preferences.getProfile(mContext).getDepartementId() +
                        "&q[salesId]=" + Preferences.getSalesId(mContext),
                eventCallback);
	}

    public void loadPipelineForClient(String clientId, final EventCallback<List<Pipeline>> eventCallback) {

        User user = Preferences.getProfile(mContext);
        String url = URLCons.PIPELINE +
                "?join[model]=Client&join[model]=Product" +
                "&q[salesId]=%s" +
                "&q[clientId]=%s";

        loadPiplines(String.format(Locale.getDefault(), url, user.getSalesId(),
                clientId), eventCallback);
    }

	private void loadPiplines(String url, final EventCallback<List<Pipeline>> eventCallback) {

		MandiriClient.get(mContext, url, new TextHttpResponseHandler() {
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                onHandleError(eventCallback, throwable);
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, String responseString) {
                onHandleSuccess(responseString);
                PipelinesResponse response = getGson().fromJson(responseString, PipelinesResponse.class);
                if (response.getError().isNotError()) {
                    eventCallback.onEvent(response.getPipelines());
                } else
                    onFailure(statusCode, null, responseString, new Exception(response.getError().getMessage()));
            }
        });
	}

	public void addPipeline(Pipeline pipeline, final EventCallback<Boolean> eventCallback) {
		String json = getGson().toJson(pipeline);
        String URL = URLCons.PIPELINE;
		MandiriClient.postJSON(mContext, URL, json, new TextHttpResponseHandler() {
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                onHandleError(eventCallback, throwable);
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, String responseString) {
                onHandleSuccess(responseString);

                PipelinesResponse response = getGson().fromJson(responseString, PipelinesResponse.class);
                if (response.getError().isNotError()) {

                    Bundle bundle = new Bundle();
                    bundle.putParcelable(Pipeline.class.getSimpleName(), response.getPipelines().get(0));
                    bundle.putInt(ApiCons.STATUS_CODE, statusCode);
                    eventCallback.onEvent(true, bundle);

                } else
                    onFailure(statusCode, null, responseString, new Exception(response
                            .getError().getMessage()));
            }
        });
	}

	public void addPipelineComment(Comment comment, final EventCallback<Boolean> eventCallback) {

		String json = getGson().toJson(comment);
		MandiriClient.postJSON(mContext, URLCons.OFFERING_COMMENT, json, new TextHttpResponseHandler() {
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                onHandleError(eventCallback, throwable);
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, String responseString) {
                onHandleSuccess(responseString);

                CommentsResponse response = getGson().fromJson(responseString, CommentsResponse.class);
                if (response.getError().isNotError()) {
                    eventCallback.onEvent(true);
                } else
                    onFailure(statusCode, null, responseString, new Exception(response
                            .getError().getMessage()));
            }
        });
	}

	public void addPipelineAction(Action action, final EventCallback<Boolean> eventCallback) {
		String json = getGson().toJson(action);
		MandiriClient.postJSON(mContext, URLCons.OFFERING_ACTION, json, new TextHttpResponseHandler() {
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                onHandleError(eventCallback, throwable);
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, String responseString) {
                onHandleSuccess(responseString);

                ActionsResponse response = getGson().fromJson(responseString, ActionsResponse.class);
                if (response.getError().isNotError()) {
                    eventCallback.onEvent(true);
                } else
                    onFailure(statusCode, null, responseString, new Exception(response
                            .getError().getMessage()));
            }
        });
	}

	public void addProduct(Pipeline pipeline, final EventCallback<Boolean> eventCallback) {
		String json = getGson().toJson(pipeline);
		MandiriClient.put(mContext, URLCons.PIPELINE + "/" + pipeline.getId() + "/products", json, new TextHttpResponseHandler() {
			@Override
			public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
				onHandleError(eventCallback, throwable);
			}

			@Override
			public void onSuccess(int statusCode, Header[] headers, String responseString) {
				onHandleSuccess(responseString);

				PipelinesResponse response = getGson().fromJson(responseString, PipelinesResponse.class);
				if (response.getError().isNotError()) {
					eventCallback.onEvent(true);
				} else
					onFailure(statusCode, null, responseString, new Exception(response
							.getError().getMessage()));
			}
		});
	}

}
