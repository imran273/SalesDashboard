package com.mandiri.salestools.utils.helper;

import android.content.Intent;
import android.os.Bundle;

/**
 * Created by esa on 05/06/15, with awesomeness
 */
public class BundleHelper {

	public static Intent createIntentWithBundle(Bundle bundle) {
		return new Intent().putExtras(bundle);
	}
}
