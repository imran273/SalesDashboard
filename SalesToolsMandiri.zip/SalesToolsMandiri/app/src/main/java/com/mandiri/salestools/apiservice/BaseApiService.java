package com.mandiri.salestools.apiservice;

import android.content.Context;
import android.util.Log;

import com.google.gson.Gson;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.utils.Logger;

/**
 * Created by esa on 06/10/14 with awesomeness.
 */
public class BaseApiService {

	public Context mContext;

	private Gson mGson;

	public BaseApiService(Context mContext) {
		this.mContext = mContext;
	}

	protected void onHandleError(EventCallback<?> eventCallback, Throwable throwable) {
		Logger.log(throwable);
		if (eventCallback != null)
			eventCallback.onEvent(null);
	}

	protected void onHandleSuccess(String responseString) {
		Logger.log(Log.INFO, "Request Complete!");
		Logger.log(Log.DEBUG, "Response:" + responseString);
	}

	protected Gson getGson() {
		if (mGson == null)
			mGson = new Gson();
		return mGson;
	}
}
