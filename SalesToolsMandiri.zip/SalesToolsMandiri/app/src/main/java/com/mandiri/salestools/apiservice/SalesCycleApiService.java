package com.mandiri.salestools.apiservice;

import android.content.Context;
import android.util.Log;

import com.loopj.android.http.TextHttpResponseHandler;
import com.mandiri.salestools.constants.URLCons;
import com.mandiri.salestools.http.MandiriClient;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.sales.Sales;
import com.mandiri.salestools.model.salescycle.SalesCycle;
import com.mandiri.salestools.model.salescycle.SalesCycleDao;
import com.mandiri.salestools.utils.Logger;

import org.apache.http.Header;

import java.util.List;

public class SalesCycleApiService extends BaseApiService {

	public SalesCycleApiService(Context mContext) {
		super(mContext);
	}

//    public void loadSalesFull(final EventCallback<List<Sales>> eventCallback) {
//        loadDepartement(URLCons.SALES_FULL, eventCallback);
//    }

    public void loadSalesCycle(final EventCallback<List<SalesCycle>> eventCallback) {
        loadSalesCycle(URLCons.SALES_CYCLES, eventCallback);
    }

	private void loadSalesCycle(final String url,
                          final EventCallback<List<SalesCycle>> eventCallback) {

		MandiriClient.get(mContext, url, new TextHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, String response) {
                Logger.log(Log.DEBUG, "Response :" + response);
                try {
                    SalesCycleDao baseApiDao = getGson().fromJson(response, SalesCycleDao.class);
                    if (baseApiDao.getError().getMessage() == null) {
                        List<SalesCycle> report = baseApiDao.getSalesCycles();

                        eventCallback.onEvent(report);
                    } else {
                        eventCallback.onEvent(null);
                    }
                } catch (Exception e) {
                    onFailure(statusCode, headers, response, e);
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                Logger.log(throwable);
                eventCallback.onEvent(null);
            }
        });
	}

	public void doAddSalesCycle(final Sales sales,
                           final EventCallback<SalesCycle> eventCallback) {

//        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        String date = df.format(Calendar.getInstance().getTime());
//        sales.setStartDate(date);
        String json = getGson().toJson(sales);

		MandiriClient.postJSON(mContext, URLCons.SALES_CYCLES, json, new TextHttpResponseHandler() {
			@Override
			public void onSuccess(int statusCode, Header[] headers, String response) {
				Logger.log(Log.DEBUG, "Response :" + response);
				try {
                    SalesCycleDao baseApiDao = getGson().fromJson(response, SalesCycleDao.class);
                    if (baseApiDao.getError().getMessage() == null) {
                        SalesCycle salesCycle = baseApiDao.getSalesCycles().get(0);

                        eventCallback.onEvent(salesCycle);
                    } else {
                        eventCallback.onEvent(null);
                    }
				} catch (Exception e) {
					onFailure(statusCode, headers, response, e);
				}
			}

			@Override
			public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
				Logger.log(throwable);
				eventCallback.onEvent(null);
			}
		});
	}
}
