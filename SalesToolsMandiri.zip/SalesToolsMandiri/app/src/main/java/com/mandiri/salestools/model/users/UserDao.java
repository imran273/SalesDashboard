package com.mandiri.salestools.model.users;

import android.os.Parcel;

import com.mandiri.salestools.model.BaseDao;

import java.util.List;

/**
 * Created by deni on 09/06/15
 */
public class UserDao extends BaseDao {

	private List<User> users;

    public List<User> getUsers() {
        return users;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeTypedList(users);
    }

    public UserDao() {
    }

    protected UserDao(Parcel in) {
        this.users = in.createTypedArrayList(User.CREATOR);
    }

    public static final Creator<UserDao> CREATOR = new Creator<UserDao>() {
        public UserDao createFromParcel(Parcel source) {
            return new UserDao(source);
        }

        public UserDao[] newArray(int size) {
            return new UserDao[size];
        }
    };
}
