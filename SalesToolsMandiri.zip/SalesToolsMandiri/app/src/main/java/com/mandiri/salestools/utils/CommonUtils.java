package com.mandiri.salestools.utils;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.os.Build;
import android.support.annotation.StringRes;
import android.support.v4.content.IntentCompat;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class CommonUtils {
	private static final String CLIPBOARD_LABEL = "saleslabel";

	public static void toastShort(Context context, CharSequence charSequence) {
		toastShort(context, String.valueOf(charSequence));
	}

	public static void toastShort(Context context, @StringRes int text) {
		toastShort(context, context.getString(text));
	}

	public static void toastShort(Context context, String text) {
		Toast.makeText(context, text, Toast.LENGTH_SHORT).show();
	}


	public static String md5(String message) {
		String digest = null;
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			byte[] hash = md.digest(message.getBytes("UTF-8"));
			StringBuilder sb = new StringBuilder(2 * hash.length);
			for (byte b : hash) {
				sb.append(String.format("%02x", b & 0xff));
			}
			digest = sb.toString();
		} catch (Exception ignored) {
		}
		return digest;
	}

	private static String convertToHex(byte[] data) {
		StringBuilder buf = new StringBuilder();
		for (byte b : data) {
			int halfbyte = (b >>> 4) & 0x0F;
			int two_halfs = 0;
			do {
				buf.append((0 <= halfbyte) && (halfbyte <= 9) ? (char) ('0' + halfbyte) : (char) ('a' + (halfbyte - 10)));
				halfbyte = b & 0x0F;
			} while (two_halfs++ < 1);
		}
		return buf.toString();
	}

	public static String md5SHA1(String text) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		text = CommonUtils.md5(text);
		MessageDigest md = MessageDigest.getInstance("SHA-1");
		md.update(text.getBytes("iso-8859-1"), 0, text.length());
		byte[] sha1hash = md.digest();
		return convertToHex(sha1hash);
	}

	public static void copyText(Context context, String text) {
		ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
		ClipData clip = ClipData.newPlainText(CLIPBOARD_LABEL, text);
		clipboard.setPrimaryClip(clip);
	}

	public static void restartApp(Context context) {
		Intent intent = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
		intent = IntentCompat.makeRestartActivityTask(intent.getComponent());
		context.startActivity(intent);
	}

	public static String dumpLocationInfo(Location loc) {
		if (loc == null) {
			return "Location null or empty";
		}
		return String.format("lat: %f, lng: %f, acc: %f, provider: %s",
				loc.getLatitude(), loc.getLongitude(), loc.getAccuracy(),
				loc.getProvider());
	}

	public static void hideKeyboard(View editText) {
		try {
			InputMethodManager imm = (InputMethodManager) editText.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
		} catch (Exception ignored) {
		}
	}

	public static void showKeyboard(View editText) {
		try {
			InputMethodManager imm = (InputMethodManager) editText.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
			imm.showSoftInput(editText, 0);
		} catch (Exception ignored) {
		}
	}

	public static boolean isLollipopOrAbove() {
		return Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP;
	}

}