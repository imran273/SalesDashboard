package com.mandiri.salestools.utils;

import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;

import com.mandiri.salestools.model.DeviceImage;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

/**
 * Created by esa on 10/11/14.
 */
public class BitmapUtils {

	public static void addImageToGallery(final String filePath, final Context context) {

		ContentValues values = new ContentValues();

		values.put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis());
		values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
		values.put(MediaStore.MediaColumns.DATA, filePath);

		context.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
	}

	public static Bitmap getScaledBitmap(Bitmap bmp, Bitmap.CompressFormat format, int maxSize) {
		BitmapFactory.Options option = new BitmapFactory.Options();
		option.inJustDecodeBounds = true;
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		bmp.compress(format, 100, baos);

		byte[] byteSrc = baos.toByteArray();
		BitmapFactory.decodeByteArray(byteSrc, 0, byteSrc.length, option);

		int w = option.outWidth;
		int h = option.outHeight;
		option.inSampleSize = 1;

		if (w > maxSize || h > maxSize)
			option.inSampleSize = Math.min(Math.round((float) w / maxSize), Math.round((float) h / maxSize));
		option.inJustDecodeBounds = false;

		return BitmapFactory.decodeByteArray(byteSrc, 0, byteSrc.length, option);
	}

	public static Bitmap getScaledBitmap(InputStream inputStream, int maxSize) {
		final BufferedInputStream is = new BufferedInputStream(inputStream, 32 * 1024);
		try {
			final BitmapFactory.Options decodeBitmapOptions = new BitmapFactory.Options();

			if (maxSize > 0 && maxSize > 0) {
				final BitmapFactory.Options decodeBoundsOptions = new BitmapFactory.Options();
				decodeBoundsOptions.inJustDecodeBounds = true;
				is.mark(8 * 1024);
				BitmapFactory.decodeStream(is, null, decodeBoundsOptions);
				is.reset();

				final int originalWidth = decodeBoundsOptions.outWidth;
				final int originalHeight = decodeBoundsOptions.outHeight;

				decodeBitmapOptions.inSampleSize = Math.max(1, Math.min(originalWidth / maxSize, originalHeight / maxSize));
			}
			return BitmapFactory.decodeStream(is, null, decodeBitmapOptions);
		} catch (IOException e) {
			Logger.log(e);
			return null;
		} finally {
			try {
				inputStream.close();
			} catch (IOException ignored) {
			}
		}
	}

	public static Bitmap getScaledBitmap(String filePath, int maxSize) {
		BitmapFactory.Options option = new BitmapFactory.Options();
		option.inJustDecodeBounds = true;

		BitmapFactory.decodeFile(filePath, option);

		int w = option.outWidth;
		int h = option.outHeight;
		option.inSampleSize = 1;

		if (w > maxSize || h > maxSize)
			option.inSampleSize = Math.min(Math.round((float) w / maxSize), Math.round((float) h / maxSize));
		option.inJustDecodeBounds = false;

		return BitmapFactory.decodeFile(filePath, option);
	}

	public static Bitmap getScaledDeviceImage(DeviceImage deviceImage, int maxSize) {

		Matrix matrix = new Matrix();
		matrix.postRotate(deviceImage.getOrientation());

		if (deviceImage.getOrientation() == 0)
			matrix = getImageOrientationMatrix(deviceImage.getAvailableImage());

		Bitmap bitmap = getScaledBitmap(deviceImage.getAvailableImage(), maxSize);

		if (bitmap == null)
			return null;

		return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(),
				matrix, false);
	}

	public static Bitmap getBitmapFromCamera(String filePath, int maxSize) {

		Bitmap bitmap = getScaledBitmap(filePath, maxSize);
		return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(),
				getImageOrientationMatrix(filePath), false);
	}

	public static Matrix getImageOrientationMatrix(String filePath) {
		try {
			int rotate = 0;

			File imageFile = new File(filePath);
			ExifInterface exif = new ExifInterface(imageFile.getAbsolutePath());

			int orientation = exif.getAttributeInt(
					ExifInterface.TAG_ORIENTATION,
					ExifInterface.ORIENTATION_NORMAL);

			Matrix matrix = new Matrix();

			switch (orientation) {
				case ExifInterface.ORIENTATION_ROTATE_270:
					rotate = 270;
					break;
				case ExifInterface.ORIENTATION_ROTATE_180:
					rotate = 180;
					break;
				case ExifInterface.ORIENTATION_ROTATE_90:
					rotate = 90;
					break;
				case ExifInterface.ORIENTATION_FLIP_HORIZONTAL:
					matrix.setScale(-1, 1);
					break;
				case ExifInterface.ORIENTATION_FLIP_VERTICAL:
					rotate = 180;
					matrix.postScale(-1, 1);
					break;
				case ExifInterface.ORIENTATION_TRANSPOSE:
					rotate = 90;
					matrix.postScale(-1, 1);
					break;
				case ExifInterface.ORIENTATION_TRANSVERSE:
					rotate = -90;
					matrix.postScale(-1, 1);
					break;
			}
			Logger.log(Log.DEBUG, "Exif rotation :" + rotate);

			matrix.postRotate(rotate);
			return matrix;

		} catch (Exception e) {
			Logger.log(e);
		}
		return null;
	}

	public static Bitmap base64StringToBitmap(String base64) {
		byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
		return BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
	}

	public static String bitmapToBase64String(Bitmap bmp, int quality) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		bmp.compress(Bitmap.CompressFormat.JPEG, quality, baos);
		byte[] bytes = baos.toByteArray();
		return Base64.encodeToString(bytes, Base64.DEFAULT);
	}

}
