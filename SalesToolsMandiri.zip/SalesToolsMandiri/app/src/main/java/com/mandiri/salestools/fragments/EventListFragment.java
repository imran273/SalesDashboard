package com.mandiri.salestools.fragments;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.mandiri.salestools.R;
import com.mandiri.salestools.adapter.BaseListAdapter;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class EventListFragment extends BaseFragment {

    @InjectView(R.id.lvContent)    ListView mLvContent;
    @InjectView(R.id.lyRefresh)    SwipeRefreshLayout mSwipeRefreshLayout;

    private EventListApdater mListApdater;

    public static EventListFragment newInstance() {
        return new EventListFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        setHasOptionsMenu(true);
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_event_list, container, false);
        ButterKnife.inject(this, rootView);
        setupUI();
        return rootView;
    }

    private void setupUI() {
        mSwipeRefreshLayout.setColorSchemeResources(R.color.primary, R.color.accentColor);
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mSwipeRefreshLayout.setRefreshing(false);
            }
        });

        View headerView = getBaseActivity().getLayoutInflater().inflate(R.layout.header_calendar, null);
        mLvContent.addHeaderView(headerView);

        mListApdater = new EventListApdater(mContext);
        mLvContent.setAdapter(mListApdater);
        mLvContent.setDividerHeight(getResources().getDimensionPixelSize(R.dimen.view_padding_small));
        mLvContent.setDivider(new ColorDrawable(Color.TRANSPARENT));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_notification:
                Toast.makeText(mContext, "Notification", Toast.LENGTH_LONG).show();
            case R.id.menu_chat:
                Toast.makeText(mContext, "Chat", Toast.LENGTH_LONG).show();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.reset(this);
    }

    private class EventListApdater extends BaseListAdapter<String> {

        public EventListApdater(Context context) {
            super(context);
        }

        @Override
        public int getCount() {
            return 10;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            CardViewHolder viewHolder;
            if (convertView == null) {
                convertView = mInflater.inflate(R.layout.list_item_event_card, parent, false);
                viewHolder = new CardViewHolder(convertView);
            } else
                viewHolder = (CardViewHolder) convertView.getTag();

            return convertView;
        }
    }

    static class CardViewHolder {

//		@InjectView(R.id.txtTitle) AppCompatTextView txtTitle;

        CardViewHolder(View view) {
            ButterKnife.inject(this, view);
            view.setTag(this);
        }
    }
}