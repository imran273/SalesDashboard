package com.mandiri.salestools.fragments;

import android.app.Activity;
import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.widget.Toast;

import com.mandiri.salestools.BaseActivity;

/**
 * Created by esa on 02/10/14.
 */
public class BaseFragment extends Fragment {

	protected Context mContext;
	protected LayoutInflater mInflater;

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		mContext = activity;
		mInflater = LayoutInflater.from(activity);
	}

	public ActionBar getActionBar() {
		return ((AppCompatActivity) getActivity()).getSupportActionBar();
	}

	public void finish() {
		if (isAdded())
			getActivity().finish();
	}

	public BaseActivity getBaseActivity() {
		return (BaseActivity) getActivity();
	}


	protected void showStockToast(int message) {
		if (isAdded())
			showStockToast(getString(message));
	}

	protected void showStockToast(String message) {
		if (isAdded()) {
			Toast toast = Toast.makeText(mContext, message, Toast.LENGTH_SHORT);
			toast.show();
		}
	}
}
