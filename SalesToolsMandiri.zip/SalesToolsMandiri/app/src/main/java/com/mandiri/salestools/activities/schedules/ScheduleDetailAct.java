package com.mandiri.salestools.activities.schedules;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.TextView;

import com.balysv.materialmenu.MaterialMenuDrawable;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.mandiri.salestools.BaseActivity;
import com.mandiri.salestools.R;
import com.mandiri.salestools.activities.add.AddRealizationAct;
import com.mandiri.salestools.apiservice.SchedulesApiService;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.schedule.Schedule;
import com.mandiri.salestools.utils.CommonUtils;

import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

/**
 * Created by esa on 20/06/15, with awesomeness
 */
public class ScheduleDetailAct extends BaseActivity implements OnMapReadyCallback {

	@InjectView(R.id.toolbar) Toolbar mToolbar;
	@InjectView(R.id.txtCaption) TextView mTxtCaption;
	@InjectView(R.id.txtTitle) TextView mTxtTitle;
	@InjectView(R.id.txtStatus) TextView mTxtStatus;
	@InjectView(R.id.inpTeam) TextView mInpTeam;
	@InjectView(R.id.inpTeamClient) TextView mInpTeamClient;
	@InjectView(R.id.inpPic) TextView mInpPic;
	@InjectView(R.id.inpContent) TextView mTxtDescription;
	@InjectView(R.id.btnSubmit) TextView mTxtLocation;

	private Schedule mSchedule;

	private GoogleMap mGoogleMap;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_schedule_detail);
		ButterKnife.inject(this);

		setupToolbar(mToolbar);
		materialMenuIcon.setState(MaterialMenuDrawable.IconState.X);

		MapFragment mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.map);
		mapFragment.getMapAsync(this);

		Bundle bundle = getIntent().getExtras();
		mSchedule = bundle.getParcelable(Schedule.class.getSimpleName());
		setupUI();

		SchedulesApiService apiService = new SchedulesApiService(mContext);
		apiService.loadSchedulesFull(mSchedule.getId(), new EventCallback<List<Schedule>>() {
			@Override
			public void onEvent(List<Schedule> schedules, Bundle bundle) {
				if (schedules == null) {
					CommonUtils.toastShort(mContext, R.string.error_string);
					return;
				}
				mSchedule = schedules.get(0);
				setupUI();
			}
		});
	}

	@Override
	public void onMapReady(GoogleMap googleMap) {
		mGoogleMap = googleMap;
		setupMap();
	}

	private void setupMap() {
		LatLng position = new LatLng(-6.2087630, 106.8455990);
		mGoogleMap.addMarker(new MarkerOptions().title("Schedule Location").position(position));

		CameraPosition cameraPosition;
		cameraPosition = new CameraPosition.Builder()
				.target(position).zoom(mGoogleMap.getMaxZoomLevel())
				.bearing(0)
				.tilt(0)
				.build();
		mGoogleMap.moveCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
	}

	private void setupUI() {

		mTxtCaption.setText(mSchedule.getPlan());
		mInpPic.setText(mSchedule.getPic());
		mInpTeam.setText(mSchedule.getTeamMandiri());
		mInpTeamClient.setText(mSchedule.getTeamClient());
		mTxtLocation.setText(mSchedule.getLocation());
		mTxtDescription.setText(mSchedule.getDescription());

		if (mSchedule.getPipeline() != null) {
			mTxtStatus.setText(String.valueOf(mSchedule.getPipeline().getStatusId()));
			mTxtTitle.setText(mSchedule.getPipeline().getName());
		}
	}

	@OnClick(R.id.btnAddRealization)
	public void onAddRealizationClick() {
		AddRealizationAct.startForResult(this, mSchedule);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case android.R.id.home:
				finish();
				break;
		}
		return super.onOptionsItemSelected(item);
	}

	/* ------- LAUNCHER ----------- */

	public static void start(Context context, Schedule schedule) {
		context.startActivity(new Intent(context, ScheduleDetailAct.class).putExtra(Schedule
				.class.getSimpleName(), schedule));
	}

}
