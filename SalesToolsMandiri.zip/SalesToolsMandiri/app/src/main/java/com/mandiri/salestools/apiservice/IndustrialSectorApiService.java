package com.mandiri.salestools.apiservice;

import android.content.Context;
import android.util.Log;

import com.loopj.android.http.TextHttpResponseHandler;
import com.mandiri.salestools.constants.URLCons;
import com.mandiri.salestools.http.MandiriClient;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.IndustrialSectors;
import com.mandiri.salestools.utils.Logger;

import org.apache.http.Header;

/**
 * Created by esa on 16/08/15, with awesomeness
 */
public class IndustrialSectorApiService extends BaseApiService {
	public IndustrialSectorApiService(Context mContext) {
		super(mContext);
	}

	public void loadIndustrialSectors(final EventCallback<IndustrialSectors> eventCallback) {
		MandiriClient.get(mContext, URLCons.INDUSTRIAL_SECTORS, new TextHttpResponseHandler() {
			@Override
			public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
				Logger.log(throwable);
				eventCallback.onEvent(null);
			}

			@Override
			public void onSuccess(int statusCode, Header[] headers, String responseString) {
				Logger.log(Log.DEBUG, "Response :" + responseString);
				try {
					IndustrialSectors sectors = getGson().fromJson(responseString, IndustrialSectors.class);
					if (sectors.getError().getMessage() == null) {
						eventCallback.onEvent(sectors);
					} else {
						eventCallback.onEvent(null);
					}
				} catch (Exception e) {
					onFailure(statusCode, headers, responseString, e);
				}
			}

		});
	}
}
