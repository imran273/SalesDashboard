package com.mandiri.salestools.model.schedule;

import android.os.Parcel;

import com.google.gson.annotations.SerializedName;
import com.mandiri.salestools.model.pipeline.Pipeline;

public class Schedule implements android.os.Parcelable {

	/**
	 * startDate : 2015-05-05T12:00:00.000Z
	 * teamClient : dummy team client
	 * createdAt : 2015-05-05T12:00:00.000Z
	 * teamMandiri : dummy team mandiri
	 * deletedAt : null
	 * description : Hai
	 * location : Yogyakarta
	 * id : 1
	 * pic : dummy
	 * offeringId : 1
	 * plan : Meeting awal aja berooh
	 * updatedAt : 2015-05-05T12:00:00.000Z
	 */

	private String startDate;
	private String endDate;
	private String teamClient;
	private String createdAt;
	private String teamMandiri;
	private String deletedAt;
	private String description;
	private String location;
	private String id;
	private String pic;
	private String offeringId;
	private String plan;
	private String updatedAt;
	private String color;

    //for add only
    private String salesId;

	@SerializedName("offering")
	private Pipeline pipeline;

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public void setTeamClient(String teamClient) {
		this.teamClient = teamClient;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public void setTeamMandiri(String teamMandiri) {
		this.teamMandiri = teamMandiri;
	}

	public void setDeletedAt(String deletedAt) {
		this.deletedAt = deletedAt;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setPic(String pic) {
		this.pic = pic;
	}

	public void setOfferingId(String offeringId) {
		this.offeringId = offeringId;
	}

	public void setPlan(String plan) {
		this.plan = plan;
	}

	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getStartDate() {
		return startDate;
	}

	public String getTeamClient() {
		return teamClient;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public String getTeamMandiri() {
		return teamMandiri;
	}

	public String getDeletedAt() {
		return deletedAt;
	}

	public String getDescription() {
		return description;
	}

	public String getLocation() {
		return location;
	}

	public String getId() {
		return id;
	}

	public String getPic() {
		return pic;
	}

	public String getOfferingId() {
		return offeringId;
	}

	public String getPlan() {
		return plan;
	}

	public String getUpdatedAt() {
		return updatedAt;
	}

    public String getSalesId() {
        return salesId;
    }

    public void setSalesId(String salesId) {
        this.salesId = salesId;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public Schedule() {
	}

	public Pipeline getPipeline() {
		return pipeline;
	}

	public void setPipeline(Pipeline pipeline) {
		this.pipeline = pipeline;
	}

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.startDate);
        dest.writeString(this.endDate);
        dest.writeString(this.teamClient);
        dest.writeString(this.createdAt);
        dest.writeString(this.teamMandiri);
        dest.writeString(this.deletedAt);
        dest.writeString(this.description);
        dest.writeString(this.location);
        dest.writeString(this.id);
        dest.writeString(this.pic);
        dest.writeString(this.offeringId);
        dest.writeString(this.plan);
        dest.writeString(this.updatedAt);
        dest.writeString(this.salesId);
	    dest.writeString(this.color);
        dest.writeParcelable(this.pipeline, 0);
    }

    protected Schedule(Parcel in) {
        this.startDate = in.readString();
        this.endDate = in.readString();
        this.teamClient = in.readString();
        this.createdAt = in.readString();
        this.teamMandiri = in.readString();
        this.deletedAt = in.readString();
        this.description = in.readString();
        this.location = in.readString();
        this.id = in.readString();
        this.pic = in.readString();
        this.offeringId = in.readString();
        this.plan = in.readString();
        this.updatedAt = in.readString();
        this.salesId = in.readString();
	    this.color = in.readString();
        this.pipeline = in.readParcelable(Pipeline.class.getClassLoader());
    }

    public static final Creator<Schedule> CREATOR = new Creator<Schedule>() {
        public Schedule createFromParcel(Parcel source) {
            return new Schedule(source);
        }

        public Schedule[] newArray(int size) {
            return new Schedule[size];
        }
    };

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
}