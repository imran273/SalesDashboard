package com.mandiri.salestools.widget;

import android.content.Context;
import android.hardware.Camera;
import android.os.Handler;
import android.os.Looper;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import com.mandiri.salestools.utils.Logger;

import java.util.List;

public class CameraPreview extends SurfaceView implements SurfaceHolder.Callback {

	private static final int RETRY_TIME = 1000;

	private Handler mHandler = new Handler(Looper.getMainLooper());

	SurfaceHolder mHolder;
	Camera mCamera;

	private boolean isAlreadyRetry;

	public CameraPreview(Context context) {
		super(context);
		mHolder = getHolder();
		mHolder.addCallback(this);
	}

	public void surfaceCreated(final SurfaceHolder holder) {
		createCamera(holder);
	}

	private void createCamera(final SurfaceHolder holder) {
		try {
			mCamera = Camera.open();
			mCamera.setPreviewDisplay(holder);
		} catch (Exception e) {
			Logger.log(e);

			if (!isAlreadyRetry) {
				if (mCamera != null)
					mCamera.release();

				mHandler.postDelayed(new Runnable() {
					@Override
					public void run() {
						createCamera(holder);
						isAlreadyRetry = true;
					}
				}, RETRY_TIME);
			}
		}
	}

	public void surfaceDestroyed(SurfaceHolder holder) {
		closeCamera();
	}

	public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
		openCamera(w, h);
	}

	public void closeCamera() {
		isAlreadyRetry = false;
		if (mCamera != null) {
			mCamera.stopPreview();
			mCamera.release();
			mCamera = null;
		}
	}

	private void openCamera(int w, int h) {
		if (mCamera == null)
			return;

		Camera.Parameters parameters = mCamera.getParameters();
		Camera.Size previewSize = determineBestPreviewSize(parameters, w, h);
		parameters.setPreviewSize(previewSize.width, previewSize.height);

		mCamera.setDisplayOrientation(90);
		mCamera.setParameters(parameters);
		mCamera.startPreview();
	}

	private Camera.Size determineBestPreviewSize(Camera.Parameters parameters, int width, int height) {
		List<Camera.Size> sizes = parameters.getSupportedPreviewSizes();
		return getOptimalPreviewSize(sizes, width, height);
	}

	private Camera.Size getOptimalPreviewSize(List<Camera.Size> sizes, int w, int h) {
		final double ASPECT_TOLERANCE = 0.1;
		double targetRatio = (double) h / w;

		if (sizes == null) return null;

		Camera.Size optimalSize = null;
		double minDiff = Double.MAX_VALUE;

		for (Camera.Size size : sizes) {
			double ratio = (double) size.width / size.height;
			if (Math.abs(ratio - targetRatio) > ASPECT_TOLERANCE) continue;
			if (Math.abs(size.height - h) < minDiff) {
				optimalSize = size;
				minDiff = Math.abs(size.height - h);
			}
		}

		if (optimalSize == null) {
			minDiff = Double.MAX_VALUE;
			for (Camera.Size size : sizes) {
				if (Math.abs(size.height - h) < minDiff) {
					optimalSize = size;
					minDiff = Math.abs(size.height - h);
				}
			}
		}
		return optimalSize;
	}

}