package com.mandiri.salestools.apiservice;

import android.content.Context;

import com.loopj.android.http.TextHttpResponseHandler;
import com.mandiri.salestools.constants.URLCons;
import com.mandiri.salestools.http.MandiriClient;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.CIFs;

import org.apache.http.Header;

import java.util.List;

/**
 * Created by esa on 17/08/15, with awesomeness
 */
public class CIFApiService extends BaseApiService {
	public CIFApiService(Context mContext) {
		super(mContext);
	}

	public void postCIF(CIFs.CIF cif, final EventCallback<Boolean> eventCallback) {
		String json = getGson().toJson(cif);

		MandiriClient.postJSON(mContext, URLCons.CIF, json, new TextHttpResponseHandler() {
			@Override
			public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
				onHandleError(eventCallback, throwable);
			}

			@Override
			public void onSuccess(int statusCode, Header[] headers, String responseString) {
				onHandleSuccess(responseString);
			}
		});
	}

	public void postBulkCIF(List<CIFs.CIF> cif, final EventCallback<Boolean> eventCallback) {

		String json = getGson().toJson(cif.toArray());

		MandiriClient.postJSON(mContext, URLCons.CIF_BULK, json, new TextHttpResponseHandler() {
			@Override
			public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
				onHandleError(eventCallback, throwable);
			}

			@Override
			public void onSuccess(int statusCode, Header[] headers, String responseString) {
				onHandleSuccess(responseString);
				eventCallback.onEvent(true);
			}
		});
	}
}
