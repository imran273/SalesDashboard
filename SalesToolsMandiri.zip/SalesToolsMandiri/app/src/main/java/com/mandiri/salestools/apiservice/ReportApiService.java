package com.mandiri.salestools.apiservice;

import android.content.Context;
import android.util.Log;

import com.loopj.android.http.TextHttpResponseHandler;
import com.mandiri.salestools.constants.URLCons;
import com.mandiri.salestools.http.MandiriClient;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.report.Report;
import com.mandiri.salestools.model.report.ReportDao;
import com.mandiri.salestools.utils.Logger;

import org.apache.http.Header;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

public class ReportApiService extends BaseApiService {

	public ReportApiService(Context mContext) {
		super(mContext);
	}

    public void loadReportsFull(final EventCallback<List<Report>> eventCallback) {
        loadReports(URLCons.REPORTS_FULL, eventCallback);
    }

    public void loadReports(final EventCallback<List<Report>> eventCallback) {
        loadReports(URLCons.REPORTS, eventCallback);
    }

	private void loadReports(final String url,
	                    final EventCallback<List<Report>> eventCallback) {
		MandiriClient.get(mContext, url, new TextHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, String response) {
                Logger.log(Log.DEBUG, "Response :" + response);
                try {
                    ReportDao baseApiDao = getGson().fromJson(response, ReportDao.class);
                    if (baseApiDao.getError().getMessage() == null) {
                        List<Report> report = baseApiDao.getReports();

                        eventCallback.onEvent(report);
                    } else {
                        eventCallback.onEvent(null);
                    }
                } catch (Exception e) {
                    onFailure(statusCode, headers, response, e);
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                Logger.log(throwable);
                eventCallback.onEvent(null);
            }
        });
	}

	public void doAddReport(Report report,
	                    final EventCallback<Report> eventCallback) {

        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String date = df.format(Calendar.getInstance().getTime());
        report.setDate(date);
//        report.setSalesId(Preferences.getSalesId(mContext));
        String json = getGson().toJson(report);

		MandiriClient.postJSON(mContext, URLCons.REPORTS_ACTIONS, json, new TextHttpResponseHandler() {
			@Override
			public void onSuccess(int statusCode, Header[] headers, String response) {
				Logger.log(Log.DEBUG, "Response :" + response);
				try {
					ReportDao baseApiDao = getGson().fromJson(response, ReportDao.class);
					if (baseApiDao.getError().getMessage() == null) {
                        Report report = baseApiDao.getReports().get(0);
						eventCallback.onEvent(report);
					} else {
						eventCallback.onEvent(null);
					}
				} catch (Exception e) {
					onFailure(statusCode, headers, response, e);
				}
			}

			@Override
			public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
				Logger.log(throwable);
				eventCallback.onEvent(null);
			}
		});
	}
}
