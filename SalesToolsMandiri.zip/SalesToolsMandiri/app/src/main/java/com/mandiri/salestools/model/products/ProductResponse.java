package com.mandiri.salestools.model.products;

import android.os.Parcel;

import com.mandiri.salestools.model.BaseDao;

import java.util.List;

/**
 * Created by esa on 04/06/15, with awesomeness
 */
public class ProductResponse extends BaseDao {

	private List<Product> products;

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		super.writeToParcel(dest, flags);
		dest.writeTypedList(products);
	}

	public ProductResponse() {
	}

	protected ProductResponse(Parcel in) {
		this.products = in.createTypedArrayList(Product.CREATOR);
	}

	public static final Creator<ProductResponse> CREATOR = new Creator<ProductResponse>() {
		public ProductResponse createFromParcel(Parcel source) {
			return new ProductResponse(source);
		}

		public ProductResponse[] newArray(int size) {
			return new ProductResponse[size];
		}
	};
}
