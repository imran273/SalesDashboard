package com.mandiri.salestools;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.balysv.materialmenu.MaterialMenuDrawable;
import com.mandiri.salestools.fragments.BaseFragment;
import com.mandiri.salestools.fragments.ClientListFragment;
import com.mandiri.salestools.fragments.PipelineListFragment;
import com.mandiri.salestools.fragments.ProductListFragment;
import com.mandiri.salestools.fragments.RealizationListFragment;
import com.mandiri.salestools.fragments.ReportListFragment;
import com.mandiri.salestools.fragments.ScheduleFragment;
import com.mandiri.salestools.fragments.dashboard.DashboardFragment;
import com.mandiri.salestools.utils.CommonUtils;
import com.mandiri.salestools.utils.Preferences;
import com.mandiri.salestools.widget.RippleDrawable;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class MainSalesAct extends BaseActivity implements NavigationView.OnNavigationItemSelectedListener {

	public static int TYPE_PIPELINE = 1;
	public static int TYPE_SCHEDULE = 2;

	public static String IS_VIEW_REPORTS = "isViewReports";

	@InjectView(R.id.toolbar) Toolbar mToolbar;
	@InjectView(R.id.drawerLayout) DrawerLayout drawerLayout;
	@InjectView(R.id.navigationView) NavigationView navigationView;
	@InjectView(R.id.bgContent) ImageView bgContent;
	@InjectView(R.id.txtFullName) TextView txtFullName;
	@InjectView(R.id.txtEmail) TextView txtEmail;

	private BaseFragment mCurrentFragment;
	private FragmentManager fragmentManager;
	private MenuItem menuItemPipeline;
	private MenuItem menuItemSchedule;
	private MenuItem menuItemReports;

    private boolean mCanQuit = false;
    private boolean mIsViewReports = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main_sales);
		ButterKnife.inject(this);

		setupToolbar();
		materialMenuIcon.setState(drawerLayout.isDrawerOpen(GravityCompat.START) ?
				MaterialMenuDrawable.IconState.ARROW : MaterialMenuDrawable.IconState.BURGER);

		Menu menuNavView = navigationView.getMenu();
		menuItemPipeline = menuNavView.findItem(R.id.drawer_pipelines);
		menuItemSchedule = menuNavView.findItem(R.id.drawer_schedules);
        menuItemReports = menuNavView.findItem(R.id.drawer_reports);

        mIsViewReports = getIntent().getBooleanExtra(IS_VIEW_REPORTS, false);

        if (!mIsViewReports){
            mCurrentFragment = DashboardFragment.newInstance();
        }else{
            menuItemReports.setChecked(true);
            mCurrentFragment = ReportListFragment.newInstance();
        }

		fragmentManager = getSupportFragmentManager();
		fragmentManager.beginTransaction()
				.replace(R.id.content, mCurrentFragment)
				.commit();

		RippleDrawable.createRipple(bgContent, getResources().getColor(R.color.ripple_material_dark));
		setupDrawerContent(navigationView);

		setupHeaderView();
	}

	private void setupToolbar() {
		setupToolbar(mToolbar, new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				if (drawerLayout.isDrawerOpen(GravityCompat.START))
					drawerLayout.closeDrawers();
				else {
					drawerLayout.openDrawer(navigationView);
				}
			}
		});
	}

	private void setupDrawerContent(NavigationView navigationView) {
		navigationView.setNavigationItemSelectedListener(this);
	}

	@Override
	public boolean onNavigationItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case R.id.drawer_dashboard:
				mCurrentFragment = DashboardFragment.newInstance();
				break;
			case R.id.drawer_clients:
				mCurrentFragment = ClientListFragment.newInstance();
				break;
			case R.id.drawer_pipelines:
				mCurrentFragment = PipelineListFragment.newInstance();
				break;
			case R.id.drawer_products:
				mCurrentFragment = ProductListFragment.newInstance();
				break;
			case R.id.drawer_schedules:
				mCurrentFragment = ScheduleFragment.newInstance();
				break;
			case R.id.drawer_realization:
				mCurrentFragment = RealizationListFragment.newInstance();
				break;
			case R.id.drawer_reports:
				mCurrentFragment = ReportListFragment.newInstance();
				break;
			default:
				CommonUtils.toastShort(mContext, item.getTitle());
				break;
		}
		navigateToFragment(mCurrentFragment);

		item.setChecked(true);
		drawerLayout.closeDrawers();
		return false;
	}

//    public void navigateToCallReports(){
//        fragmentManager = getSupportFragmentManager();
//        fragmentManager.beginTransaction()
//                .replace(R.id.content, ReportListFragment.newInstance())
//                .commit();
//    }

	private void navigateToFragment(BaseFragment baseFragment) {
		fragmentManager = getSupportFragmentManager();
		fragmentManager.beginTransaction()
				.replace(R.id.content, baseFragment)
				.commit();
	}

	public void setupFragment(int type) {
		if (type == TYPE_PIPELINE) {
			mCurrentFragment = PipelineListFragment.newInstance();
			menuItemPipeline.setChecked(true);
		} else {
			mCurrentFragment = ScheduleFragment.newInstance();
			menuItemSchedule.setChecked(true);
		}

		fragmentManager = getSupportFragmentManager();
		fragmentManager.beginTransaction()
				.replace(R.id.content, mCurrentFragment)
				.commit();
	}

	private void setupHeaderView() {
		txtFullName.setText(Preferences.getName(mContext));
		txtEmail.setText(Preferences.getEmail(mContext));
	}

	@Override
	public void finish() {
		if (mCurrentFragment instanceof DashboardFragment){
            if (mCanQuit) {
                super.finish();
                return;
            }

            Toast.makeText(this, R.string.back_again_to_quit,
                    Toast.LENGTH_SHORT).show();

            mCanQuit = true;
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    mCanQuit = false;
                }
            }, 3000);

        }else{
            onNavigationItemSelected(navigationView.getMenu().findItem(R.id.drawer_dashboard));
        }
	}

//    @OnClick(R.id.bgContent)
//    public void onHeaderDrawerClick() {
//        ProfileAct.start(mContext);
//    }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.menu_main, menu);
//        menuItemPipeline = menu.findItem(R.id.drawer_pipelines);
//        menuItemSchedule = menu.findItem(R.id.drawer_schedules);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case android.R.id.home:
				drawerLayout.openDrawer(GravityCompat.START);
				return true;
			case R.id.action_logout:
				Preferences.clear(mContext);
				LoginAct.start(mContext);
				finish();
				return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/* -------- Initiator ------------- */

	public static void start(Context context) {
		Intent intent = new Intent(context, MainSalesAct.class);
		context.startActivity(intent);
	}

	public static void start(Context context, boolean isCallReports) {
		Intent intent = new Intent(context, MainSalesAct.class);
        intent.putExtra(IS_VIEW_REPORTS, isCallReports);
		context.startActivity(intent);
	}
}
