package com.mandiri.salestools.adapter;

import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.listener.PauseOnScrollListener;
import com.mandiri.salestools.R;
import com.mandiri.salestools.model.DeviceImage;
import com.mandiri.salestools.utils.BitmapUtils;
import com.mandiri.salestools.utils.helper.MediaStoreHelper;
import com.mandiri.salestools.widget.CameraPreview;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import butterknife.ButterKnife;
import butterknife.InjectView;

/**
 * Created by esa on 06/01/15, with awesomeness
 */
public class PhoneGalleryAdapter extends BaseListAdapter<DeviceImage> {

	private CameraPreview mCameraPreview;
	private ExecutorService mExecutorService = Executors.newFixedThreadPool(5);
	private Handler mHandler = new Handler(Looper.getMainLooper());

	private int mCellSize;
	private int mPadding;

	private boolean isUsingHeader;


	public PhoneGalleryAdapter(AbsListView absListView, int cellSize, final AbsListView.OnScrollListener onScrollListener) {
		this(absListView, false, cellSize, onScrollListener);
	}

	public PhoneGalleryAdapter(AbsListView absListView, boolean isUsingHeader, int cellSize, final AbsListView.OnScrollListener onScrollListener) {
		super(absListView.getContext());

		this.isUsingHeader = isUsingHeader;

		mCellSize = cellSize;
		mPadding = absListView.getContext().getResources().getDimensionPixelSize(R.dimen.view_padding_small);

		ImageLoader mImageLoader = ImageLoader.getInstance();
		final PauseOnScrollListener pauseOnScrollListener = new PauseOnScrollListener(mImageLoader, false, true);
		absListView.setOnScrollListener(new AbsListView.OnScrollListener() {
			@Override
			public void onScrollStateChanged(AbsListView absListView, int i) {
				if (onScrollListener != null)
					onScrollListener.onScrollStateChanged(absListView, i);
//				pauseOnScrollListener.onScrollStateChanged(absListView, i);
			}

			@Override
			public void onScroll(AbsListView absListView, int i, int i2, int i3) {
				if (onScrollListener != null)
					onScrollListener.onScroll(absListView, i, i2, i3);
//				pauseOnScrollListener.onScroll(absListView, i, i2, i3);
			}
		});
	}

	public void releaseCamera() {
		mCameraPreview.closeCamera();
	}

	public CameraPreview getCameraPreview() {
		if (mCameraPreview == null)
			mCameraPreview = new CameraPreview(mContext);
		return mCameraPreview;
	}

	public int getCount() {
		if (super.getCount() > 0)
			return !isUsingHeader ? super.getCount() + 1 : super.getCount();
		return 0;
	}

	@Override
	public int getViewTypeCount() {
		return 2;
	}

	@Override
	public int getItemViewType(int position) {
		if (position == 0) {
			return 0;
		} else
			return 1;
	}

	@Override
	public DeviceImage getItem(int position) {
		return super.getItem(position - 1);
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {

		if (position == 0 && !isUsingHeader) {
			CameraItemViewHolder viewHolder;
			if (convertView == null) {
				convertView = mInflater.inflate(R.layout.list_item_phone_gallery_camera, parent, false);
				convertView.setLayoutParams(new GridView.LayoutParams(mCellSize, mCellSize));

				if (mCameraPreview == null) {
					mCameraPreview = new CameraPreview(mContext);
					viewHolder = new CameraItemViewHolder(convertView);
					viewHolder.mContainer.addView(mCameraPreview);
				}
			}
		} else {
			final PhoneGalleryViewHolder viewHolder;
			if (convertView == null) {
				convertView = mInflater.inflate(R.layout.list_item_phone_gallery, parent, false);
				convertView.setLayoutParams(new GridView.LayoutParams(mCellSize, mCellSize));
				viewHolder = new PhoneGalleryViewHolder(convertView);
			} else {
				viewHolder = (PhoneGalleryViewHolder) convertView.getTag();
				viewHolder.mImgContent.setImageDrawable(null);
			}

			final int actualPosition = isUsingHeader ? position : position - 1;
			final DeviceImage deviceImage = mListData.get(actualPosition);
			if (deviceImage.getThumbnail() == null) {
				String thumbnail = MediaStoreHelper.getThumbnailImages(mContext, deviceImage.getId(), deviceImage.getBucketId());
				deviceImage.setThumbnail((thumbnail != null ? thumbnail : deviceImage.getFilePath()));
			}
			calculateItemPadding(convertView, position);

			final Matrix matrix = new Matrix();
			matrix.postRotate(deviceImage.getOrientation());

			viewHolder.position = position;
			mExecutorService.execute(new Runnable() {
				@Override
				public void run() {
					final Bitmap bitmap = BitmapUtils.getScaledDeviceImage(deviceImage, 100);
					mHandler.post(new Runnable() {
						@Override
						public void run() {
							if (viewHolder.position == position) {
								if (bitmap == null) {
									viewHolder.mImgContent.setImageResource(R.drawable.ic_placeholder);
									mListData.get(actualPosition).setCoruppted(true);
								} else
									viewHolder.mImgContent.setImageBitmap(bitmap);
							}
						}
					});
				}
			});
		}
		return convertView;
	}

	protected void calculateItemPadding(View convertView, int position) {
		boolean isAddPadding = (position - 2) >= 0 && (position - 2) % 3 == 0;
		convertView.setPadding(convertView.getPaddingLeft(), convertView.getPaddingTop(),
				isAddPadding ? mPadding : 0, convertView.getPaddingBottom());
	}

	/* ------------------ VIEWHOLDER ---------------------- */

	static class PhoneGalleryViewHolder {

		@InjectView(R.id.imgContent) ImageView mImgContent;

		private int position;

		PhoneGalleryViewHolder(View view) {
			ButterKnife.inject(this, view);
			view.setTag(this);
		}
	}

	static class CameraItemViewHolder {

		@InjectView(R.id.lyContainer) FrameLayout mContainer;

		CameraItemViewHolder(View view) {
			ButterKnife.inject(this, view);
			view.setTag(this);
		}
	}
}
