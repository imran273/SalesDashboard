package com.mandiri.salestools.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mandiri.salestools.R;
import com.mandiri.salestools.model.pic.PIC;
import com.mandiri.salestools.utils.ValidateUtils;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

/**
 * Created by esa on 17/08/15, with awesomeness
 */
public class PICInputForm extends LinearLayout {

	@InjectView(R.id.pic_form_title) TextView mTxtTitle;
	@InjectView(R.id.pic_form_name) EditText mInpName;
	@InjectView(R.id.pic_form_email) EditText mInpEmail;
	@InjectView(R.id.pic_form_phone) EditText mInpPhone;
	@InjectView(R.id.pic_form_position) EditText mInpPosition;

	private PICInputFormListener mListener;

	public PICInputForm(Context context) {
		this(context, null);
	}

	public PICInputForm(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public PICInputForm(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		init();
	}

	private void init() {
		setOrientation(LinearLayout.VERTICAL);
		LayoutInflater.from(getContext()).inflate(R.layout.view_pic_input_form, this, true);
		ButterKnife.inject(this);
	}

	public boolean isFormValid() {
		return ValidateUtils.runningValidationWithViews(getString(R.string.required), mInpName,
				  mInpPosition, mInpEmail, mInpPhone);
	}

	public void setTitle(String title) {
		mTxtTitle.setText(title);
	}

	public void setName(String name) {
		mInpName.setText(name);
	}

	public void setEmail(String email) {
		mInpEmail.setText(email);
	}

	public PIC getPIC() {
		PIC pic = new PIC();
		pic.setName(mInpName.getText().toString());
		pic.setPhone(mInpPhone.getText().toString());
		pic.setPosition(mInpPosition.getText().toString());
		pic.setEmail(mInpEmail.getText().toString());
		return pic;
	}


	private String getString(int resId) {
		return getContext().getString(resId);
	}

	public void setListener(PICInputFormListener listener) {
		mListener = listener;
	}

	@OnClick(R.id.pic_form_delete)
	public void onDeleteClick() {
		if (mListener != null)
			mListener.onDeleteButtonClick(this);
	}

	public interface PICInputFormListener {
		void onDeleteButtonClick(PICInputForm picInputForm);
	}
}
