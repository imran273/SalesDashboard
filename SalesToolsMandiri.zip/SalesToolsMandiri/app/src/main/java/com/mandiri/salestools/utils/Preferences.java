package com.mandiri.salestools.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;

import com.google.gson.Gson;
import com.mandiri.salestools.model.users.User;

/**
 * Created by deni on 20/05/2015.
 */
public class Preferences {

    public static final String USER = "Pref.User";
    public static final String NAME = "Pref.Name";
    public static final String USER_ID = "Pref.UserId";
    public static final String TOKEN = "Pref.Token";
    public static final String ROLE = "Pref.Role";
    public static final String ROLE_ID = "Pref.RoleId";
    public static final String EMAIL = "Pref.Email";
    public static final String SALES_ID = "Pref.SalesId";
    public static final String DEP_ID = "Pref.DepartementId";

    private static SharedPreferences getSharedPreference(Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context);
    }

    public static void clear(Context context) {
        SharedPreferences.Editor editor = getSharedPreference(context).edit();
        editor.clear().apply();
    }

    public static boolean accountConfigured(Context context) {
        return getProfile(context) != null;
    }

    public static void saveProfile(Context context, String profile) {
        getSharedPreference(context).edit().putString(USER, profile).apply();
    }

    public static void saveName(Context context, String name) {
        getSharedPreference(context).edit().putString(NAME, name).apply();
    }

    public static void saveToken(Context context, String token) {
        getSharedPreference(context).edit().putString(TOKEN, token).apply();
    }

    public static void saveRole(Context context, String role) {
        getSharedPreference(context).edit().putString(ROLE, role).apply();
    }

    public static void saveUserId(Context context, int userId) {
        getSharedPreference(context).edit().putInt(USER_ID, userId).apply();
    }

    public static void saveRoleId(Context context, int roleId) {
        getSharedPreference(context).edit().putInt(ROLE_ID, roleId).apply();
    }

    public static void saveEmail(Context context, String email) {
        getSharedPreference(context).edit().putString(EMAIL, email).apply();
    }

    public static void saveSalesId(Context context, String salesId) {
        getSharedPreference(context).edit().putString(SALES_ID, salesId).apply();
    }

    public static void saveDepartementId(Context context, String depId) {
        getSharedPreference(context).edit().putString(DEP_ID, depId).apply();
    }


    public static int getUserId(Context context) {
        return getSharedPreference(context).getInt(USER_ID, 0);
    }

    public static String getRole(Context context) {
        return getSharedPreference(context).getString(ROLE, null);
    }

    public static int getRoleId(Context context) {
        return getSharedPreference(context).getInt(ROLE_ID, 0);
    }

    public static String getToken(Context context) {
        return getSharedPreference(context).getString(TOKEN, null);
    }

    public static String getEmail(Context context) {
        return getSharedPreference(context).getString(EMAIL, null);
    }

    public static String getName(Context context) {
        return getSharedPreference(context).getString(NAME, null);
    }

    public static String getSalesId(Context context) {
        return getSharedPreference(context).getString(SALES_ID, null);
    }

    public static String getDepartementId(Context context) {
        return getSharedPreference(context).getString(DEP_ID, null);
    }

    @NonNull
    public static User getProfile(Context context) {
        String json = getSharedPreference(context).getString(USER, null);
        if (json == null)
            return null;
        return new Gson().fromJson(json, User.class);
    }
}


