package com.mandiri.salestools;

import android.app.Application;
import android.graphics.Bitmap;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;

/**
 * Created by esa on 23/10/14 with awesomeness.
 */
public class SalesToolsApp extends Application {

	private static final String APP_NAMESPACE = "qluein";

	@Override
	public void onCreate() {
		super.onCreate();

		DisplayImageOptions defaultOptions = new DisplayImageOptions.Builder().cacheInMemory(true).cacheOnDisk(true)
				.bitmapConfig(Bitmap.Config.RGB_565).resetViewBeforeLoading(true)
				.showImageOnLoading(R.drawable.ic_placeholder).imageScaleType(ImageScaleType.EXACTLY).build();

		ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(getApplicationContext())
				.defaultDisplayImageOptions(defaultOptions).threadPoolSize(5).memoryCacheSize(12 * 1024 * 1024)
				.denyCacheImageMultipleSizesInMemory().build();

		ImageLoader.getInstance().init(config);

	}
}
