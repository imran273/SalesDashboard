package com.mandiri.salestools.adapter.spinner;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mandiri.salestools.adapter.BaseListAdapter;
import com.mandiri.salestools.apiservice.BUCs;

public class KanwilAdapter extends BaseListAdapter<BUCs.BUC> {

	public KanwilAdapter(Context context) {
		super(context);
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		return getView(false, position, convertView, parent);
	}

	@Override
	public View getDropDownView(int position, View convertView, ViewGroup parent) {
		return getView(true, position, convertView, parent);
	}

	private View getView(boolean isDropDown, int position, View convertView, ViewGroup parent) {

		if (convertView == null)
			convertView = mInflater.inflate(isDropDown ? android.R.layout.simple_spinner_dropdown_item
					  : android.R.layout.simple_spinner_item, parent, false);

		TextView textView = (TextView) convertView;
		textView.setText(mListData.get(position).getRegionalOffice());

		return convertView;
	}
}