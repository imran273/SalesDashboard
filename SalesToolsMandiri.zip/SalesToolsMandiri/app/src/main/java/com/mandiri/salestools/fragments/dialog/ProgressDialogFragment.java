/*
 * Copyright (c) 2015. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.
 * Vestibulum commodo. Ut rhoncus gravida arcu.
 */

package com.mandiri.salestools.fragments.dialog;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;

/**
 * Created by esa on 22/12/14.
 */
public class ProgressDialogFragment extends BaseDialogFragment {

	public static final String TAG = ProgressDialogFragment.class.getSimpleName();

	private static final String ARG_MESSAGE = "ProgressDialogFragment.Message";

	private Context mContext;
	private String mMessage;

	public static ProgressDialogFragment newInstance(String message) {
		Bundle bundle = new Bundle();
		bundle.putString(ARG_MESSAGE, message);
		ProgressDialogFragment progressDialogFragment = new ProgressDialogFragment();
		progressDialogFragment.setArguments(bundle);
		return progressDialogFragment;
	}

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		mContext = activity;
	}

	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {

		mMessage = getArguments().getString(ARG_MESSAGE);

		ProgressDialog progressDialog = new ProgressDialog(mContext);
		progressDialog.setMessage(mMessage);
		return progressDialog;
	}

	public ProgressDialogFragment show(FragmentManager fragmentManager) {
		fragmentManager.beginTransaction().add(this, ProgressDialogFragment.class.getSimpleName())
				.commitAllowingStateLoss();
		return this;
	}
}
