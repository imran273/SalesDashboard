package com.mandiri.salestools.model.clients;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by esa on 09/06/15, with awesomeness
 */
public class Client implements Parcelable {

	/**
	 * createdAt : 2015-05-04T12:00:00.000Z
	 * deletedAt : null
	 * address : Yogyakarta
	 * phone : 02234923749
	 * clientPicId : 2
	 * name : PT Dummy
	 * id : 1
	 * type : company
	 * parentId : null
	 * updatedAt : 2015-05-04T12:00:00.000Z
	 */

	private int id;
	private String createdAt;
	private String deletedAt;
	private String address;
	private String phone;
	private String name;
	private String type;
	private String parentId;
	private String updatedAt;
	private String cif;
	private String clientCategory;
	private String businessUnitCodeId;
	private String regionalOffice;
	private String industrialSectorId;
	private String industryCategories;

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	@Override
	public String toString() {
		return "Client{" +
				  "createdAt='" + createdAt + '\'' +
				  ", deletedAt='" + deletedAt + '\'' +
				  ", address='" + address + '\'' +
				  ", phone='" + phone + '\'' +
				  ", name='" + name + '\'' +
				  ", id=" + id +
				  ", type='" + type + '\'' +
				  ", parentId='" + parentId + '\'' +
				  ", updatedAt='" + updatedAt + '\'' +
				  ", cif='" + cif + '\'' +
				  ", clientCategory='" + clientCategory + '\'' +
				  ", businessUnitCodeId='" + businessUnitCodeId + '\'' +
				  ", regionalOffice='" + regionalOffice + '\'' +
				  ", industrialSectorId='" + industrialSectorId + '\'' +
				  ", industryCategories='" + industryCategories + '\'' +
				  '}';
	}

	public void setDeletedAt(String deletedAt) {
		this.deletedAt = deletedAt;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}


	public void setName(String name) {
		this.name = name;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public String getDeletedAt() {
		return deletedAt;
	}

	public String getAddress() {
		return address;
	}

	public String getPhone() {
		return phone;
	}

	public String getName() {
		return name;
	}

	public int getId() {
		return id;
	}

	public String getType() {
		return type;
	}

	public String getParentId() {
		return parentId;
	}

	public String getUpdatedAt() {
		return updatedAt;
	}

	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}

	public String getClientCategory() {
		return clientCategory;
	}

	public void setClientCategory(String clientCategory) {
		this.clientCategory = clientCategory;
	}

	public String getBusinessUnitCodeId() {
		return businessUnitCodeId;
	}

	public void setBusinessUnitCodeId(String businessUnitCodeId) {
		this.businessUnitCodeId = businessUnitCodeId;
	}

	public String getRegionalOffice() {
		return regionalOffice;
	}

	public void setRegionalOffice(String regionalOffice) {
		this.regionalOffice = regionalOffice;
	}

	public String getIndustrialSectorId() {
		return industrialSectorId;
	}

	public void setIndustrialSectorId(String industrialSectorId) {
		this.industrialSectorId = industrialSectorId;
	}

	public String getIndustryCategories() {
		return industryCategories;
	}

	public void setIndustryCategories(String industryCategories) {
		this.industryCategories = industryCategories;
	}

	public Client() {
	}

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(this.createdAt);
		dest.writeString(this.deletedAt);
		dest.writeString(this.address);
		dest.writeString(this.phone);
		dest.writeString(this.name);
		dest.writeInt(this.id);
		dest.writeString(this.type);
		dest.writeString(this.parentId);
		dest.writeString(this.updatedAt);
		dest.writeString(this.cif);
		dest.writeString(this.clientCategory);
		dest.writeString(this.businessUnitCodeId);
		dest.writeString(this.regionalOffice);
		dest.writeString(this.industrialSectorId);
		dest.writeString(this.industryCategories);
	}

	protected Client(Parcel in) {
		this.createdAt = in.readString();
		this.deletedAt = in.readString();
		this.address = in.readString();
		this.phone = in.readString();
		this.name = in.readString();
		this.id = in.readInt();
		this.type = in.readString();
		this.parentId = in.readString();
		this.updatedAt = in.readString();
		this.cif = in.readString();
		this.clientCategory = in.readString();
		this.businessUnitCodeId = in.readString();
		this.regionalOffice = in.readString();
		this.industrialSectorId = in.readString();
		this.industryCategories = in.readString();
	}

	public static final Creator<Client> CREATOR = new Creator<Client>() {
		public Client createFromParcel(Parcel source) {
			return new Client(source);
		}

		public Client[] newArray(int size) {
			return new Client[size];
		}
	};
}
