package com.mandiri.salestools.model.sales;


import android.os.Parcel;
import android.os.Parcelable;

import com.mandiri.salestools.model.BaseDao;

public class SalesStatistic extends BaseDao implements Parcelable {

    /**
     * onTrack : 0
     * total : 0
     * missed : 0
     * woRealization : 0
     */
    private int onTrack;
    private int total;
    private int missed;
    private int woRealization;

    public void setOnTrack(int onTrack) {
        this.onTrack = onTrack;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public void setMissed(int missed) {
        this.missed = missed;
    }

    public void setWoRealization(int woRealization) {
        this.woRealization = woRealization;
    }

    public int getOnTrack() {
        return onTrack;
    }

    public int getTotal() {
        return total;
    }

    public int getMissed() {
        return missed;
    }

    public int getWoRealization() {
        return woRealization;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeInt(this.onTrack);
        dest.writeInt(this.total);
        dest.writeInt(this.missed);
        dest.writeInt(this.woRealization);
    }

    public SalesStatistic() {
    }

    protected SalesStatistic(Parcel in) {
        this.onTrack = in.readInt();
        this.total = in.readInt();
        this.missed = in.readInt();
        this.woRealization = in.readInt();
    }

    public static final Creator<SalesStatistic> CREATOR = new Creator<SalesStatistic>() {
        public SalesStatistic createFromParcel(Parcel source) {
            return new SalesStatistic(source);
        }

        public SalesStatistic[] newArray(int size) {
            return new SalesStatistic[size];
        }
    };
}