package com.mandiri.salestools.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.mandiri.salestools.R;
import com.mandiri.salestools.activities.add.BaseInputAct;
import com.mandiri.salestools.adapter.BaseListAdapter;
import com.mandiri.salestools.apiservice.ReportApiService;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.report.Report;
import com.mandiri.salestools.utils.CommonUtils;

import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;

/**
 * Created by Deni on 09/06/15
 */
public class ReportListFragment extends BaseFragment {

    @InjectView(R.id.lyRefresh)
    SwipeRefreshLayout mSwipeRefreshLayout;
    @InjectView(R.id.lvContent)
    ListView mLvContent;
    @InjectView(R.id.pbLoad)
    ProgressBar mPbLoad;
    @InjectView(R.id.txtNoData)
    TextView mTxtNoData;
    @InjectView(R.id.btnSubmit)
    FloatingActionButton btnSubmit;

    private ReportApiService mApiService;
    private ReportListAdapter mListAdapter;

    public static ReportListFragment newInstance() {
        return new ReportListFragment();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        getActionBar().setTitle(R.string.call_report);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = mInflater.inflate(R.layout.fragment_common_list, container, false);
        ButterKnife.inject(this, view);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        mListAdapter = new ReportListAdapter(mContext);
        mLvContent.setAdapter(mListAdapter);

        mSwipeRefreshLayout.setColorSchemeResources(R.color.primary);
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                loadData();
            }
        });
        btnSubmit.setVisibility(View.GONE);
        loadData();
    }

    private void loadData() {
        if (mApiService == null)
            mApiService = new ReportApiService(mContext);
        mApiService.loadReports(new EventCallback<List<Report>>() {
            @Override
            public void onEvent(List<Report> data, Bundle bundle) {
                resetLoadingUI();
                if (data == null) {
                    CommonUtils.toastShort(mContext, R.string.error_string);
                    mTxtNoData.setVisibility(View.VISIBLE);
                    return;
                }
                if (data.size() == 0){
                    mTxtNoData.setVisibility(View.VISIBLE);
                    return;
                }
                mTxtNoData.setVisibility(View.GONE);
                mListAdapter.pushData(data);
            }
        });

    }

    private void resetLoadingUI() {
        mSwipeRefreshLayout.setRefreshing(false);
        mPbLoad.setVisibility(View.GONE);
    }


//    @OnClick(R.id.btnSubmit)
//    public void onAddClick(){
//        AddReportAct.startForResult(this);
//    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.reset(this);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK && requestCode == BaseInputAct.BASE_INPUT_CODE) {
            Report report = data.getExtras().getParcelable(Report.class.getSimpleName());
            mListAdapter.getListData().add(report);
            mListAdapter.notifyDataSetChanged();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private class ReportListAdapter extends BaseListAdapter<Report> {

        public ReportListAdapter(Context context) {
            super(context);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            if (convertView == null)
                convertView = mInflater.inflate(R.layout.list_item_report, parent, false);

            Report item = mListData.get(position);

            ReportViewHolder viewHolder = ReportViewHolder.getInstance(convertView);
			viewHolder.mTxtTitle.setText(item.getProduct());
            viewHolder.mTxtSubTitle.setText(item.getDescription());
            viewHolder.mTxtCategory.setText(item.getUpdatedAt());

            return convertView;
        }
    }

    static class ReportViewHolder {

        @InjectView(R.id.txtTitle)
        TextView mTxtTitle;
        @InjectView(R.id.txtSubTitle)
        TextView mTxtSubTitle;
        @InjectView(R.id.txtPhone)
        TextView mTxtCategory;

        public ReportViewHolder(View view) {
            ButterKnife.inject(this, view);
            view.setTag(this);
        }

        static ReportViewHolder getInstance(View view) {
            if (view.getTag() != null)
                return (ReportViewHolder) view.getTag();
            return new ReportViewHolder(view);
        }
    }
}
