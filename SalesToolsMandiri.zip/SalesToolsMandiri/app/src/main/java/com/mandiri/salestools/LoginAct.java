package com.mandiri.salestools;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatEditText;
import android.text.TextUtils;
import android.view.Window;
import android.widget.Toast;

import com.mandiri.salestools.apiservice.AuthApiService;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.users.User;
import com.mandiri.salestools.utils.CommonUtils;
import com.mandiri.salestools.widget.RippleDrawable;

import org.buraktamturk.loadingview.LoadingView;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

/**
 * Created by deni on 01/06/15
 */
public class LoginAct extends Activity {

	@InjectView(R.id.inpUsername) AppCompatEditText mInpUsername;
	@InjectView(R.id.inpPassword) AppCompatEditText mInpPassword;
	@InjectView(R.id.btnSubmit) AppCompatButton mBtnSubmit;
	@InjectView(R.id.loadingView) LoadingView mLoadingView;

	private AuthApiService mUserApiService;
	private Context mContext = this;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_login);
		ButterKnife.inject(this);

		RippleDrawable.createRipple(mBtnSubmit, getResources().getColor(R.color.grey));
	}

	@OnClick(R.id.btnSubmit)
	public void onLoginClick() {
		validateLogin();
	}

	private void validateLogin() {
		String username = mInpUsername.getText().toString();
		String password = mInpPassword.getText().toString();

		CommonUtils.hideKeyboard(getCurrentFocus());

		boolean isValid = true;
		if (TextUtils.isEmpty(username.trim())) {
			mInpUsername.requestFocus();
			mInpUsername.setError("Username must not be empty ");
			isValid = false;
		}
		if (TextUtils.isEmpty(password.trim())) {
			mInpPassword.requestFocus();
			mInpPassword.setError("Password must not be empty ");
			isValid = false;
		}

		if (!isValid)
			return;

		doLogin(username, password);
	}

	private void doLogin(String username, String password) {
		mLoadingView.setLoading(true);

		if (mUserApiService == null)
			mUserApiService = new AuthApiService(this);

        mUserApiService.doLogin(username, password, new EventCallback<User>() {
			@Override
			public void onEvent(User userDao, Bundle bundle) {
				if (userDao != null) {
					Toast.makeText(mContext, "success", Toast.LENGTH_SHORT).show();
					MainSalesAct.start(mContext);
					finish();
				} else {
					mLoadingView.setLoading(false);

                    if (bundle != null){
                        String message = bundle.getString("message");
                        Toast.makeText(mContext, message, Toast.LENGTH_LONG).show();
                    }else{
                        Toast.makeText(mContext, "failed", Toast.LENGTH_SHORT).show();

                        mInpPassword.requestFocus();
                        mInpPassword.setError("Invalid Username or Password");

                        mInpUsername.requestFocus();
                        mInpUsername.setError("Invalid Username or Password");
                    }
				}
			}
		});
	}

	public static void start(Context context) {
		Intent intent = new Intent(context, LoginAct.class);
		context.startActivity(intent);
	}
}
