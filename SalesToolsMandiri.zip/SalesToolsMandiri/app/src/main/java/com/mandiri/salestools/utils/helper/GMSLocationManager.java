package com.mandiri.salestools.utils.helper;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.FragmentManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.mandiri.salestools.R;
import com.mandiri.salestools.gms.GMSHelper;
import com.mandiri.salestools.gms.GMSListener;
import com.mandiri.salestools.utils.LocationUtils;
import com.mandiri.salestools.utils.Logger;

import java.util.Timer;
import java.util.TimerTask;
import java.util.WeakHashMap;

/**
 * Created by esa on 24/10/14 with awesomeness.
 */
public class GMSLocationManager implements LocationListener, GoogleApiClient.OnConnectionFailedListener, GoogleApiClient.ConnectionCallbacks {

	public static final int TIME_GAP_FAST = 1000 * 60 * 5;
	public static final int TIME_GAP_LONG = 1000 * 60 * 10;
	private static final int TIMER_DELAY = 150;

	public static final int TIMEOUT_LONG = 7000;
	public static final int TIMEOUT_FAST = 5000;
	public static final int TIMEOUT_QUICK = 1000;

	public static WeakHashMap<Context, GMSLocationManager> managerHashMap = new WeakHashMap<>();

	private Context mContext;
	private LocationRequest mLocationRequest;
	private LocationManager mLocationManager;
	private GoogleApiClient mGoogleApiClient;
	private GMSListener mGmsListener;

	private Handler mHandler = new Handler(Looper.getMainLooper());
	private Location mLastLocation;

	private Dialog mSettingDialog;
	private Dialog mSuggestionDialog;
	private Dialog mErrorDialog;

	private int mErrorCode = -1;
	private int mTimeOut = TIMEOUT_FAST;
	private int mTimeGap = TIME_GAP_FAST;

	public static GMSLocationManager attach(Context context) {
		GMSLocationManager gmsLocationManager = managerHashMap.get(context);
		if (gmsLocationManager == null) {
			gmsLocationManager = new GMSLocationManager(context);
			managerHashMap.put(context, gmsLocationManager);
		}
		return gmsLocationManager;
	}

	public GMSLocationManager timeOut(int milis) {
		mTimeOut = milis;
		return this;
	}

	public GMSLocationManager timeGap(int milis) {
		mTimeGap = milis;
		return this;
	}

	public GMSLocationManager(Context context) {

		mContext = context;

		mLocationRequest = LocationRequest.create();
		mLocationRequest.setInterval(LocationUtils.UPDATE_INTERVAL_IN_MILLISECONDS);
		mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
		mLocationRequest.setFastestInterval(LocationUtils.FAST_INTERVAL_CEILING_IN_MILLISECONDS);

		mGoogleApiClient = new GoogleApiClient.Builder(context)
				.addConnectionCallbacks(this)
				.addOnConnectionFailedListener(this)
				.addApi(LocationServices.API).build();

		mLocationManager = (LocationManager) mContext.getSystemService(Context.LOCATION_SERVICE);
	}

	public GMSLocationManager listener(GMSListener mGmsListener) {
		this.mGmsListener = mGmsListener;
		return this;
	}

	public boolean isClientConnected() {
		return mGoogleApiClient != null && mGoogleApiClient.isConnected();
	}

	public boolean isProviderEnabled() {
		return mLocationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
				mLocationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
	}

	public GMSLocationManager start() {
		isServiceAvailable();

		if (!isProviderEnabled())
			showSettingDialog();

		if (!mGoogleApiClient.isConnected())
			mGoogleApiClient.connect();
		else
			startPeriodicUpdates();
		return this;
	}

	public void stop() {
		if (mGoogleApiClient.isConnected()) {
			stopPeriodicUpdates();
			mGoogleApiClient.disconnect();
		}
	}

	private void startPeriodicUpdates() {
		Logger.log(Log.INFO, "Start periodic update..");

		if (isServiceAvailable() && mGoogleApiClient.isConnected()) {

			PendingResult<Status> result = LocationServices.FusedLocationApi.requestLocationUpdates
					(mGoogleApiClient, mLocationRequest, this);

			result.setResultCallback(new ResultCallback<Status>() {
				@Override
				public void onResult(Status status) {
					if (status.isSuccess()) {
						Logger.log(Log.INFO, "Status is succes");
					} else if (status.hasResolution()) {
						Logger.log(Log.INFO, "Status has resolution");
					} else {
						Logger.log(Log.ERROR, "Status error");
					}
				}
			});
		}
	}

	private void stopPeriodicUpdates() {
		if (mGoogleApiClient.isConnected())
			LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, this);
	}

	public void onDisconnected() {
		stopPeriodicUpdates();
	}

	public void onLocationChanged(Location location) {
		Logger.log(Log.DEBUG, "OnLocationChanged:" + location);
		mLastLocation = location;
	}


	public Location getLastLocation() {
		if (isClientConnected()) {
			Location lastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
			return isBetterLocation(lastLocation, mLastLocation) ? lastLocation : mLastLocation;
		}
		return mLastLocation;
	}

	protected boolean isBetterLocation(Location location, Location currentBestLocation) {
		if (currentBestLocation == null) {
			// A new location is always better than no location
			return true;
		}
		if (location == null) {
			// A location is always better than no location
			return false;
		}

		// Check whether the new location fix is newer or older
		long timeDelta = location.getTime() - currentBestLocation.getTime();
		boolean isSignificantlyNewer = timeDelta > TIME_GAP_FAST;
		boolean isSignificantlyOlder = timeDelta < -TIME_GAP_FAST;
		boolean isNewer = timeDelta > 0;

		// If it's been more than two minutes since the current location, use the new location
		// because the user has likely moved
		if (isSignificantlyNewer) {
			return true;
			// If the new location is more than two minutes older, it must be worse
		} else if (isSignificantlyOlder) {
			return false;
		}

		// Check whether the new location fix is more or less accurate
		int accuracyDelta = (int) (location.getAccuracy() - currentBestLocation.getAccuracy());
		boolean isLessAccurate = accuracyDelta > 0;
		boolean isMoreAccurate = accuracyDelta < 0;
		boolean isSignificantlyLessAccurate = accuracyDelta > 200;

		// Check if the old and new location are from the same provider
		boolean isFromSameProvider = isSameProvider(location.getProvider(),
				currentBestLocation.getProvider());

		// Determine location quality using a combination of timeliness and accuracy
		if (isMoreAccurate) {
			return true;
		} else if (isNewer && !isLessAccurate) {
			return true;
		} else if (isNewer && !isSignificantlyLessAccurate && isFromSameProvider) {
			return true;
		}
		return false;
	}

	/**
	 * Checks whether two providers are the same
	 */
	private boolean isSameProvider(String provider1, String provider2) {
		if (provider1 == null) {
			return provider2 == null;
		}
		return provider1.equals(provider2);
	}


	public void getCurrentLocation(final LocationResult locationResult) {

		Logger.log(Log.INFO, "Client connection status:" + isClientConnected());
		if (!isClientConnected() && mLastLocation == null) {
			Logger.log(Log.DEBUG, "Connectiing GMS Client...");
			listener(new GMSHelper.SimpleteGMSListener() {
				@Override
				public void onServiceConnected(Bundle bundle) {
					getCurrentLocation(locationResult);
				}
			}).start();
		}

		Location location = getFineLocation();
		if (location != null) {
			Logger.log(Log.INFO, "Got location on the first time");
			locationResult.gotLocation(location);
			return;
		}

		final Timer timer = new Timer();
		final Runnable lastLocationTask = new Runnable() {
			@Override
			public void run() {
				timer.cancel();
				locationResult.gotLocation(getFineLocation());
			}
		};

		Logger.log(Log.INFO, "Scheduling for getting location...");
		timer.scheduleAtFixedRate(new TimerTask() {
			@Override
			public void run() {
				final Location location = getFineLocation();
				Logger.log(Log.DEBUG, "Get location:" + location);

				if (location != null) {
					timer.cancel();
					mHandler.removeCallbacks(lastLocationTask);
				}
				mHandler.post(new Runnable() {
					@Override
					public void run() {
						if (location != null) {
							mHandler.removeCallbacks(this);
							locationResult.gotLocation(location);
						}
					}
				});
			}
		}, TIMER_DELAY, TIMER_DELAY);

		mHandler.postDelayed(lastLocationTask, mTimeOut);
	}

	private Location getFineLocation() {
		Location location = getLastLocation();
		if (isFineLocation(location))
			return location;
		return null;
	}

	private boolean isFineLocation(Location location) {
		return location != null && System.currentTimeMillis() - location.getTime() < mTimeGap;
	}


	/* ============ CONNECTIN RELATED =============*/

	@Override
	public void onConnected(Bundle bundle) {
		if (mGmsListener != null)
			mGmsListener.onServiceConnected(bundle);
		startPeriodicUpdates();
	}

	@Override
	public void onConnectionSuspended(int i) {
		mGoogleApiClient.connect();
	}

	@Override
	public void onConnectionFailed(ConnectionResult connectionResult) {
		if (mGmsListener != null)
			mGmsListener.onConnectionFailed();

		onDisconnected();

		if (connectionResult.hasResolution()) {
			try {
				if (mContext instanceof Activity)
					connectionResult.startResolutionForResult((Activity) mContext,
							LocationUtils.CONNECTION_FAILURE_RESOLUTION_REQUEST);
			} catch (IntentSender.SendIntentException e) {
				Logger.log(e);
			}
		} else {
			showErrorDialog(connectionResult.getErrorCode());
		}
	}

	public boolean isServiceAvailable() {

		int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(mContext);

		if (ConnectionResult.SUCCESS == resultCode) {
			return true;
		} else {
			showErrorDialog(resultCode);
			return false;
		}
	}

	/* ================== HELPER ======================*/


	private void showErrorDialog(int errorCode) {
		if (mContext instanceof Activity) {
			if (mErrorDialog == null || errorCode != mErrorCode)
				mErrorDialog = GooglePlayServicesUtil.getErrorDialog(errorCode, (Activity) mContext,
						LocationUtils.CONNECTION_FAILURE_RESOLUTION_REQUEST);

			if (mErrorDialog != null && !mErrorDialog.isShowing()) {
				FragmentManager fragmentManager = ((Activity) mContext).getFragmentManager();
				ErrorDialogFragment errorFragment = new ErrorDialogFragment();
				errorFragment.setDialog(mErrorDialog);
				fragmentManager.beginTransaction().add(errorFragment,
						ErrorDialogFragment.class.getSimpleName()).commitAllowingStateLoss();
			}
		}
		mErrorCode = errorCode;
	}

	public static class ErrorDialogFragment extends DialogFragment {

		private Dialog mDialog;

		public ErrorDialogFragment() {
			super();
			mDialog = null;
		}

		public void setDialog(Dialog dialog) {
			mDialog = dialog;
		}

		@Override
		public Dialog onCreateDialog(Bundle savedInstanceState) {
			return mDialog;
		}
	}


	public void showSettingDialog() {
		if (mSettingDialog == null) {
			AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
			builder.setMessage(mContext.getString(R.string.location_setting_prompt));
			builder.setPositiveButton("Go To Setting", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					Intent myIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
					mContext.startActivity(myIntent);
				}
			});
			builder.setCancelable(false);
			mSettingDialog = builder.create();
		}
		try {
			if (!mSettingDialog.isShowing())
				mSettingDialog.show();
		} catch (Exception ignored) {
			Logger.log(ignored);
		}
	}

	public void showSuggestionDialog() {
		if (!isProviderEnabled() || (mSettingDialog != null && mSettingDialog.isShowing()))
			return;
		if (mSuggestionDialog == null) {
			AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
			builder.setMessage(mContext.getString(R.string.location_suggestion));
			builder.setPositiveButton("Go To Setting", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					Intent myIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
					mContext.startActivity(myIntent);
				}
			});
			builder.setNegativeButton("OK", null);
			builder.setCancelable(true);
			mSuggestionDialog = builder.create();
		}
		try {
			if (!mSuggestionDialog.isShowing())
				mSuggestionDialog.show();
		} catch (Exception ignored) {
			Logger.log(ignored);
		}
	}

	public void onActivityResult(int requestCode, int resultCode, Intent intent) {
		switch (requestCode) {
			case LocationUtils.CONNECTION_FAILURE_RESOLUTION_REQUEST:
				switch (resultCode) {
					case Activity.RESULT_OK:
						break;
					default:
						break;
				}
			default:
				break;
		}
	}

	public static abstract class LocationResult {
		public abstract void gotLocation(Location location);
	}
}
