package com.mandiri.salestools.activities.schedules;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import com.balysv.materialmenu.MaterialMenuDrawable;
import com.mandiri.salestools.BaseActivity;
import com.mandiri.salestools.R;
import com.mandiri.salestools.adapter.BaseListAdapter;

import butterknife.ButterKnife;
import butterknife.InjectView;

/**
 * Created by esa on 04/06/15, with awesomeness
 */
public class ScheduleListAct extends BaseActivity {

	@InjectView(R.id.toolbar) Toolbar mToolbar;
	@InjectView(R.id.lvContent) ListView mLvContent;

	private TaskAdapter mTaskAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_schedule_list);
		ButterKnife.inject(this);

		setupToolbar(mToolbar);
		getBaseActionBar().setTitle(R.string.appointments);
		materialMenuIcon.setState(MaterialMenuDrawable.IconState.X);

		mTaskAdapter = new TaskAdapter(mContext);
		mLvContent.setAdapter(mTaskAdapter);
		mLvContent.setDivider(null);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.activity_schedule_list, menu);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case android.R.id.home:
				finish();
				break;
			case R.id.menu_done:
				break;
		}
		return super.onOptionsItemSelected(item);
	}

	private class TaskAdapter extends BaseListAdapter<String> {

		public TaskAdapter(Context context) {
			super(context);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {

			if (convertView == null)
				convertView = mInflater.inflate(R.layout.list_item_dialog_calendar_task, parent, false);

			ViewHolder viewHolder = ViewHolder.getViewHolder(convertView);
			viewHolder.mCardView.setCardBackgroundColor(mContext.getResources().getColor(R.color.blue_200));
			viewHolder.mTxtTitle.setText("Task " + position);

			return convertView;
		}

		@Override
		public int getCount() {
			return 5;
		}
	}

	static class ViewHolder {
		@InjectView(R.id.txtTitle) TextView mTxtTitle;
		@InjectView(R.id.cardView) CardView mCardView;

		ViewHolder(View view) {
			ButterKnife.inject(this, view);
			view.setTag(this);
		}

		public static ViewHolder getViewHolder(View view) {
			if (view.getTag() == null)
				return new ViewHolder(view);
			else
				return (ViewHolder) view.getTag();
		}
	}

	/* ------- LAUNCHER --------- */

	public static void start(Context context) {
		context.startActivity(new Intent(context, ScheduleListAct.class));
	}
}
