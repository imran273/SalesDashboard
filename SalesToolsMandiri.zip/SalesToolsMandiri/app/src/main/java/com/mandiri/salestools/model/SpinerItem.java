package com.mandiri.salestools.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by deni on 09/01/2015.
 */
public class SpinerItem implements Parcelable {

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.name);
    }

    public SpinerItem() {
    }

    private SpinerItem(Parcel in) {
        this.name = in.readString();
    }

    public static final Creator<SpinerItem> CREATOR = new Creator<SpinerItem>() {
        public SpinerItem createFromParcel(Parcel source) {
            return new SpinerItem(source);
        }

        public SpinerItem[] newArray(int size) {
            return new SpinerItem[size];
        }
    };
}
