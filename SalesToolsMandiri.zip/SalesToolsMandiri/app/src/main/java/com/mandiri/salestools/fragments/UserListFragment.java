package com.mandiri.salestools.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.mandiri.salestools.R;
import com.mandiri.salestools.activities.add.BaseInputAct;
import com.mandiri.salestools.adapter.BaseListAdapter;
import com.mandiri.salestools.apiservice.UserApiService;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.users.User;
import com.mandiri.salestools.utils.CommonUtils;

import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;

/**
 * Created by deni on 09/06/15
 */
public class UserListFragment extends BaseFragment {

	@InjectView(R.id.lyRefresh) SwipeRefreshLayout mSwipeRefreshLayout;
	@InjectView(R.id.lvContent) ListView mLvContent;
	@InjectView(R.id.pbLoad) ProgressBar mPbLoad;
	@InjectView(R.id.txtNoData) TextView mTxtNoData;

	private UserApiService mApiService;
	private UserListAdapter mListAdapter;

	public static UserListFragment newInstance() {
		return new UserListFragment();
	}

	@Override
	public void onCreate(@Nullable Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);
	}

	@Nullable
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = mInflater.inflate(R.layout.fragment_common_list, container, false);
		ButterKnife.inject(this, view);
		return view;
	}

	@Override
	public void onActivityCreated(@Nullable Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		mListAdapter = new UserListAdapter(mContext);
		mLvContent.setAdapter(mListAdapter);

		mSwipeRefreshLayout.setColorSchemeResources(R.color.primary);
		mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
			@Override
			public void onRefresh() {
				loadData();
			}
		});
		loadData();
	}

	private void loadData() {
		if (mApiService == null)
			mApiService = new UserApiService(mContext);
		mApiService.loadUser(new EventCallback<List<User>>() {
            @Override
            public void onEvent(List<User> data, Bundle bundle) {
                resetLoadingUI();
                if (data == null) {
                    CommonUtils.toastShort(mContext, R.string.error_string);
                    return;
                }
                mListAdapter.pushData(data);
            }
        });

	}

	private void resetLoadingUI() {
		mSwipeRefreshLayout.setRefreshing(false);
		mPbLoad.setVisibility(View.GONE);
	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		inflater.inflate(R.menu.menu_add, menu);
		super.onCreateOptionsMenu(menu, inflater);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case R.id.menu_add:
//				AddProductAct.startForResult(this);
				break;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onDestroyView() {
		super.onDestroyView();
		ButterKnife.reset(this);
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == Activity.RESULT_OK && requestCode == BaseInputAct.BASE_INPUT_CODE) {
			User sales = data.getExtras().getParcelable(User.class.getSimpleName());
			mListAdapter.getListData().add(sales);
			mListAdapter.notifyDataSetChanged();
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	private class UserListAdapter extends BaseListAdapter<User> {

		public UserListAdapter(Context context) {
			super(context);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {

			if (convertView == null)
				convertView = mInflater.inflate(R.layout.list_item_sales, parent, false);

			UserViewHolder viewHolder = UserViewHolder.getInstance(convertView);
			viewHolder.mTxtTitle.setText(mListData.get(position).getName());

			return convertView;
		}
	}

	static class UserViewHolder {

		@InjectView(R.id.txtTitle) TextView mTxtTitle;

		public UserViewHolder(View view) {
			ButterKnife.inject(this, view);
			view.setTag(this);
		}

		static UserViewHolder getInstance(View view) {
			if (view.getTag() != null)
				return (UserViewHolder) view.getTag();
			return new UserViewHolder(view);
		}
	}
}
