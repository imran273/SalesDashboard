package com.mandiri.salestools.apiservice;

import android.content.Context;
import android.util.Log;

import com.loopj.android.http.TextHttpResponseHandler;
import com.mandiri.salestools.constants.URLCons;
import com.mandiri.salestools.http.MandiriClient;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.sales.Sales;
import com.mandiri.salestools.model.sales.SalesDao;
import com.mandiri.salestools.model.sales.SalesStatistic;
import com.mandiri.salestools.utils.Logger;
import com.mandiri.salestools.utils.Preferences;

import org.apache.http.Header;

import java.util.List;

public class SalesApiService extends BaseApiService {

	public SalesApiService(Context mContext) {
		super(mContext);
	}

    public void loadSales(final EventCallback<List<Sales>> eventCallback) {
        loadSales(URLCons.SALES, eventCallback);
    }

	private void loadSales(final String url,
                          final EventCallback<List<Sales>> eventCallback) {
		MandiriClient.get(mContext, url, new TextHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, String response) {
                Logger.log(Log.DEBUG, "Response :" + response);
                try {
                    SalesDao baseApiDao = getGson().fromJson(response, SalesDao.class);
                    if (baseApiDao.getError().getMessage() == null) {
                        List<Sales> sales = baseApiDao.getSales();

                        eventCallback.onEvent(sales);
                    } else {
                        eventCallback.onEvent(null);
                    }
                } catch (Exception e) {
                    onFailure(statusCode, headers, response, e);
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                Logger.log(throwable);
                eventCallback.onEvent(null);
            }
        });
	}

	public void loadSalesStatistic(final EventCallback<SalesStatistic> eventCallback) {

        String URL = URLCons.SALES;

//        URL = URL +"/"+ Preferences.getUserId(mContext) + "/statistics";
        URL = URL +"/" + Preferences.getUserId(mContext)+"/statistics";

		MandiriClient.get(mContext, URL, new TextHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, String response) {
                Logger.log(Log.DEBUG, "Response :" + response);
                try {
                    SalesDao salesDao = getGson().fromJson(response, SalesDao.class);
                    SalesStatistic salesStatistic = salesDao.getStatistics();
                    eventCallback.onEvent(salesStatistic);
                } catch (Exception e) {
                    onFailure(statusCode, headers, response, e);
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                Logger.log(throwable);
                eventCallback.onEvent(null);
            }
        });
	}

	public void doAddSales(final Sales sales,
                           final EventCallback<Sales> eventCallback) {

//        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        String date = df.format(Calendar.getInstance().getTime());
//        sales.setStartDate(date);
        String json = getGson().toJson(sales);

		MandiriClient.postJSON(mContext, URLCons.SALES, json, new TextHttpResponseHandler() {
			@Override
			public void onSuccess(int statusCode, Header[] headers, String response) {
				Logger.log(Log.DEBUG, "Response :" + response);
				try {
					SalesDao baseApiDao = getGson().fromJson(response, SalesDao.class);
					if (baseApiDao.getError().getMessage() == null) {
                        Sales report = baseApiDao.getSales().get(0);
						eventCallback.onEvent(report);
					} else {
						eventCallback.onEvent(null);
					}
				} catch (Exception e) {
					onFailure(statusCode, headers, response, e);
				}
			}

			@Override
			public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
				Logger.log(throwable);
				eventCallback.onEvent(null);
			}
		});
	}
}
