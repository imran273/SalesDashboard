package com.mandiri.salestools.apiservice;

import android.content.Context;
import android.util.Log;

import com.loopj.android.http.TextHttpResponseHandler;
import com.mandiri.salestools.constants.URLCons;
import com.mandiri.salestools.http.MandiriClient;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.departement.Departement;
import com.mandiri.salestools.model.departement.DepartementDao;
import com.mandiri.salestools.model.sales.Sales;
import com.mandiri.salestools.utils.Logger;

import org.apache.http.Header;

import java.util.List;

public class DepartementApiService extends BaseApiService {

	public DepartementApiService(Context mContext) {
		super(mContext);
	}

//    public void loadSalesFull(final EventCallback<List<Sales>> eventCallback) {
//        loadDepartement(URLCons.SALES_FULL, eventCallback);
//    }

    public void loadDepartement(final EventCallback<List<Departement>> eventCallback) {
        loadDepartement(URLCons.DEPARTEMENTS, eventCallback);
    }

	private void loadDepartement(final String url,
                                 final EventCallback<List<Departement>> eventCallback) {

		MandiriClient.get(mContext, url, new TextHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, String response) {
                Logger.log(Log.DEBUG, "Response :" + response);
                try {
                    DepartementDao baseApiDao = getGson().fromJson(response, DepartementDao.class);
                    if (baseApiDao.getError().getMessage() == null) {
                        List<Departement> report = baseApiDao.getDepartements();

                        eventCallback.onEvent(report);
                    } else {
                        eventCallback.onEvent(null);
                    }
                } catch (Exception e) {
                    onFailure(statusCode, headers, response, e);
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                Logger.log(throwable);
                eventCallback.onEvent(null);
            }
        });
	}

	public void doAddDepartement(final Sales sales,
                           final EventCallback<Departement> eventCallback) {

//        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        String date = df.format(Calendar.getInstance().getTime());
//        sales.setStartDate(date);
        String json = getGson().toJson(sales);

		MandiriClient.postJSON(mContext, URLCons.DEPARTEMENTS, json, new TextHttpResponseHandler() {
			@Override
			public void onSuccess(int statusCode, Header[] headers, String response) {
				Logger.log(Log.DEBUG, "Response :" + response);
				try {
                    DepartementDao baseApiDao = getGson().fromJson(response, DepartementDao.class);
                    if (baseApiDao.getError().getMessage() == null) {
                        Departement departement = baseApiDao.getDepartements().get(0);

                        eventCallback.onEvent(departement);
                    } else {
                        eventCallback.onEvent(null);
                    }
				} catch (Exception e) {
					onFailure(statusCode, headers, response, e);
				}
			}

			@Override
			public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
				Logger.log(throwable);
				eventCallback.onEvent(null);
			}
		});
	}
}
