package com.mandiri.salestools.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.mandiri.salestools.R;
import com.mandiri.salestools.activities.add.AddCustomerAct;
import com.mandiri.salestools.activities.add.BaseInputAct;
import com.mandiri.salestools.adapter.BaseListAdapter;
import com.mandiri.salestools.apiservice.ClientApiService;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.clients.Client;
import com.mandiri.salestools.utils.CommonUtils;

import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

/**
 * Created by esa on 09/06/15, with awesomeness
 */
public class ClientListFragment extends BaseFragment {

	@InjectView(R.id.lyRefresh) SwipeRefreshLayout mSwipeRefreshLayout;
	@InjectView(R.id.lvContent) ListView mLvContent;
	@InjectView(R.id.pbLoad) ProgressBar mPbLoad;
	@InjectView(R.id.txtNoData) TextView mTxtNoData;

	private ClientApiService mApiService;
	private ClientListAdapter mListAdapter;

	public static ClientListFragment newInstance() {
		return new ClientListFragment();
	}

	@Override
	public void onCreate(@Nullable Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);
		getActionBar().setTitle(R.string.clients);
	}

	@Nullable
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = mInflater.inflate(R.layout.fragment_common_list, container, false);
		ButterKnife.inject(this, view);
		return view;
	}

	@Override
	public void onActivityCreated(@Nullable Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		mListAdapter = new ClientListAdapter(mContext);
		mLvContent.setAdapter(mListAdapter);

		mSwipeRefreshLayout.setColorSchemeResources(R.color.primary);
		mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
			@Override
			public void onRefresh() {
				loadData();
			}
		});
		loadData();
	}

	private void loadData() {
		if (mApiService == null)
			mApiService = new ClientApiService(mContext);
		mApiService.loadClientsWeb(new EventCallback<List<Client>>() {
			@Override
			public void onEvent(List<Client> clients, Bundle bundle) {
				resetLoadingUI();
				if (clients == null) {
					CommonUtils.toastShort(mContext, R.string.error_string);
                    mTxtNoData.setVisibility(View.VISIBLE);
					return;
				}
                if (clients.size() == 0){
                    mTxtNoData.setVisibility(View.VISIBLE);
                    return;
                }
                mTxtNoData.setVisibility(View.GONE);
				mListAdapter.pushData(clients);
			}
		});
	}

	private void resetLoadingUI() {
		mPbLoad.setVisibility(View.GONE);
	}

	@OnClick(R.id.btnSubmit)
	public void onAddClick() {
		AddCustomerAct.startForResult(this);
	}

	@Override
	public void onDestroyView() {
		super.onDestroyView();
		ButterKnife.reset(this);
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == Activity.RESULT_OK && requestCode == BaseInputAct.BASE_INPUT_CODE) {
			Client client = data.getExtras().getParcelable(Client.class.getSimpleName());
			mListAdapter.getListData().add(client);
			mListAdapter.notifyDataSetChanged();
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	private class ClientListAdapter extends BaseListAdapter<Client> {

		public ClientListAdapter(Context context) {
			super(context);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {

			if (convertView == null)
				convertView = mInflater.inflate(R.layout.list_item_client, parent, false);

            Client item = mListData.get(position);

			ClientViewHolder viewHolder = ClientViewHolder.getInstance(convertView);

			viewHolder.mTxtTitle.setText(item.getName());
			viewHolder.mTxtSubTitle.setText(item.getAddress());
			viewHolder.mTxtPhone.setText(item.getPhone());

			return convertView;
		}
	}

	static class ClientViewHolder {

		@InjectView(R.id.txtTitle) TextView mTxtTitle;
		@InjectView(R.id.txtSubTitle) TextView mTxtSubTitle;
		@InjectView(R.id.txtPhone) TextView mTxtPhone;

		public ClientViewHolder(View view) {
			ButterKnife.inject(this, view);
			view.setTag(this);
		}

		static ClientViewHolder getInstance(View view) {
			if (view.getTag() != null)
				return (ClientViewHolder) view.getTag();
			return new ClientViewHolder(view);
		}
	}
}
