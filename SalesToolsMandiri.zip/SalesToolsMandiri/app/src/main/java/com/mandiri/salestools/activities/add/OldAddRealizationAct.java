/*
 * Copyright (c) 2015. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.
 * Vestibulum commodo. Ut rhoncus gravida arcu.
 */

package com.mandiri.salestools.activities.add;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.balysv.materialmenu.MaterialMenuDrawable;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.Places;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.mandiri.salestools.R;
import com.mandiri.salestools.adapter.BaseListAdapter;
import com.mandiri.salestools.apiservice.RealizationApiService;
import com.mandiri.salestools.apiservice.SchedulesApiService;
import com.mandiri.salestools.fragments.BaseFragment;
import com.mandiri.salestools.fragments.dialog.BaseDialogFragment;
import com.mandiri.salestools.fragments.dialog.ProgressDialogFragment;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.realization.Realization;
import com.mandiri.salestools.model.schedule.Schedule;
import com.mandiri.salestools.utils.CommonUtils;
import com.mandiri.salestools.utils.Logger;
import com.mandiri.salestools.widget.RippleDrawable;

import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

@Deprecated
public class OldAddRealizationAct extends BaseInputAct implements GoogleApiClient.OnConnectionFailedListener {

	@InjectView(R.id.inpTeamMandiri) EditText inpTeamMandiri;
	@InjectView(R.id.inpTeamClient) EditText inpTeamClient;
	@InjectView(R.id.inpDescription) EditText inpDescription;
	@InjectView(R.id.btnPickPlace) Button btnPickPlace;
	@InjectView(R.id.lySchedule) LinearLayout lySchedule;
	@InjectView(R.id.spinnerSchedule) Spinner spinnerSchedule;
	@InjectView(R.id.cbxFlagUpdate)    CheckBox cbxFlagUpdate;
	@InjectView(R.id.toolbar) Toolbar mToolbar;
//	@InjectView(R.id.btnSubmit)
//	Button btnSubmit;
//    @InjectView(R.id.autocomplete_places)
//    AutoCompleteTextView mAutocompleteView;

	private RealizationApiService mRealizationApiService;
	private GoogleApiClient mGoogleApiClient;
	static final int REQUEST_PLACE_PICKER = 29;
//    private PlaceAutocompleteAdapter mAdapter;

//    private Place mPlaces;

	private Realization mRealization;
	private Schedule mSchedule;

	private List<Schedule> mListDataSchedule;
	private ScheduleAdapter mScheduleAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add_realization);
		ButterKnife.inject(this);

		setupToolbar(mToolbar);
		materialMenuIcon.setState(MaterialMenuDrawable.IconState.ARROW);

		mGoogleApiClient = new GoogleApiClient
				.Builder(this)
				.addApi(Places.GEO_DATA_API)
				.addApi(Places.PLACE_DETECTION_API)
				.addOnConnectionFailedListener(this)
				.build();

		mSchedule = getIntent().getParcelableExtra(ARG_SCHEDULE);

		setupUI();
	}

	private void setupUI() {

//        mAutocompleteView.setOnItemClickListener(mAutocompleteClickListener);
//        mAdapter = new PlaceAutocompleteAdapter(this, android.R.layout.simple_list_item_1,
//                mGoogleApiClient, BOUNDS_JAKARTA, null);
//        mAutocompleteView.setAdapter(mAdapter);
		RippleDrawable.createRipple(btnPickPlace, getResources().getColor(R.color.ripple));
		RippleDrawable.createRipple(cbxFlagUpdate, getResources().getColor(R.color.ripple));
//		RippleDrawable.createRipple(btnSubmit, getResources().getColor(R.color.ripple));

		if (mSchedule == null) {
			lySchedule.setVisibility(View.VISIBLE);

			spinnerSchedule.setAdapter(mScheduleAdapter = new ScheduleAdapter(mContext));

			SchedulesApiService schedulesApiService = new SchedulesApiService(mContext);
			schedulesApiService.loadSchedules(new EventCallback<List<Schedule>>() {
				@Override
				public void onEvent(List<Schedule> schedules, Bundle bundle) {
					mListDataSchedule = schedules;
					mScheduleAdapter.pushData(schedules);
				}
			});
		} else {
			lySchedule.setVisibility(View.GONE);
		}
	}

	@OnClick(R.id.btnPickPlace)
	public void onPickPlaceClick() {
		displayPlacePicker();
	}

//	@OnClick(R.id.btnSubmit)
//	public void onSubmitClick() {
//		validatePost();
//	}

	private void displayPlacePicker() {
		try {
			PlacePicker.IntentBuilder intentBuilder = new PlacePicker.IntentBuilder();
			Intent intent = intentBuilder.build(this);
			startActivityForResult(intent, REQUEST_PLACE_PICKER);
		} catch (GooglePlayServicesRepairableException e) {
			Logger.log(e);
		} catch (GooglePlayServicesNotAvailableException e) {
			Logger.log(e);
		}
	}

	@Override
	protected void onActivityResult(int requestCode,
	                                int resultCode, Intent data) {
		if (requestCode == REQUEST_PLACE_PICKER
				&& resultCode == RESULT_OK) {

			// The user has selected a place. Extract the name and address.
			final Place place = PlacePicker.getPlace(data, this);

			final CharSequence name = place.getName();
			final CharSequence address = place.getAddress();
			String attributions = PlacePicker.getAttributions(data);
			if (attributions == null) {
				attributions = "";
			}

			if (mRealization == null)
				mRealization = new Realization();

			mRealization.setLat(place.getLatLng().latitude);
			mRealization.setLng(place.getLatLng().longitude);
			mRealization.setLocation(place.getName() + ", " + place.getAddress());

			btnPickPlace.setText(place.getName() + ", " + place.getAddress());

//            mViewName.setText(name);
//            mViewAddress.setText(address);
//            mViewAttributions.setText(Html.fromHtml(attributions));

//            mInpPlace.setText(name + ", " + address + ", attributions : " + Html.fromHtml(attributions));
		} else {
			super.onActivityResult(requestCode, resultCode, data);
		}
	}

	private class ScheduleAdapter extends BaseListAdapter<Schedule> {

		public ScheduleAdapter(Context context) {
			super(context);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			return getView(false, position, convertView, parent);
		}

		@Override
		public View getDropDownView(int position, View convertView, ViewGroup parent) {
			return getView(true, position, convertView, parent);
		}

		private View getView(boolean isDropDown, int position, View convertView, ViewGroup parent) {

			if (convertView == null)
				convertView = mInflater.inflate(isDropDown ? android.R.layout.simple_spinner_dropdown_item
						: android.R.layout.simple_spinner_item, parent, false);

			TextView textView = (TextView) convertView;
			textView.setText(mListData.get(position).getPlan());

			return convertView;
		}
	}

	@Override
	protected void onStart() {
		super.onStart();
		mGoogleApiClient.connect();
	}

	@Override
	protected void onStop() {
		mGoogleApiClient.disconnect();
		super.onStop();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.menu_submit, menu);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case R.id.menu_add:
				validatePost();
				break;
		}
		return super.onOptionsItemSelected(item);
	}

	public void validatePost() {

		CommonUtils.hideKeyboard(getCurrentFocus());

		String teamMandiri = inpTeamMandiri.getText().toString().trim();
		String teamClient = inpTeamClient.getText().toString().trim();
		String description = inpDescription.getText().toString().trim();

		boolean isValid = true;
		if (TextUtils.isEmpty(teamMandiri.trim())) {
			this.inpTeamMandiri.requestFocus();
			this.inpTeamMandiri.setError("Team Mandiri must not be empty ");
			isValid = false;
		}
		if (TextUtils.isEmpty(teamClient)) {
			inpTeamClient.requestFocus();
			inpTeamClient.setError("Team Client must not be empty");
			isValid = false;
		}
		if (TextUtils.isEmpty(description)) {
			inpDescription.requestFocus();
			inpDescription.setError("Realisasi must not be empty");
			isValid = false;
		}
		if (mRealization == null) {
			Toast.makeText(mContext, "Pick Place before", Toast.LENGTH_SHORT).show();
			displayPlacePicker();
			isValid = false;
		}

		if (!isValid)
			return;

		if (mSchedule != null) {
			mRealization.setScheduleId(mSchedule.getId());
		} else {
			mRealization.setScheduleId(mListDataSchedule.get(spinnerSchedule.getSelectedItemPosition()).getId());
		}

		mRealization.setDescription(description);
		mRealization.setTeamMandiri(teamMandiri);
		mRealization.setTeamClient(teamClient);
        mRealization.setFlagUpdateCycle(cbxFlagUpdate.isChecked());
		doAddRealization();
	}

	private void doAddRealization() {
		if (mRealizationApiService == null)
			mRealizationApiService = new RealizationApiService(mContext);

		final ProgressDialogFragment progressDialogFragment = ProgressDialogFragment.newInstance("Please wait..");
		progressDialogFragment.show(getSupportFragmentManager(), ProgressDialogFragment.TAG);

		mRealizationApiService.doAddRealization(mRealization, new EventCallback<Realization>() {
			@Override
			public void onEvent(Realization realization, Bundle bundle) {
				if (realization != null) {
					progressDialogFragment.dismiss();
					Toast.makeText(mContext, "success", Toast.LENGTH_SHORT).show();
					finish();
				} else {
					progressDialogFragment.dismiss();
					Toast.makeText(mContext, "failed", Toast.LENGTH_SHORT).show();
				}
			}
		});
	}

	@Override
	public void onConnectionFailed(ConnectionResult connectionResult) {
		Logger.log(Log.ERROR, "onConnectionFailed: ConnectionResult.getErrorCode() = "
				+ connectionResult.getErrorCode());

		// TODO(Developer): Check error code and notify the user of error state and resolution.
		Toast.makeText(this,
				"Could not connect to Google API Client: Error " + connectionResult.getErrorCode(),
				Toast.LENGTH_SHORT).show();
	}

	/* ---------- LAUNCHER ------------ */
	public static void startForResult(BaseFragment baseFragment) {
		baseFragment.startActivityForResult(new Intent(baseFragment.getActivity(), OldAddRealizationAct
				.class), BaseInputAct.BASE_INPUT_CODE);
	}

	public static void startForResult(Activity activity, Schedule schedule) {
		activity.startActivityForResult(new Intent(activity, OldAddRealizationAct
				.class).putExtra(ARG_SCHEDULE, schedule), BaseInputAct.BASE_INPUT_CODE);
	}

	public static void startForResult(BaseDialogFragment baseDialogFragment, Schedule schedule) {
		Intent intent = new Intent(baseDialogFragment.getActivity(), OldAddRealizationAct.class);
		intent.putExtra(ARG_SCHEDULE, schedule);
		baseDialogFragment.startActivityForResult(intent, BaseInputAct.BASE_INPUT_CODE);
	}

}
