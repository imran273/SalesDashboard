package com.mandiri.salestools.gms;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.mandiri.salestools.R;
import com.mandiri.salestools.utils.Logger;

import java.util.WeakHashMap;

/**
 * Created by esa on 24/11/14. with awesomeness
 */
public class GMSHelper implements GoogleApiClient.OnConnectionFailedListener, GoogleApiClient.ConnectionCallbacks {

	private static final int RC_SIGN_IN = 91001;

	public static WeakHashMap<Context, GMSHelper> managerHashMap = new WeakHashMap<>();

	private Activity mActivity;
	private GoogleApiClient mGoogleApiClient;
	private GMSListener mGmsListener;

	private boolean mResolvingConnectionFailure;

    public static GMSHelper getInstance(Activity activity) {
		GMSHelper gmsHelper = managerHashMap.get(activity);
		if (gmsHelper == null) {
			gmsHelper = new GMSHelper(activity);
			managerHashMap.put(activity, gmsHelper);
		}
		return gmsHelper;
	}

	public GMSHelper(Activity activity) {
		mActivity = activity;
//		mGoogleApiClient = new GoogleApiClient.Builder(activity)
//				.addConnectionCallbacks(this)
//				.addOnConnectionFailedListener(this)
//				.addApi(Plus.API).addScope(Plus.SCOPE_PLUS_LOGIN)
//				.addApi(Games.API).addScope(Games.SCOPE_GAMES).build();
	}

	public GMSHelper listener(GMSListener mGmsListener) {
		this.mGmsListener = mGmsListener;
		return this;
	}


	/* ============== ACTIVITY RELATED =============*/

	public void onStart() {
		mGoogleApiClient.connect();
	}

	public void onStop() {
		if (mGoogleApiClient.isConnected())
			mGoogleApiClient.disconnect();
		managerHashMap.remove(mActivity);
	}

	/* ============== PUBLIC METHOD ============ */

	public GoogleApiClient getClient() {
		return mGoogleApiClient;
	}

	public Activity getActivity() {
		return mActivity;
	}

//	public void signOut() {
//		List<GMSHelper> gmsHelpers = new ArrayList<>(managerHashMap.values());
//		for (GMSHelper gmsHelper : gmsHelpers) {
//			if (gmsHelper.getClient().isConnected()) {
//				Plus.AccountApi.clearDefaultAccount(gmsHelper.getClient());
//				gmsHelper.getClient().disconnect();
//				managerHashMap.remove(gmsHelper.getActivity());
//			}
//		}
//	}

	public void signIn() {
		mGoogleApiClient.connect();
	}

	public void signInIfNeeded() {
		if (mGoogleApiClient.isConnected())
			onConnected(null);
		else
			mGoogleApiClient.connect();
	}

//	public void unlockAchievement(String achievementID) {
//		if (mGoogleApiClient.isConnected())
//			Games.Achievements.unlock(mGoogleApiClient, achievementID);
//	}
//
//	public void showAchievementAct() {
//		if (mGoogleApiClient.isConnected())
//			mActivity.startActivityForResult(Games.Achievements.getAchievementsIntent(mGoogleApiClient), 1);
//	}
//
//	public void checkIfUnlocked(final String achievementID, final AchievementChecker.CheckerListener checkerListener) {
//		if (mGoogleApiClient.isConnected())
//			Games.Achievements.load(mGoogleApiClient, false).setResultCallback(new AchievementChecker
//					(achievementID, checkerListener));
//	}
//
//	public void loadPeopleList(String pageToken, ResultCallback<People.LoadPeopleResult> resultResultCallback) {
//		Plus.PeopleApi.loadVisible(mGoogleApiClient, pageToken).setResultCallback(resultResultCallback);
//	}

	/* ============ CONNECTIN RELATED =============*/

	@Override
	public void onConnected(Bundle bundle) {
		if (mGmsListener != null)
			mGmsListener.onServiceConnected(bundle);
	}

	@Override
	public void onConnectionSuspended(int i) {
		mGoogleApiClient.connect();
	}

	@Override
	public void onConnectionFailed(ConnectionResult connectionResult) {
		if (mGmsListener != null)
			mGmsListener.onConnectionFailed();

		if (mResolvingConnectionFailure) {
			Logger.log(Log.WARN, "Already resolving connection");
//			return;
		}
//		mResolvingConnectionFailure = BaseGameUtils.resolveConnectionFailure(mActivity, mGoogleApiClient,
//				connectionResult, RC_SIGN_IN, mActivity.getString(R.string.error_signin_other));
        else{
            Toast.makeText(mActivity, mActivity.getResources().getString(R.string.connection_error),
                    Toast.LENGTH_LONG).show();
        }
	}

	public boolean onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == RC_SIGN_IN) {
			mResolvingConnectionFailure = false;
			if (resultCode == Activity.RESULT_OK) {
				mGoogleApiClient.connect();
			} else {
//				BaseGameUtils.showActivityResultError(mActivity, requestCode, resultCode,
//						R.string.error_signin_failure, R.string.error_signin_other);
                Toast.makeText(mActivity, mActivity.getResources().getString(R.string.connection_error),
                        Toast.LENGTH_LONG).show();
			}
			return true;
		}
		return false;
	}


	public static class SimpleteGMSListener implements GMSListener {
		@Override
		public void onServiceConnected(Bundle bundle) {
		}

		@Override
		public void onConnectionFailed() {
		}
	}
}
