package com.mandiri.salestools.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by deni on 09/01/2015.
 */
public class ReportPersonnel implements Parcelable {

    private String id;
    private String no_ktp;
    private String nama;
    private String jenis_kelamin;
    private String alamat;
    private String kota;
    private String provinsi;
    private String tanggal_lahir;
    private String usia;
    private String pekerjaan;
    private String status;
    private String lat;
    private String lng;
    private String distance;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNo_ktp() {
        return no_ktp;
    }

    public void setNo_ktp(String no_ktp) {
        this.no_ktp = no_ktp;
    }

    public String getJenis_kelamin() {
        return jenis_kelamin;
    }

    public void setJenis_kelamin(String jenis_kelamin) {
        this.jenis_kelamin = jenis_kelamin;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getKota() {
        return kota;
    }

    public void setKota(String kota) {
        this.kota = kota;
    }

    public String getProvinsi() {
        return provinsi;
    }

    public void setProvinsi(String provinsi) {
        this.provinsi = provinsi;
    }

    public String getTanggal_lahir() {
        return tanggal_lahir;
    }

    public void setTanggal_lahir(String tanggal_lahir) {
        this.tanggal_lahir = tanggal_lahir;
    }

    public String getUsia() {
        return usia;
    }

    public void setUsia(String usia) {
        this.usia = usia;
    }

    public String getPekerjaan() {
        return pekerjaan;
    }

    public void setPekerjaan(String pekerjaan) {
        this.pekerjaan = pekerjaan;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }


    public ReportPersonnel() {
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.id);
        dest.writeString(this.no_ktp);
        dest.writeString(this.nama);
        dest.writeString(this.jenis_kelamin);
        dest.writeString(this.alamat);
        dest.writeString(this.kota);
        dest.writeString(this.provinsi);
        dest.writeString(this.tanggal_lahir);
        dest.writeString(this.usia);
        dest.writeString(this.pekerjaan);
        dest.writeString(this.status);
        dest.writeString(this.lat);
        dest.writeString(this.lng);
        dest.writeString(this.distance);
    }

    private ReportPersonnel(Parcel in) {
        this.id = in.readString();
        this.no_ktp = in.readString();
        this.nama = in.readString();
        this.jenis_kelamin = in.readString();
        this.alamat = in.readString();
        this.kota = in.readString();
        this.provinsi = in.readString();
        this.tanggal_lahir = in.readString();
        this.usia = in.readString();
        this.pekerjaan = in.readString();
        this.status = in.readString();
        this.lat = in.readString();
        this.lng = in.readString();
        this.distance = in.readString();
    }

    public static final Creator<ReportPersonnel> CREATOR = new Creator<ReportPersonnel>() {
        public ReportPersonnel createFromParcel(Parcel source) {
            return new ReportPersonnel(source);
        }

        public ReportPersonnel[] newArray(int size) {
            return new ReportPersonnel[size];
        }
    };
}
