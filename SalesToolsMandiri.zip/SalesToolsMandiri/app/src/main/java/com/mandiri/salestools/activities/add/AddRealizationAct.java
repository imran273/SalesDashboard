package com.mandiri.salestools.activities.add;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.balysv.materialmenu.MaterialMenuDrawable;
import com.mandiri.salestools.R;
import com.mandiri.salestools.adapter.BaseListAdapter;
import com.mandiri.salestools.apiservice.RealizationApiService;
import com.mandiri.salestools.apiservice.SchedulesApiService;
import com.mandiri.salestools.fragments.BaseFragment;
import com.mandiri.salestools.fragments.dialog.BaseDialogFragment;
import com.mandiri.salestools.fragments.dialog.ProgressDialogFragment;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.realization.Realization;
import com.mandiri.salestools.model.schedule.Schedule;
import com.mandiri.salestools.utils.CommonUtils;
import com.mandiri.salestools.utils.helper.GMSLocationManager;
import com.mandiri.salestools.widget.RippleDrawable;

import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class AddRealizationAct extends BaseInputAct {

	@InjectView(R.id.inpTeamMandiri) EditText inpTeamMandiri;
	@InjectView(R.id.inpTeamClient) EditText inpTeamClient;
	@InjectView(R.id.inpDescription) EditText inpDescription;
	@InjectView(R.id.inpPlace) EditText inpPlace;
	@InjectView(R.id.lySchedule) LinearLayout lySchedule;
	@InjectView(R.id.spinnerSchedule) Spinner spinnerSchedule;
	@InjectView(R.id.cbxFlagUpdate)    CheckBox cbxFlagUpdate;
	@InjectView(R.id.toolbar) Toolbar mToolbar;

	private RealizationApiService mRealizationApiService;

    private Location myLocation;
    private GMSLocationManager gmsLocationManager;

	private Schedule mSchedule;

	private List<Schedule> mListDataSchedule;
	private ScheduleAdapter mScheduleAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add_realization);
		ButterKnife.inject(this);

		setupToolbar(mToolbar);
		materialMenuIcon.setState(MaterialMenuDrawable.IconState.ARROW);

        mSchedule = getIntent().getParcelableExtra(ARG_SCHEDULE);

        gmsLocationManager = GMSLocationManager.attach(mContext).timeOut(GMSLocationManager.TIMEOUT_QUICK).start();
        gmsLocationManager.getCurrentLocation(new GMSLocationManager.LocationResult() {
            @Override
            public void gotLocation(Location location) {
                if (location != null && myLocation == null) {
                    myLocation = location;
                }
            }
        });

		setupUI();
	}

	private void setupUI() {

		RippleDrawable.createRipple(cbxFlagUpdate, getResources().getColor(R.color.ripple));

		if (mSchedule == null) {
			lySchedule.setVisibility(View.VISIBLE);

			spinnerSchedule.setAdapter(mScheduleAdapter = new ScheduleAdapter(mContext));

			SchedulesApiService schedulesApiService = new SchedulesApiService(mContext);
			schedulesApiService.loadTodaySchedules(new EventCallback<List<Schedule>>() {
				@Override
				public void onEvent(List<Schedule> schedules, Bundle bundle) {
					mListDataSchedule = schedules;
					mScheduleAdapter.pushData(schedules);
				}
			});
		} else {
			lySchedule.setVisibility(View.GONE);
		}
	}

	private class ScheduleAdapter extends BaseListAdapter<Schedule> {

		public ScheduleAdapter(Context context) {
			super(context);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			return getView(false, position, convertView, parent);
		}

		@Override
		public View getDropDownView(int position, View convertView, ViewGroup parent) {
			return getView(true, position, convertView, parent);
		}

		private View getView(boolean isDropDown, int position, View convertView, ViewGroup parent) {

			if (convertView == null)
				convertView = mInflater.inflate(isDropDown ? android.R.layout.simple_spinner_dropdown_item
						: android.R.layout.simple_spinner_item, parent, false);

			TextView textView = (TextView) convertView;
			textView.setText(mListData.get(position).getPlan());

			return convertView;
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.menu_submit, menu);
		return super.onCreateOptionsMenu(menu);
    }

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case R.id.menu_add:
				validatePost();
				break;
		}
		return super.onOptionsItemSelected(item);
	}

	public void validatePost() {
        Realization mRealization = new Realization();

		CommonUtils.hideKeyboard(getCurrentFocus());

		String teamMandiri = inpTeamMandiri.getText().toString().trim();
		String teamClient = inpTeamClient.getText().toString().trim();
		String description = inpDescription.getText().toString().trim();
		String place = inpPlace.getText().toString().trim();

		boolean isValid = true;
		if (TextUtils.isEmpty(teamMandiri.trim())) {
			this.inpTeamMandiri.requestFocus();
			this.inpTeamMandiri.setError("Team Mandiri must not be empty ");
			isValid = false;
		}
		if (TextUtils.isEmpty(teamClient)) {
			inpTeamClient.requestFocus();
			inpTeamClient.setError("Team Client must not be empty");
			isValid = false;
		}
		if (TextUtils.isEmpty(description)) {
			inpDescription.requestFocus();
			inpDescription.setError("Realisasi must not be empty");
			isValid = false;
		}
        if (TextUtils.isEmpty(place)) {
            inpPlace.requestFocus();
            inpPlace.setError("Place mus not be empty");
			isValid = false;
		}
        if(myLocation == null)
            isValid = false;

		if (!isValid)
			return;

		if (mSchedule != null) {
			mRealization.setScheduleId(mSchedule.getId());
		} else {
			mRealization.setScheduleId(mListDataSchedule.get(spinnerSchedule.getSelectedItemPosition()).getId());
		}

        mRealization.setLat(myLocation.getLatitude());
        mRealization.setLng(myLocation.getLongitude());
        mRealization.setLocation(place);
		mRealization.setDescription(description);
		mRealization.setTeamMandiri(teamMandiri);
		mRealization.setTeamClient(teamClient);
        mRealization.setFlagUpdateCycle(cbxFlagUpdate.isChecked());
		doAddRealization(mRealization);
	}

	private void doAddRealization(Realization mRealization) {
		if (mRealizationApiService == null)
			mRealizationApiService = new RealizationApiService(mContext);

		final ProgressDialogFragment progressDialogFragment = ProgressDialogFragment.newInstance("Please wait..");
		progressDialogFragment.show(getSupportFragmentManager(), ProgressDialogFragment.TAG);

        mRealizationApiService.doAddRealization(mRealization, new EventCallback<Realization>() {
            @Override
            public void onEvent(Realization realization, Bundle bundle) {
                if (realization != null) {
                    progressDialogFragment.dismiss();
                    Toast.makeText(mContext, "success", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    progressDialogFragment.dismiss();
                    Toast.makeText(mContext, "failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onStart() {
        gmsLocationManager.start();
        super.onStart();
    }

    @Override
    protected void onStop() {
        gmsLocationManager.stop();
        super.onStop();
    }

    /* ---------- LAUNCHER ------------ */
	public static void startForResult(BaseFragment baseFragment) {
		baseFragment.startActivityForResult(new Intent(baseFragment.getActivity(), AddRealizationAct
				.class), BaseInputAct.BASE_INPUT_CODE);
	}

	public static void startForResult(Activity activity, Schedule schedule) {
		activity.startActivityForResult(new Intent(activity, AddRealizationAct
				.class).putExtra(ARG_SCHEDULE, schedule), BaseInputAct.BASE_INPUT_CODE);
	}

	public static void startForResult(BaseDialogFragment baseDialogFragment, Schedule schedule) {
		Intent intent = new Intent(baseDialogFragment.getActivity(), AddRealizationAct.class);
		intent.putExtra(ARG_SCHEDULE, schedule);
		baseDialogFragment.startActivityForResult(intent, BaseInputAct.BASE_INPUT_CODE);
	}

}
