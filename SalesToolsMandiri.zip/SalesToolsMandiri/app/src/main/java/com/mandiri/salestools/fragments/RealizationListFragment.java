/*
 * Copyright (c) 2015. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.
 * Vestibulum commodo. Ut rhoncus gravida arcu.
 */

package com.mandiri.salestools.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.mandiri.salestools.R;
import com.mandiri.salestools.activities.add.AddRealizationAct;
import com.mandiri.salestools.activities.add.BaseInputAct;
import com.mandiri.salestools.adapter.BaseListAdapter;
import com.mandiri.salestools.apiservice.RealizationApiService;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.realization.Realization;
import com.mandiri.salestools.utils.CommonUtils;

import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

/**
 * Created by Deni on 09/06/15
 */
public class RealizationListFragment extends BaseFragment {

	@InjectView(R.id.lyRefresh) SwipeRefreshLayout mSwipeRefreshLayout;
	@InjectView(R.id.lvContent) ListView mLvContent;
	@InjectView(R.id.pbLoad) ProgressBar mPbLoad;
	@InjectView(R.id.txtNoData) TextView mTxtNoData;

	private RealizationApiService mApiService;
	private RealizationListAdapter mListAdapter;

	public static RealizationListFragment newInstance() {
		return new RealizationListFragment();
	}

	@Override
	public void onCreate(@Nullable Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);
        getActionBar().setTitle(R.string.realizations);
	}

	@Nullable
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = mInflater.inflate(R.layout.fragment_common_list, container, false);
		ButterKnife.inject(this, view);
		return view;
	}

	@Override
	public void onActivityCreated(@Nullable Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		mListAdapter = new RealizationListAdapter(mContext);
		mLvContent.setAdapter(mListAdapter);

		mSwipeRefreshLayout.setColorSchemeResources(R.color.primary);
		mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
			@Override
			public void onRefresh() {
				loadData();
			}
		});
		loadData();
	}

	private void loadData() {
		if (mApiService == null)
			mApiService = new RealizationApiService(mContext);
		mApiService.loadRealizations(new EventCallback<List<Realization>>() {
            @Override
            public void onEvent(List<Realization> data, Bundle bundle) {
                resetLoadingUI();
                if (data == null) {
                    CommonUtils.toastShort(mContext, R.string.error_string);
                    mTxtNoData.setVisibility(View.VISIBLE);
                    return;
                }
                if (data.size() == 0){
                    mTxtNoData.setVisibility(View.VISIBLE);
                    return;
                }
                mTxtNoData.setVisibility(View.GONE);
                mListAdapter.pushData(data);
            }
        });

	}

	private void resetLoadingUI() {
		mSwipeRefreshLayout.setRefreshing(false);
		mPbLoad.setVisibility(View.GONE);
	}

    @OnClick(R.id.btnSubmit)
    public void onAddClick(){
        AddRealizationAct.startForResult(this);
    }

	@Override
	public void onDestroyView() {
		super.onDestroyView();
		ButterKnife.reset(this);
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == Activity.RESULT_OK && requestCode == BaseInputAct.BASE_INPUT_CODE) {
            Realization realization = data.getExtras().getParcelable(Realization.class.getSimpleName());
			mListAdapter.getListData().add(realization);
			mListAdapter.notifyDataSetChanged();
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	private class RealizationListAdapter extends BaseListAdapter<Realization> {

		public RealizationListAdapter(Context context) {
			super(context);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {

			if (convertView == null)
				convertView = mInflater.inflate(R.layout.list_item_realization, parent, false);

            Realization item = mListData.get(position);

			RealizationViewHolder viewHolder = RealizationViewHolder.getInstance(convertView);
			viewHolder.mTxtTitle.setText(item.getDescription());
			viewHolder.mTxtSubTitle.setText(item.getLocation());
			viewHolder.mTxtCategory.setText(item.getDate());

			return convertView;
		}
	}

	static class RealizationViewHolder {

		@InjectView(R.id.txtTitle) TextView mTxtTitle;
        @InjectView(R.id.txtSubTitle) TextView mTxtSubTitle;
        @InjectView(R.id.txtPhone) TextView mTxtCategory;

		public RealizationViewHolder(View view) {
			ButterKnife.inject(this, view);
			view.setTag(this);
		}

		static RealizationViewHolder getInstance(View view) {
			if (view.getTag() != null)
				return (RealizationViewHolder) view.getTag();
			return new RealizationViewHolder(view);
		}
	}
}
