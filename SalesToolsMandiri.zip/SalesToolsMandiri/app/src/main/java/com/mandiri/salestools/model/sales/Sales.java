
package com.mandiri.salestools.model.sales;


import android.os.Parcel;
import android.os.Parcelable;

public class Sales implements Parcelable {

    /**
     * createdAt : 2015-06-08T19:07:19.000Z
     * deletedAt : null
     * level : partner
     * phone : 02130303030
     * name : test1
     * id : 1
     * departementId : 1
     * divisionId : 1
     * userId : 4
     * updatedAt : 2015-06-09T06:23:20.000Z
     */
    private String createdAt;
    private String deletedAt;
    private String level;
    private String phone;
    private String name;
    private int id;
    private int departementId;
    private int divisionId;
    private int userId;
    private String updatedAt;

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public void setDeletedAt(String deletedAt) {
        this.deletedAt = deletedAt;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setDepartementId(int departementId) {
        this.departementId = departementId;
    }

    public void setDivisionId(int divisionId) {
        this.divisionId = divisionId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public String getDeletedAt() {
        return deletedAt;
    }

    public String getLevel() {
        return level;
    }

    public String getPhone() {
        return phone;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public int getDepartementId() {
        return departementId;
    }

    public int getDivisionId() {
        return divisionId;
    }

    public int getUserId() {
        return userId;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.createdAt);
        dest.writeString(this.deletedAt);
        dest.writeString(this.level);
        dest.writeString(this.phone);
        dest.writeString(this.name);
        dest.writeInt(this.id);
        dest.writeInt(this.departementId);
        dest.writeInt(this.divisionId);
        dest.writeInt(this.userId);
        dest.writeString(this.updatedAt);
    }

    public Sales() {
    }

    protected Sales(Parcel in) {
        this.createdAt = in.readString();
        this.deletedAt = in.readString();
        this.level = in.readString();
        this.phone = in.readString();
        this.name = in.readString();
        this.id = in.readInt();
        this.departementId = in.readInt();
        this.divisionId = in.readInt();
        this.userId = in.readInt();
        this.updatedAt = in.readString();
    }

    public static final Creator<Sales> CREATOR = new Creator<Sales>() {
        public Sales createFromParcel(Parcel source) {
            return new Sales(source);
        }

        public Sales[] newArray(int size) {
            return new Sales[size];
        }
    };
}