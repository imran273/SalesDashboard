package com.mandiri.salestools.fragments;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.ProgressBar;

import com.mandiri.salestools.R;
import com.mandiri.salestools.adapter.BaseListAdapter;
import com.mandiri.salestools.fragments.chart.DataCustomerChartFragment;
import com.mandiri.salestools.model.users.User;
import com.melnykov.fab.FloatingActionButton;
import com.nostra13.universalimageloader.core.ImageLoader;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

public class HomeListFragment extends BaseFragment {

	@InjectView(R.id.lvContent) ListView mLvContent;
	@InjectView(R.id.pbLoad) ProgressBar mPbLoad;
	@InjectView(R.id.lyRefresh) SwipeRefreshLayout mSwipeRefreshLayout;
    @InjectView(R.id.fabAdd) FloatingActionButton mFabAdd;

	private DailyTaskListApdater mListApdater;

	public static HomeListFragment newInstance() {
		HomeListFragment fragment = new HomeListFragment();
		Bundle args = new Bundle();
		fragment.setArguments(args);
		return fragment;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		setHasOptionsMenu(true);
		super.onCreate(savedInstanceState);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_card_list, container, false);
		ButterKnife.inject(this, rootView);
		setupUI();
		return rootView;
	}

	private void setupUI() {
		mSwipeRefreshLayout.setColorSchemeResources(R.color.primary, R.color.accentColor);
		mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                loadData();
            }
        });

        mListApdater = new DailyTaskListApdater(mContext);
        mLvContent.setAdapter(mListApdater);
        mLvContent.setDividerHeight(getResources().getDimensionPixelSize(R.dimen.view_padding_small));
        mLvContent.setDivider(new ColorDrawable(Color.TRANSPARENT));
        mFabAdd.setVisibility(View.VISIBLE);
        mFabAdd.attachToListView(mLvContent);

        mPbLoad.setVisibility(View.VISIBLE);

        mSwipeRefreshLayout.setRefreshing(true);
        loadData();
	}

    @OnClick(R.id.fabAdd)
    public void onFabClick(){
//        ((MainActivity) getActivity()).onNavigationDrawerItemSelected(3);
    }

    private void loadData() {
		mPbLoad.setVisibility(View.GONE);
//        if (mReportPersonnelApiService == null)
//            mReportPersonnelApiService = new ViewReportApiService(mContext);
//
////        mSwipeRefreshLayout.setRefreshing(true);
//        mReportPersonnelApiService.getReport(new EventCallback<List<ViewReport>>() {
//            @Override
//            public void onEvent(List<ViewReport> listData) {
//                mSwipeRefreshLayout.setRefreshing(false);
//                mPbLoad.setVisibility(View.GONE);
//                if (listData != null) {
//                    viewReportList = listData;
//                    mListApdater.notifyDataSetChanged();
//                } else {
//                    Toast.makeText(mContext, getString(R.string.connection_error), Toast.LENGTH_LONG).show();
//                }
//            }
//        });
    }

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onDestroyView() {
		super.onDestroyView();
		ButterKnife.reset(this);
	}

	private class DailyTaskListApdater extends BaseListAdapter<User> {
        private ImageLoader mImageLoader = ImageLoader.getInstance();

		public DailyTaskListApdater(Context context) {
			super(context);
		}

		@Override
		public int getCount() {
			return 10;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			CardViewHolder viewHolder;
			if (convertView == null) {
				convertView = mInflater.inflate(R.layout.list_item_chart_fragment, parent, false);
				viewHolder = new CardViewHolder(convertView);
			} else
				viewHolder = (CardViewHolder) convertView.getTag();

//            ViewReport item = viewReportList.get(position);
//            viewHolder.txtTitle.setText(item.getNoTPS());
//            viewHolder.txtContent.setText(item.getContent());
//            viewHolder.txtTimeStamp.setText(item.getTimestamp());
//            viewHolder.txtUsername.setText(item.getPersonil());
//            viewHolder.txtUsername.setText(item.getPersonil() + "," + item.getKecamatan() + "," + item.getKota() + "," + item.getProvinsi());
//            Bitmap mBitmap;
//            try{
//                mBitmap = BitmapUtils.base64StringToBitmap(item.getImage());
//                viewHolder.imgContent.setImageBitmap(mBitmap);
//            }catch (Exception e){
//                Logger.log(e);
//            }
//            mImageLoader.displayImage(URLCons.URL_IMAGE+item.getImage(), viewHolder.imgContent);

			BaseFragment fragment = new DataCustomerChartFragment();
			FragmentManager fragmentManager = getFragmentManager();
			fragmentManager.beginTransaction()
					.replace(R.id.container, fragment)
					.commit();

			return convertView;
		}
	}

	static class CardViewHolder {

//		@InjectView(R.id.txtTitle) AppCompatTextView txtTitle;
//		@InjectView(R.id.txtUsername) AppCompatTextView txtUsername;
//		@InjectView(R.id.txtTimeStamp) AppCompatTextView txtTimeStamp;
//		@InjectView(R.id.txtContent) AppCompatTextView txtContent;
//		@InjectView(R.id.container) Fragment fragment;
//
		CardViewHolder(View view) {
			ButterKnife.inject(this, view);
			view.setTag(this);
		}
	}
}