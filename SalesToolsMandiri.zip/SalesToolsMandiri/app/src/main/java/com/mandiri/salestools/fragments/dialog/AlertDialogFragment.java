package com.mandiri.salestools.fragments.dialog;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;

public class AlertDialogFragment extends BaseDialogFragment {

	public static final String TAG = AlertDialogFragment.class.getSimpleName();

	private AlertDialog mAlertDialog;

	public static AlertDialogFragment newInstance(){
		return new AlertDialogFragment();
	}

	public AlertDialogFragment() {
		super();
		mAlertDialog = null;
	}

	public void setDialog(AlertDialog alertDialog) {
		this.mAlertDialog = alertDialog;
	}

	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {
		return mAlertDialog;
	}
}