package com.mandiri.salestools.fragments.dialog;


import android.app.Activity;
import android.content.Context;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;

/**
 * Created by esa on 14/01/15, with awesomeness
 */
public class BaseDialogFragment extends DialogFragment {

	protected Context mContext;
	protected LayoutInflater mInflater;

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		mContext = activity;
		mInflater = LayoutInflater.from(mContext);
	}
}
