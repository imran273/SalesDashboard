package com.mandiri.salestools.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.mandiri.salestools.R;
import com.mandiri.salestools.fragments.chart.BarChartItem;
import com.mandiri.salestools.fragments.chart.ChartItem;
import com.mandiri.salestools.fragments.chart.LineChartItem;
import com.mandiri.salestools.fragments.chart.PieChartItem;

import java.util.ArrayList;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class ChartListFragment extends ChartBaseFragment {

    @InjectView(R.id.lvContent)    ListView mLvContent;

    public static ChartListFragment newInstance() {
        return new ChartListFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        setHasOptionsMenu(true);
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_card_list, container, false);
        ButterKnife.inject(this, rootView);
        setupUI();
        return rootView;
    }

    private void setupUI() {
        ArrayList<ChartItem> list = new ArrayList<>();

        // 30 items
        for (int i = 0; i < 30; i++) {

            if(i % 3 == 0) {
                list.add(new LineChartItem(generateDataLine(i + 1), mContext));
            } else if(i % 3 == 1) {
                list.add(new BarChartItem(generateDataBar(i + 1), mContext));
            } else if(i % 3 == 2) {
                list.add(new PieChartItem(generateDataPie(i + 1), mContext));
            }
        }

        ChartDataAdapter cda = new ChartDataAdapter(mContext, list);
        mLvContent.setAdapter(cda);
    }
}