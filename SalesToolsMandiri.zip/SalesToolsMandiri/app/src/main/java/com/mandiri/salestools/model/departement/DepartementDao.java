package com.mandiri.salestools.model.departement;

import android.os.Parcel;

import com.mandiri.salestools.model.BaseDao;

import java.util.List;

/**
 * Created by deni on 04/06/15
 */
public class DepartementDao extends BaseDao {

	private List<Departement> departements;

    public List<Departement> getDepartements() {
        return departements;
    }

    public void setDepartements(List<Departement> departements) {
        this.departements = departements;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeTypedList(departements);
    }

    public DepartementDao() {
    }

    protected DepartementDao(Parcel in) {
        this.departements = in.createTypedArrayList(Departement.CREATOR);
    }

    public static final Creator<DepartementDao> CREATOR = new Creator<DepartementDao>() {
        public DepartementDao createFromParcel(Parcel source) {
            return new DepartementDao(source);
        }

        public DepartementDao[] newArray(int size) {
            return new DepartementDao[size];
        }
    };
}
