package com.mandiri.salestools.model.report;

import android.os.Parcel;

import com.mandiri.salestools.model.BaseDao;

import java.util.List;

/**
 * Created by deni on 04/06/15
 */
public class ReportDao extends BaseDao {

	private List<Report> reports;

    public List<Report> getReports() {
        return reports;
    }

    public void setReports(List<Report> reports) {
        this.reports = reports;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeTypedList(reports);
    }

    public ReportDao() {
    }

    protected ReportDao(Parcel in) {
        this.reports = in.createTypedArrayList(Report.CREATOR);
    }

    public static final Creator<ReportDao> CREATOR = new Creator<ReportDao>() {
        public ReportDao createFromParcel(Parcel source) {
            return new ReportDao(source);
        }

        public ReportDao[] newArray(int size) {
            return new ReportDao[size];
        }
    };
}
