package com.mandiri.salestools.fragments.dialog;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;

import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.mandiri.salestools.R;
import com.mandiri.salestools.adapter.spinner.ClientAdapter;
import com.mandiri.salestools.adapter.spinner.PipelineAdapter;
import com.mandiri.salestools.apiservice.ClientApiService;
import com.mandiri.salestools.apiservice.PipelineApiService;
import com.mandiri.salestools.apiservice.SchedulesApiService;
import com.mandiri.salestools.fragments.BaseFragment;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.clients.Client;
import com.mandiri.salestools.model.pipeline.Pipeline;
import com.mandiri.salestools.model.schedule.Schedule;
import com.mandiri.salestools.utils.CommonUtils;
import com.mandiri.salestools.utils.Logger;
import com.mandiri.salestools.utils.MandiriDateUtils;
import com.mandiri.salestools.utils.StringValueUtils;
import com.mandiri.salestools.utils.helper.BundleHelper;
import com.mandiri.salestools.widget.RippleDrawable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;
import butterknife.OnItemSelected;

/**
 * Created by esa on 03/06/15, with awesomeness
 */
public class AddScheduleDialog extends BaseDialogFragment {

	public static final int ADD_SCHEDULE_REQUEST_CODE = 0x114;
	private static final int LOCATION_REQUEST_CODE = 0x10;

	@InjectView(R.id.inpTitle) EditText mInpTitle;
	@InjectView(R.id.inpStartTime) EditText mInpStartTime;
	@InjectView(R.id.inpEndTime) EditText mInpEndTime;
	@InjectView(R.id.inpContent) EditText mInpContent;
	@InjectView(R.id.btnDone) Button mBtnDone;
	@InjectView(R.id.spinner) Spinner mPipelineSpinner;
	@InjectView(R.id.inpTeam) EditText mInpTeam;
	@InjectView(R.id.inpTeamClient) EditText mInpTeamClient;
	@InjectView(R.id.inpPic) EditText mInpPic;
	@InjectView(R.id.scrollView) ScrollView mScrollView;
	@InjectView(R.id.pbLoad) ProgressBar mProgressBar;
	@InjectView(R.id.btnSubmit) Button mPlacePickerButton;
	@InjectView(R.id.spnClientName) Spinner mSpnClient;

	private PipelineApiService mPipelineApiService;
	private PipelineAdapter mPipelineAdater;
	private ClientAdapter mClientAdapter;

	@NonNull
	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {
		Dialog dialog = new Dialog(mContext);
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setContentView(getContentView());
		dialog.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager
				  .LayoutParams.WRAP_CONTENT);
		return dialog;
	}

	@SuppressLint("InflateParams")
	private View getContentView() {
		View view = mInflater.inflate(R.layout.dialog_add_schedule, null);
		ButterKnife.inject(this, view);
		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		RippleDrawable.createRipple(mBtnDone, Color.WHITE);

		mPipelineAdater = new PipelineAdapter(mContext);
		mPipelineSpinner.setAdapter(mPipelineAdater);

		mClientAdapter = new ClientAdapter(mContext);
		mSpnClient.setAdapter(mClientAdapter);

		mPipelineApiService = new PipelineApiService(mContext);

		ClientApiService clientApiService = new ClientApiService(mContext);
		clientApiService.loadClients(new EventCallback<List<Client>>() {
			@Override
			public void onEvent(List<Client> clients, Bundle bundle) {
				List<Client> clientNames = new ArrayList<>();
				for (Client client : clients) {
					if (client.getParentId() != null)
						clientNames.add(client);
				}
				mClientAdapter.pushData(clientNames);
			}
		});
	}

	private void resetUILoading() {
		if (isAdded()) {
			mProgressBar.setVisibility(View.GONE);
			mScrollView.setVisibility(View.VISIBLE);
			mBtnDone.setVisibility(View.VISIBLE);
		}
	}

	@OnItemSelected(R.id.spnClientName)
	public void onStatusSelected(int position) {
		Client client = mClientAdapter.getItem(position);
		mPipelineApiService.loadPipelineForClient(String.valueOf(client.getId()), new EventCallback<List<Pipeline>>() {
			@Override
			public void onEvent(List<Pipeline> pipelines, Bundle bundle) {
				resetUILoading();

				if (pipelines == null) {
					CommonUtils.toastShort(mContext, R.string.error_string);
					return;
				}
				if (pipelines.isEmpty()) {
					CommonUtils.toastShort(mContext, "No pipelines found!");

					Pipeline pipeline = new Pipeline();
					pipeline.setName("Not found");
					pipelines.add(pipeline);

					mPipelineAdater.pushData(pipelines);
					mPipelineSpinner.setEnabled(false);
				} else {
					mPipelineAdater.pushData(pipelines);
					mPipelineSpinner.setEnabled(true);
				}
			}
		});
	}

	@OnClick(R.id.btnDone)
	public void onAddSchedule() {
		Date date = (Date) getArguments().getSerializable(Date.class.getSimpleName());
		final Schedule schedule = new Schedule();
		schedule.setPlan(mInpTitle.getText().toString());
		schedule.setTeamMandiri(mInpTeamClient.getText().toString());
		schedule.setTeamClient(mInpTeam.getText().toString());
		schedule.setPic(mInpPic.getText().toString());
		schedule.setDescription(mInpContent.getText().toString());
		schedule.setLocation(mPlacePickerButton.getText().toString());
		schedule.setOfferingId(mPipelineAdater.getItem(mPipelineSpinner.getSelectedItemPosition()).getId());
		schedule.setColor("4CAF50");

		schedule.setStartDate(MandiriDateUtils.getStringSimpleFormattedDate(date) + " " +
				  StringValueUtils.getValue(mInpStartTime) + ":00");
		schedule.setEndDate(MandiriDateUtils.getStringSimpleFormattedDate(date) + " " +
				  StringValueUtils.getValue(mInpEndTime) + ":00");

		if (MandiriDateUtils.beforeNow(schedule.getStartDate())) {
			CommonUtils.toastShort(mContext, "Start Date must after now and well-formed");
			return;
		}

		if (MandiriDateUtils.beforeNow(schedule.getEndDate())) {
			CommonUtils.toastShort(mContext, "End date must after Start Date and Now");
			return;
		}

		SchedulesApiService schedulesApiService = new SchedulesApiService(mContext);
		schedulesApiService.addSchedule(schedule, new EventCallback<Schedule>() {
			@Override
			public void onEvent(Schedule schedule1, Bundle bundle) {
				if (schedule1 == null) {
					CommonUtils.toastShort(mContext, R.string.error_string);
					return;
				}

				BaseFragment baseFragment = (BaseFragment) getTargetFragment();
				if (baseFragment != null) {

					schedule.setStartDate(schedule1.getStartDate());
					schedule.setEndDate(schedule1.getEndDate());

					bundle = new Bundle();
					bundle.putParcelable(Schedule.class.getSimpleName(), schedule);
					bundle.putSerializable(Date.class.getSimpleName(), schedule1.getStartDate());
					baseFragment.onActivityResult(ADD_SCHEDULE_REQUEST_CODE, Activity.RESULT_OK,
							  BundleHelper.createIntentWithBundle(bundle));
				}
				dismissAllowingStateLoss();
			}
		});
	}

	@OnClick(R.id.btnSubmit)
	public void onPickPlaceClick() {
		try {
			PlacePicker.IntentBuilder intentBuilder = new PlacePicker.IntentBuilder();
			Intent intent = intentBuilder.build(mContext);
			startActivityForResult(intent, LOCATION_REQUEST_CODE);
		} catch (GooglePlayServicesRepairableException | GooglePlayServicesNotAvailableException e) {
			CommonUtils.toastShort(mContext, "Cannot pick location, this shouldn't happening");
			Logger.log(e);
		}
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == LOCATION_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
			final Place place = PlacePicker.getPlace(data, mContext);
			mPlacePickerButton.setText(place.getName());
		} else
			super.onActivityResult(requestCode, resultCode, data);
	}

	@Override
	public void onDestroyView() {
		super.onDestroyView();
		ButterKnife.reset(this);
	}


	/* ------- LAUNCHER ----------- */

	public static void show(FragmentManager fragmentManager, Date date) {
		show(null, fragmentManager, date);
	}

	public static void show(BaseFragment baseFragment, FragmentManager fragmentManager, Date date) {
		Bundle bundle = new Bundle();
		bundle.putSerializable(Date.class.getSimpleName(), date);
		AddScheduleDialog addScheduleDialog = new AddScheduleDialog();
		addScheduleDialog.setArguments(bundle);

		if (baseFragment != null) {
			addScheduleDialog.setTargetFragment(baseFragment, ADD_SCHEDULE_REQUEST_CODE);
		}

		FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
		fragmentTransaction.add(addScheduleDialog, AddScheduleDialog.class.getSimpleName());
		fragmentTransaction.commitAllowingStateLoss();
	}
}

