package com.mandiri.salestools.utils;

/**
 * Created by esa on 18/08/15, with awesomeness
 */
public class SegmentationUtils {

	public static String getSegmentation(int index){
		switch (index) {
			case 0:
				return "corporate";
			case 1:
				return "financial";
			default:
				return "commercial";
		}
	}

	public static String getSegmentationID(int index){
		switch (index) {
			case 0:
				return "2";
			case 1:
				return "3";
			default:
				return "4";
		}
	}
}
