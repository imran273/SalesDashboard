package com.mandiri.salestools;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.balysv.materialmenu.MaterialMenuDrawable;
import com.balysv.materialmenu.extras.toolbar.MaterialMenuIconToolbar;

public class BaseActivity extends AppCompatActivity {

	protected MaterialMenuIconToolbar materialMenuIcon;
	protected Context mContext = this;

	private Toolbar mToolbar;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	public void setTitle(int title) {
		super.setTitle(title);
		ActionBar actionBar = getSupportActionBar();
		if (actionBar != null)
			actionBar.setTitle(getString(title));
	}

	protected void setupToolbar(final Toolbar toolbar) {
		setupToolbar(toolbar, null);
	}

	@TargetApi(Build.VERSION_CODES.LOLLIPOP)
	protected void setupToolbar(final Toolbar toolbar, final View.OnClickListener onClickListener) {

		mToolbar = toolbar;

		setSupportActionBar(toolbar);

		ActionBar actionBar = getSupportActionBar();
		if (actionBar != null)
			actionBar.setHomeButtonEnabled(true);

		if (onClickListener != null)
			toolbar.setNavigationOnClickListener(onClickListener);

		materialMenuIcon = new MaterialMenuIconToolbar(this, Color.WHITE, MaterialMenuDrawable.Stroke.THIN) {
			@Override
			public int getToolbarViewId() {
				return toolbar.getId();
			}
		};
	}

	public Toolbar getToolbar() {
		return mToolbar;
	}

	public ActionBar getBaseActionBar() {
		ActionBar actionBar = getSupportActionBar();
		assert actionBar != null;
		return actionBar;
	}

	protected void onPostCreate(Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		if (materialMenuIcon != null)
			materialMenuIcon.syncState(savedInstanceState);
	}

	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		if (materialMenuIcon != null)
			materialMenuIcon.onSaveInstanceState(outState);
	}

}
