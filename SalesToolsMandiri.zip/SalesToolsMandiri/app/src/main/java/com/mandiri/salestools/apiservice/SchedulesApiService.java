package com.mandiri.salestools.apiservice;

import android.content.Context;

import com.loopj.android.http.TextHttpResponseHandler;
import com.mandiri.salestools.constants.URLCons;
import com.mandiri.salestools.http.MandiriClient;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.schedule.Schedule;
import com.mandiri.salestools.model.schedule.SchedulesResponse;
import com.mandiri.salestools.utils.Preferences;

import org.apache.http.Header;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

/**
 * Created by esa on 04/06/15, with awesomeness
 */
public class SchedulesApiService extends BaseApiService {

	public SchedulesApiService(Context mContext) {
		super(mContext);
	}

	public void loadSchedulesFull(String id, final EventCallback<List<Schedule>> eventCallback) {
		String url = String.format(URLCons.SCHEDULES_FULL, id);
		loadSchedules(url, eventCallback);
	}

	public void loadSchedules(final EventCallback<List<Schedule>> eventCallback) {
		loadSchedules(URLCons.SCHEDULES, eventCallback);
	}

	public void loadTodaySchedules(final EventCallback<List<Schedule>> eventCallback) {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = df.format(Calendar.getInstance().getTime());

		loadSchedules(URLCons.SCHEDULES + "?q[starDate]=" + date, eventCallback);
	}

	private void loadSchedules(String url, final EventCallback<List<Schedule>> eventCallback) {

		MandiriClient.get(mContext, url, new TextHttpResponseHandler() {
			@Override
			public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
				onHandleError(eventCallback, throwable);
			}

			@Override
			public void onSuccess(int statusCode, Header[] headers, String responseString) {
				onHandleSuccess(responseString);

				try {
					SchedulesResponse schedulesResponse = getGson().fromJson(responseString,
							  SchedulesResponse.class);

					if (schedulesResponse.getError().isNotError()) {
						eventCallback.onEvent(schedulesResponse.getSchedules());
					} else
						onFailure(statusCode, null, responseString, new Exception(schedulesResponse
								  .getError().getMessage()));

				} catch (Exception e) {
					onFailure(statusCode, null, responseString, e);
				}
			}
		});
	}

	public void addSchedule(Schedule schedule, final EventCallback<Schedule> eventCallback) {
		schedule.setSalesId(Preferences.getSalesId(mContext));
		String json = getGson().toJson(schedule);

		MandiriClient.postJSON(mContext, URLCons.SCHEDULES, json, new TextHttpResponseHandler() {
			@Override
			public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
				onHandleError(eventCallback, throwable);
			}

			@Override
			public void onSuccess(int statusCode, Header[] headers, String responseString) {
				onHandleSuccess(responseString);

				SchedulesResponse response = getGson().fromJson(responseString, SchedulesResponse.class);
				if (response.getError().isNotError()) {
					eventCallback.onEvent(response.getSchedules().get(0));
				} else
					onFailure(statusCode, null, responseString, new Exception(response.getError().getMessage()));
			}
		});
	}
}
