package com.mandiri.salestools.adapter;

import android.content.Context;
import android.support.v4.app.FragmentManager;

import com.mandiri.salestools.R;
import com.mandiri.salestools.fragments.BaseFragment;
import com.mandiri.salestools.fragments.profile.OverviewFragment;
import com.mandiri.salestools.fragments.profile.PenawaranFragment;


public class ProfilePagerAdapter extends SmartFragmentStatePagerAdapter {

	private Context mContext;

	public ProfilePagerAdapter(Context context, FragmentManager fm) {
		super(fm);
		mContext = context;
	}

	@Override
	public int getItemPosition(Object object) {
		return POSITION_UNCHANGED;
	}

	@Override
	public BaseFragment getItem(int position) {
		if (position == 0) {
			return OverviewFragment.newInstance();
		} else {
			return PenawaranFragment.newInstance();
		}
	}

	@Override
	public int getCount() {
		return 2;
	}

	public CharSequence getPageTitle(int position) {
		if (position == 0)
			return mContext.getString(R.string.overview);
		else
			return mContext.getString(R.string.penawaran);
	}
}