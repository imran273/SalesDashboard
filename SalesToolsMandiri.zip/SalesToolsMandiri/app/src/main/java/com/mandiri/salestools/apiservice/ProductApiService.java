package com.mandiri.salestools.apiservice;

import android.content.Context;
import android.os.Bundle;

import com.loopj.android.http.TextHttpResponseHandler;
import com.mandiri.salestools.constants.ApiCons;
import com.mandiri.salestools.constants.URLCons;
import com.mandiri.salestools.http.MandiriClient;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.products.Product;
import com.mandiri.salestools.model.products.ProductResponse;
import com.mandiri.salestools.utils.Preferences;

import org.apache.http.Header;

import java.util.List;

/**
 * Created by esa on 09/06/15, with awesomeness
 */
public class ProductApiService extends BaseApiService {

	public ProductApiService(Context mContext) {
		super(mContext);
	}

	public void loadProducts(final EventCallback<List<Product>> eventCallback) {
		MandiriClient.get(mContext, URLCons.PRODUCTS + "?q[departementId]=" +
                Preferences.getProfile(mContext).getDepartementId(), new TextHttpResponseHandler() {
			@Override
			public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
				onHandleError(eventCallback, throwable);
			}

			@Override
			public void onSuccess(int statusCode, Header[] headers, String responseString) {
				onHandleSuccess(responseString);
				ProductResponse productResponse = getGson().fromJson(responseString, ProductResponse.class);
				if (productResponse.getError().isNotError()) {
					eventCallback.onEvent(productResponse.getProducts());
				} else
					onFailure(statusCode, null, responseString, new Exception(productResponse
							.getError().getMessage()));
			}
		});
	}

	public void addProduct(final Product product, final EventCallback<Boolean> eventCallback) {
		String json = getGson().toJson(product);
		MandiriClient.postJSON(mContext, URLCons.PRODUCTS, json, new TextHttpResponseHandler() {
			@Override
			public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
				onHandleError(eventCallback, throwable);
			}

			@Override
			public void onSuccess(int statusCode, Header[] headers, String responseString) {
				onHandleSuccess(responseString);
				ProductResponse productResponse = getGson().fromJson(responseString, ProductResponse.class);
				if (productResponse.getError().isNotError()) {

					Bundle bundle = new Bundle();
					bundle.putParcelable(Product.class.getSimpleName(), product);
					bundle.putInt(ApiCons.STATUS_CODE, statusCode);
					eventCallback.onEvent(true, bundle);

				} else
					onFailure(statusCode, null, responseString, new Exception(productResponse
							.getError().getMessage()));
			}
		});
	}
}
