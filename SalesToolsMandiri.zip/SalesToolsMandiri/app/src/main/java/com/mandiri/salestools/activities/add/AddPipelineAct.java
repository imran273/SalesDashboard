package com.mandiri.salestools.activities.add;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.balysv.materialmenu.MaterialMenuDrawable;
import com.mandiri.salestools.MainSalesAct;
import com.mandiri.salestools.R;
import com.mandiri.salestools.adapter.BaseListAdapter;
import com.mandiri.salestools.apiservice.ClientApiService;
import com.mandiri.salestools.apiservice.PipelineApiService;
import com.mandiri.salestools.apiservice.ProductApiService;
import com.mandiri.salestools.apiservice.SalesApiService;
import com.mandiri.salestools.apiservice.StatusApiService;
import com.mandiri.salestools.fragments.BaseFragment;
import com.mandiri.salestools.fragments.dialog.AlertDialogFragment;
import com.mandiri.salestools.fragments.dialog.ProgressDialogFragment;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.action.Action;
import com.mandiri.salestools.model.clients.Client;
import com.mandiri.salestools.model.comment.Comment;
import com.mandiri.salestools.model.pipeline.Pipeline;
import com.mandiri.salestools.model.products.Product;
import com.mandiri.salestools.model.sales.Sales;
import com.mandiri.salestools.model.status.Status;
import com.mandiri.salestools.model.users.User;
import com.mandiri.salestools.utils.CommonUtils;
import com.mandiri.salestools.utils.MandiriDateUtils;
import com.mandiri.salestools.utils.Preferences;
import com.mandiri.salestools.utils.StringValueUtils;
import com.mandiri.salestools.utils.ValidateUtils;
import com.mandiri.salestools.utils.helper.BundleHelper;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;
import butterknife.OnItemSelected;
import butterknife.OnTouch;

/**
 * Created by esa on 09/06/15, with awesomeness
 */
public class AddPipelineAct extends BaseInputAct {

	@InjectView(R.id.toolbar) Toolbar mToolbar;
	@InjectView(R.id.spnCategory) TextView txtCategory;
	@InjectView(R.id.spnSolutionCategory) TextView txtSolutionCategory;
	@InjectView(R.id.inpContent) EditText mInpContent;
	@InjectView(R.id.inpDate) EditText mInpDate;
	@InjectView(R.id.spnClient) Spinner mSpnClientGroup;
//	@InjectView(R.id.inpCustomerGroup) TextView mInpCustomerGroup;
	@InjectView(R.id.spnProduct) Spinner mSpnProduct;
	@InjectView(R.id.spnSales) Spinner mSpnSales;
	@InjectView(R.id.spnOfferingType) Spinner mSpnOfferingType;
	@InjectView(R.id.spnClientName) Spinner mSpnClientName;
	@InjectView(R.id.spnSalesCycle) Spinner mSpnSalesCycle;
	@InjectView(R.id.inpClosedDate) EditText mInpClosedDate;
	@InjectView(R.id.inpCif) TextView mInpCif;
	@InjectView(R.id.spnType) TextView mInpProductType;
	@InjectView(R.id.inpNextAction) TextView mInpAction;
	@InjectView(R.id.inpUpdatingComment) TextView mInpComment;
	@InjectView(R.id.inpGroup) TextView mInpGroup;
	@InjectView(R.id.btnNewCustomer)    Button mBtnNewCustomer;

	/* Estimation */
	@InjectView(R.id.inpEstimationAdtCash) EditText mInpEstimationAdtCash;
	@InjectView(R.id.inpEstimationAdtTrade) EditText mInpEstimationAdtTrade;
	@InjectView(R.id.inpEstimationAdtAvgCash) EditText mInpEstimationAdtAvgCash;
	@InjectView(R.id.inpEstimationOutstanding) EditText mInpEstimationOutstanding;

	private PipelineApiService mApiService;

	/* Adapter */
	private SalesAdapter mSalesAdapter;
	private ClientGroupAdapter mClientAdapter;
	private ClientNameAdapter mClientNameAdapter;
	private ProductAdapter mProductAdapter;
	private SalesCycleAdapter mSalesCycleAdapter;

	/* For Date Picker */
	private Calendar mOpenCalendar = Calendar.getInstance();
	private Calendar mEndCalendar = Calendar.getInstance();
    private ProgressDialogFragment progressDialogFragment;

    private Bundle mPipelineBundle;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add_pipeline);
		ButterKnife.inject(this);

		setupToolbar(mToolbar);
		setTitle(R.string.add_pipeline);
		materialMenuIcon.setState(MaterialMenuDrawable.IconState.ARROW);

		setupView();

		mApiService = new PipelineApiService(mContext);
	}

	private void setupView() {
		txtCategory.setEnabled(false);
		txtSolutionCategory.setEnabled(false);

		mSpnSales.setAdapter(mSalesAdapter = new SalesAdapter(mContext));
        mSpnSalesCycle.setAdapter(mSalesCycleAdapter = new SalesCycleAdapter(mContext));
		mSpnClientGroup.setAdapter(mClientAdapter = new ClientGroupAdapter(mContext));
		mSpnClientName.setAdapter(mClientNameAdapter = new ClientNameAdapter(mContext));
		mSpnProduct.setAdapter(mProductAdapter = new ProductAdapter(mContext));

		mSpnClientGroup.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                return true;
            }
        });

		mSpnSalesCycle.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                return true;
            }
        });

        loadData();

		User user = Preferences.getProfile(mContext);
		if (user.getRole().equalsIgnoreCase("sales")) {
			mSpnSales.setEnabled(false);
			mSpnSalesCycle.setEnabled(false);
			mSpnClientGroup.setEnabled(false);

			Sales sales = new Sales();
			sales.setName(user.getName());
			List<Sales> salesList = new ArrayList<>();
			salesList.add(sales);
			mSalesAdapter.pushData(salesList);
		}
	}

    private void loadData(){
        StatusApiService statusApiService = new StatusApiService(mContext);
        statusApiService.loadStatus(new EventCallback<List<Status>>() {
            @Override
            public void onEvent(List<Status> sales, Bundle bundle) {
                mSalesCycleAdapter.pushData(sales);
            }
        });

        SalesApiService salesApiService = new SalesApiService(mContext);
        salesApiService.loadSales(new EventCallback<List<Sales>>() {
            @Override
            public void onEvent(List<Sales> sales, Bundle bundle) {
                mSalesAdapter.pushData(sales);
            }
        });

        ClientApiService clientApiService = new ClientApiService(mContext);
        clientApiService.loadClients(new EventCallback<List<Client>>() {
            @Override
            public void onEvent(List<Client> clients, Bundle bundle) {

                List<Client> clientNames = new ArrayList<>();
                for (Client client : clients) {
                    if (client.getParentId() != null)
                        clientNames.add(client);
                }
                clients.removeAll(clientNames);

                mClientAdapter.pushData(clients);
                mClientNameAdapter.pushData(clientNames);
            }
        });

        final ProductApiService productApiService = new ProductApiService(mContext);
        productApiService.loadProducts(new EventCallback<List<Product>>() {
            @Override
            public void onEvent(List<Product> products, Bundle bundle) {
                User user = Preferences.getProfile(mContext);

                List<Product> selectedProduct = new ArrayList<>();
                for (Product product : products)
                    if (product.getDepartementId().equals(user.getDepartementId()))
                        selectedProduct.add(product);

                mProductAdapter.pushData(selectedProduct);
            }
        });
    }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.menu_submit, menu);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case R.id.menu_add:
				doSubmitPipeline();
				break;
		}
		return super.onOptionsItemSelected(item);
	}

    @OnClick(R.id.btnNewCustomer)
    public void onNewCustomerClicked(){
        AddCustomerAct.start(mContext);
    }

    @OnClick(R.id.btnViewCallReports)
    public void onCallReportClicked(){
        MainSalesAct.start(mContext, true);
        finish();
    }

	@OnItemSelected(R.id.spnClientName)
	public void onClientNameSelected(int position) {
		Client client = mClientNameAdapter.getItem(position);
		for (int i = 0; i < mClientAdapter.getListData().size(); i++) {
			if (String.valueOf(mClientAdapter.getListData().get(i).getId()).equals(client.getParentId())) {
				mSpnClientGroup.setSelection(i);
//                mInpCustomerGroup.setText(mClientAdapter.getListData().get(i).getName());
                mInpCif.setText(mClientAdapter.getListData().get(i).getCif());
                mInpGroup.setText(mClientAdapter.getListData().get(i).getBusinessUnitCodeId());
				break;
			}
		}
	}

	@OnItemSelected(R.id.spnProduct)
	public void onProductSelected(int position) {
		Product product = mProductAdapter.getItem(position);
		txtCategory.setText(product.getCategory());
		txtSolutionCategory.setText(product.getType());
        mInpProductType.setText(product.getType());
	}

	@OnTouch({R.id.inpDate, R.id.inpClosedDate})
	public boolean onOpenDateTouch(MotionEvent motionEvent, View view) {
		if (motionEvent.getAction() != MotionEvent.ACTION_DOWN)
			return false;
		showDatePickerDialog(view == mInpDate ? mOpenCalendar : mEndCalendar, (EditText) view);
		return true;
	}


	private void showDatePickerDialog(final Calendar calendar, final EditText editText) {
		DatePickerDialog datePickerDialog = new DatePickerDialog(mContext, new DatePickerDialog.OnDateSetListener() {
			@Override
			public void onDateSet(DatePicker datePicker, int year, int month, int day) {
				calendar.set(Calendar.YEAR, year);
				calendar.set(Calendar.MONTH, month);
				calendar.set(Calendar.DAY_OF_MONTH, day);

				editText.setText(MandiriDateUtils.getStringFormattedDate(calendar.getTime()));
			}
		}, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar
				.get(Calendar.DAY_OF_MONTH));

		AlertDialogFragment dialogFragment = new AlertDialogFragment();
		dialogFragment.setDialog(datePickerDialog);
		dialogFragment.show(getSupportFragmentManager().beginTransaction(), DatePicker.class
                .getSimpleName());
	}


	private boolean isValid() {
		String empty = getString(R.string.error_empty_string);
		return ValidateUtils.runningValidationWithViews(empty, mInpClosedDate,
				mInpDate, mInpCif);
	}

	private void doSubmitPipeline() {
		if (!isValid())
			return;
        progressDialogFragment = ProgressDialogFragment.newInstance
                ("Adding...").show(getSupportFragmentManager());

		final Pipeline pipeline = new Pipeline();
        pipeline.setName(mClientAdapter.getItem(mSpnClientGroup.getSelectedItemPosition()).getName());
//		pipeline.setName(StringValueUtils.getValue(mSpnClientGroup));
//        pipeline.setCif(StringValueUtils.getValue(mInpCif));
        pipeline.setDescription(StringValueUtils.getValue(mInpContent));
//        pipeline.setGroupBuc(StringValueUtils.getValue(mInpGroup));

        String estCash = StringValueUtils.getValue(mInpEstimationAdtCash);
        if (TextUtils.isEmpty(estCash))
            pipeline.setEstCash(Integer.valueOf(estCash));
        String estTrade = StringValueUtils.getValue(mInpEstimationAdtTrade);
        if (TextUtils.isEmpty(estTrade))
            pipeline.setEstTrade(Integer.valueOf(estTrade));
        String estAvg = StringValueUtils.getValue(mInpEstimationAdtAvgCash);
        if (TextUtils.isEmpty(estAvg))
            pipeline.setEstAvg(Integer.valueOf(estAvg));
        String estOutstanding = StringValueUtils.getValue(mInpEstimationOutstanding);
        if (TextUtils.isEmpty(estOutstanding))
            pipeline.setEstOutstanding(Integer.valueOf(estOutstanding));

        pipeline.setOfferingType(mSpnOfferingType.getSelectedItem().toString());
        pipeline.setOpenDate(StringValueUtils.getValue(mInpDate));
        pipeline.setExpectedCloseDate(StringValueUtils.getValue(mInpClosedDate));
        pipeline.setDepartementId(mSalesAdapter.getItem(mSpnSales.getSelectedItemPosition()).getDepartementId());
        pipeline.setStatusId(mSalesCycleAdapter.getItem(mSpnSalesCycle.getSelectedItemPosition()).getId());
        pipeline.setSalesId(mSalesAdapter.getItem(mSpnSales.getSelectedItemPosition()).getId());
        pipeline.setClientId(mClientAdapter.getItem(mSpnClientGroup.getSelectedItemPosition()).getId());
        pipeline.setProductId(mProductAdapter.getItem(mSpnProduct.getSelectedItemPosition()).getId());
//        pipeline.setAction(StringValueUtils.getValue(mInpAction));
//        pipeline.setComment(StringValueUtils.getValue(mInpComment));

		if (!mSpnSales.isEnabled())
			pipeline.setSalesId(Integer.valueOf(Preferences.getProfile(mContext).getSalesId()));

//		User user = Preferences.getProfile(mContext);
//		pipeline.setDepartementId(Integer.valueOf(user.getDepartementId()));

		mApiService.addPipeline(pipeline, new EventCallback<Boolean>() {
			@Override
			public void onEvent(Boolean data, Bundle bundle) {
				progressDialogFragment.dismissAllowingStateLoss();

				if (data == null) {
					CommonUtils.toastShort(mContext, R.string.error_string);
					return;
				}

                mPipelineBundle = bundle;
                Pipeline  mPipeline = mPipelineBundle.getParcelable(Pipeline.class.getSimpleName());
                if (!TextUtils.isEmpty(StringValueUtils.getValue(mInpAction))){
                    addPipelineAction(mPipeline, StringValueUtils.getValue(mInpAction), StringValueUtils.getValue(mInpComment));
                    return;
                }
                if (!TextUtils.isEmpty(StringValueUtils.getValue(mInpComment))){
                    addPipelineComment(mPipeline, StringValueUtils.getValue(mInpComment));
                    return;
                }

                setResult(Activity.RESULT_OK, BundleHelper.createIntentWithBundle(bundle));
				finish();
			}
		});
	}

    private void addPipelineAction(final Pipeline pipeline, String actionString, final String comment){
        pipeline.setAction(actionString);

        Action action = new Action();
        action.setNextAction(actionString);
        action.setOfferingId(Integer.parseInt(pipeline.getId()));
        action.setStatusId(Integer.parseInt(pipeline.getStatusId()));

        mApiService.addPipelineAction(action, new EventCallback<Boolean>() {
            @Override
            public void onEvent(Boolean data, Bundle bundle) {
                progressDialogFragment.dismissAllowingStateLoss();

                if (data == null) {
                    if (mPipelineBundle != null){
                        setResult(Activity.RESULT_OK, BundleHelper.createIntentWithBundle(mPipelineBundle));
                        finish();
                        return;
                    }
                    CommonUtils.toastShort(mContext, R.string.error_string);
                    return;
                }

                if (!TextUtils.isEmpty(comment)){
                    addPipelineComment(pipeline, StringValueUtils.getValue(mInpComment));
                    return;
                }

                setResult(Activity.RESULT_OK, BundleHelper.createIntentWithBundle(mPipelineBundle));
                finish();
            }
        });
    }

    private void addPipelineComment(Pipeline pipeline, String commentString){
        pipeline.setComment(commentString);

        Comment comment = new Comment();
        comment.setComment(commentString);
        comment.setOfferingId(Integer.parseInt(pipeline.getId()));
        comment.setUserId(Preferences.getUserId(mContext));

        mApiService.addPipelineComment(comment, new EventCallback<Boolean>() {
            @Override
            public void onEvent(Boolean data, Bundle bundle) {
                progressDialogFragment.dismissAllowingStateLoss();

                if (data == null) {
                    if (mPipelineBundle != null){
                        setResult(Activity.RESULT_OK, BundleHelper.createIntentWithBundle(mPipelineBundle));
                        finish();
                        return;
                    }
                    CommonUtils.toastShort(mContext, R.string.error_string);
                    return;
                }
                setResult(Activity.RESULT_OK, BundleHelper.createIntentWithBundle(mPipelineBundle));
                finish();
            }
        });
    }

	/* ------------- ADAPTER ------------- */

	private class ProductAdapter extends BaseListAdapter<Product> {

		public ProductAdapter(Context context) {
			super(context);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			return getView(false, position, convertView, parent);
		}

		@Override
		public View getDropDownView(int position, View convertView, ViewGroup parent) {
			return getView(true, position, convertView, parent);
		}

		private View getView(boolean isDropDown, int position, View convertView, ViewGroup parent) {

			if (convertView == null)
				convertView = mInflater.inflate(isDropDown ? android.R.layout.simple_spinner_dropdown_item
						: android.R.layout.simple_spinner_item, parent, false);

			TextView textView = (TextView) convertView;
			textView.setText(mListData.get(position).getName());

			return convertView;
		}
	}

	private class ClientNameAdapter extends BaseListAdapter<Client> {

		public ClientNameAdapter(Context context) {
			super(context);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			return getView(false, position, convertView, parent);
		}

		@Override
		public View getDropDownView(int position, View convertView, ViewGroup parent) {
			return getView(true, position, convertView, parent);
		}

		private View getView(boolean isDropDown, int position, View convertView, ViewGroup parent) {

			if (convertView == null)
				convertView = mInflater.inflate(isDropDown ? android.R.layout.simple_spinner_dropdown_item
						: android.R.layout.simple_spinner_item, parent, false);

			TextView textView = (TextView) convertView;
			textView.setText(mListData.get(position).getName());

			return convertView;
		}
	}

	private class ClientGroupAdapter extends BaseListAdapter<Client> {

		public ClientGroupAdapter(Context context) {
			super(context);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			return getView(false, position, convertView, parent);
		}

		@Override
		public View getDropDownView(int position, View convertView, ViewGroup parent) {
			return getView(true, position, convertView, parent);
		}

		private View getView(boolean isDropDown, int position, View convertView, ViewGroup parent) {

			if (convertView == null)
				convertView = mInflater.inflate(isDropDown ? android.R.layout.simple_spinner_dropdown_item
						: android.R.layout.simple_spinner_item, parent, false);

			TextView textView = (TextView) convertView;
			textView.setText(mListData.get(position).getName());

			return convertView;
		}
	}

	private class SalesAdapter extends BaseListAdapter<Sales> {

		public SalesAdapter(Context context) {
			super(context);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			return getView(false, position, convertView, parent);
		}

		@Override
		public View getDropDownView(int position, View convertView, ViewGroup parent) {
			return getView(true, position, convertView, parent);
		}

		private View getView(boolean isDropDown, int position, View convertView, ViewGroup parent) {

			if (convertView == null)
				convertView = mInflater.inflate(isDropDown ? android.R.layout.simple_spinner_dropdown_item
						: android.R.layout.simple_spinner_item, parent, false);

			TextView textView = (TextView) convertView;
			textView.setText(mListData.get(position).getName());

			return convertView;
		}
	}

	private class SalesCycleAdapter extends BaseListAdapter<Status> {

		public SalesCycleAdapter(Context context) {
			super(context);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			return getView(false, position, convertView, parent);
		}

		@Override
		public View getDropDownView(int position, View convertView, ViewGroup parent) {
			return getView(true, position, convertView, parent);
		}

		private View getView(boolean isDropDown, int position, View convertView, ViewGroup parent) {

			if (convertView == null)
				convertView = mInflater.inflate(isDropDown ? android.R.layout.simple_spinner_dropdown_item
						: android.R.layout.simple_spinner_item, parent, false);

			TextView textView = (TextView) convertView;
			textView.setText(mListData.get(position).getName());

			return convertView;
		}
	}

    @Override
    protected void onResume() {
        super.onResume();
        loadData();
    }

    /* ---------- LAUNCHER ------------ */

	public static void startForResult(BaseFragment baseFragment) {
		baseFragment.startActivityForResult(new Intent(baseFragment.getActivity(), AddPipelineAct
				.class), BaseInputAct.BASE_INPUT_CODE);
	}
}
