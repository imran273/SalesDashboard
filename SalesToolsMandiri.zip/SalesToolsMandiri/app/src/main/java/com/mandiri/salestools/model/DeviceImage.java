package com.mandiri.salestools.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by esa on 05/01/15, with awesomeness
 */
public class DeviceImage implements Parcelable {

	private String id;
	private String bucketId;
	private String filePath;
	private String thumbnail;
	private int orientation;
	private boolean isCoruppted;

	public int getOrientation() {
		return orientation;
	}

	public void setOrientation(int orientation) {
		this.orientation = orientation;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getBucketId() {
		return bucketId;
	}

	public void setBucketId(String bucketId) {
		this.bucketId = bucketId;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public DeviceImage() {
	}

	public String getThumbnail() {
		return thumbnail;
	}

	public void setThumbnail(String thumbnail) {
		this.thumbnail = thumbnail;
	}

	public String getAvailableImage() {
		return thumbnail != null ? thumbnail : filePath;
	}

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(this.id);
		dest.writeString(this.bucketId);
		dest.writeString(this.filePath);
		dest.writeString(this.thumbnail);
		dest.writeInt(this.orientation);
	}

	private DeviceImage(Parcel in) {
		this.id = in.readString();
		this.bucketId = in.readString();
		this.filePath = in.readString();
		this.thumbnail = in.readString();
		this.orientation = in.readInt();
	}

	public static final Creator<DeviceImage> CREATOR = new Creator<DeviceImage>() {
		public DeviceImage createFromParcel(Parcel source) {
			return new DeviceImage(source);
		}

		public DeviceImage[] newArray(int size) {
			return new DeviceImage[size];
		}
	};

	public boolean isCoruppted() {
		return isCoruppted;
	}

	public void setCoruppted(boolean isCoruppted) {
		this.isCoruppted = isCoruppted;
	}
}
