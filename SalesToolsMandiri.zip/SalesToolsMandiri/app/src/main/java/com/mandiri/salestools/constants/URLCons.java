package com.mandiri.salestools.constants;

/**
 * This class only for URL constant
 */
public final class URLCons {

	private static final String URL_BASE = "http://45.64.96.237:3000/";
	private static final String URL_BASE_V1 = "http://45.64.96.237:3000/api/v1/";

	public static final String URL_IMAGE = URL_BASE + "report/";

	/* Auth */
	public static final String AUTH_LOGIN = URL_BASE + "auth/login";

	/* Schedules */
	public static final String SCHEDULES = URL_BASE_V1 + "schedules";
	public static final String SCHEDULES_FULL = URL_BASE_V1 + "schedules/%s/full";

	/* Pipeline */
	public static final String PIPELINE = URL_BASE_V1 + "offerings";
	public static final String OFFERING_ACTION = URL_BASE_V1 + "offering-actions";
	public static final String OFFERING_COMMENT = URL_BASE_V1 + "comments";

	/* Realization */
	public static final String REALIZATIONS = URL_BASE_V1 + "realizations";
	public static final String REALIZATIONS_FULL = URL_BASE_V1 + "realizations/1/full";

	/* Report */
	public static final String REPORTS = URL_BASE_V1 + "reports";
	public static final String REPORTS_ACTIONS = URL_BASE_V1 + "report-actions";
	public static final String REPORTS_FULL = URL_BASE_V1 + "reports/1/full";

	/* Products */
	public static final String PRODUCTS = URL_BASE_V1 + "products";

	/* Clients */
	public static final String CLIENTS = URL_BASE_V1 + "clients";

	/* Client PICs */
	public static final String CLIENT_PICS = URL_BASE_V1 + "client-pics";
	public static final String CLIENT_PICS_BULK = URL_BASE_V1 + "client-pics/bulk-create";

	/* Sales */
	public static final String SALES = URL_BASE_V1 + "sales";

	/* Sales-Cycles */
	public static final String SALES_CYCLES = URL_BASE_V1 + "sales-cycles";

	/* Users */
	public static final String USER = URL_BASE_V1 + "users";

	/* Status */
	public static final String STATUS = URL_BASE_V1 + "status";

	/* Division */
	public static final String DIVISIONS = URL_BASE_V1 + "divisions";

	/* Departements */
	public static final String DEPARTEMENTS = URL_BASE_V1 + "departements";

	/* Industrial Sectors */
	public static final String INDUSTRIAL_SECTORS = URL_BASE_V1 + "industrial-sectors";

	/* Business Unit Code (BUC) */
	public static final String BUC = URL_BASE_V1 + "business-unit-codes";

	/* Client Information (CIF) */
	public static final String CIF = URL_BASE_V1 + "client-informations";
	public static final String CIF_BULK = URL_BASE_V1 + "client-informations/bulk-create";
}