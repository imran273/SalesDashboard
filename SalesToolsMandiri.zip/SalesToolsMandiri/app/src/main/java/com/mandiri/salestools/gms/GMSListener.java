package com.mandiri.salestools.gms;

import android.os.Bundle;

public interface GMSListener {
	void onServiceConnected(Bundle bundle);

	void onConnectionFailed();
}