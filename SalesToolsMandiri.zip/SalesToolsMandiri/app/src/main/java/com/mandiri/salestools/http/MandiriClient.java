package com.mandiri.salestools.http;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.mandiri.salestools.constants.URLCons;
import com.mandiri.salestools.utils.Logger;
import com.mandiri.salestools.utils.Preferences;

import org.apache.http.entity.StringEntity;

import java.io.UnsupportedEncodingException;

public class MandiriClient {

	private static final String PARAMATER_KEY_INVALID = "key invalid";

	private static final AsyncHttpClient client = new AsyncHttpClient();

	public static void init() {
		client.setTimeout(40000);
	}

	public static void cancel(Context context) {
		client.cancelRequests(context, true);
	}

	public static void get(Context context, String url, AsyncHttpResponseHandler responseHandler) {
		get(context, url, null, responseHandler);
	}

	public static void delete(Context context, String url, AsyncHttpResponseHandler responseHandler) {
		onMakeRequest(context, url, null, responseHandler);
		client.delete(context, url, responseHandler);
	}

	public static void get(final Context context, final String url, RequestParams params, final AsyncHttpResponseHandler responseHandler) {
		params = embedKeySession(context, url, params);
		onMakeRequest(context, url, params, responseHandler);
		client.get(context, url, params, responseHandler);
	}

	public static void put(final Context context, final String url, String jsonString, final AsyncHttpResponseHandler responseHandler) {
		onMakeRequest(context, url, null, responseHandler);

		StringEntity entity = null;
		try {
			entity = new StringEntity(jsonString);
		} catch (UnsupportedEncodingException e) {
			Logger.log(e);
		}

		String key = Preferences.getToken(context);
		if (!TextUtils.isEmpty(key))
			client.addHeader("authorization", "Bearer " + key);

		client.addHeader("Content-Type", "application/json");
		client.addHeader("Auth-Key", "098m4dD0g6123geT!@#$");
		client.put(context, url, entity, "application/json", responseHandler);
	}

	public static void postJSON(Context context, String url, String jsonString, AsyncHttpResponseHandler responseHandler) {
		onMakeRequest(context, url, null, responseHandler);
		Logger.log(Log.DEBUG, "JSON Params:" + jsonString);

		StringEntity entity = null;
		try {
			entity = new StringEntity(jsonString);
		} catch (UnsupportedEncodingException e) {
			Logger.log(e);
		}

		String key = Preferences.getToken(context);
		if (!TextUtils.isEmpty(key))
			client.addHeader("authorization", "Bearer " + key);

		client.addHeader("Content-Type", "application/json");
		client.addHeader("Auth-Key", "098m4dD0g6123geT!@#$");
		client.post(context, url, entity, "application/json", responseHandler);
	}

	private static RequestParams embedKeySession(Context context, String url, RequestParams requestParams) {
		String key = Preferences.getToken(context);
		if (key == null && url.equalsIgnoreCase(URLCons.AUTH_LOGIN))
			return requestParams;

//		if (requestParams == null)
//			requestParams = new RequestParams();
//
//		if (Preferences.getUserId(context) != 0 && !requestParams.has("salesId"))
//			requestParams.put("salesId", Preferences.getUserId(context));

		if (!TextUtils.isEmpty(key))
			client.addHeader("authorization", "Bearer " + key);

		return requestParams;
	}

	private static void onMakeRequest(Context context, String url, RequestParams params, AsyncHttpResponseHandler handler) {
		if (params != null) {
			Logger.log(Log.INFO, "MakeRequest: ".concat(url) + "?" + params.toString());
		} else {
			Logger.log(Log.INFO, "MakeRequest: ".concat(url));
		}
	}

}
