package com.mandiri.salestools.model.action;

import android.os.Parcel;
import android.os.Parcelable;

public class Action implements Parcelable {

    /**
     * createdAt : 2015-06-09T12:00:00.000Z
     * deletedAt : null
     * statusId : 1
     * id : 1
     * nextAction : rencana meet up selanjutnya oleh client
     * offeringId : 1
     * updatedAt : 2015-06-09T12:00:00.000Z
     */
    private String createdAt;
    private String deletedAt;
    private int statusId;
    private int id;
    private String nextAction;
    private int offeringId;
    private String updatedAt;

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public void setDeletedAt(String deletedAt) {
        this.deletedAt = deletedAt;
    }

    public void setStatusId(int statusId) {
        this.statusId = statusId;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNextAction(String nextAction) {
        this.nextAction = nextAction;
    }

    public void setOfferingId(int offeringId) {
        this.offeringId = offeringId;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public String getDeletedAt() {
        return deletedAt;
    }

    public int getStatusId() {
        return statusId;
    }

    public int getId() {
        return id;
    }

    public String getNextAction() {
        return nextAction;
    }

    public int getOfferingId() {
        return offeringId;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.createdAt);
        dest.writeString(this.deletedAt);
        dest.writeInt(this.statusId);
        dest.writeInt(this.id);
        dest.writeString(this.nextAction);
        dest.writeInt(this.offeringId);
        dest.writeString(this.updatedAt);
    }

    public Action() {
    }

    protected Action(Parcel in) {
        this.createdAt = in.readString();
        this.deletedAt = in.readString();
        this.statusId = in.readInt();
        this.id = in.readInt();
        this.nextAction = in.readString();
        this.offeringId = in.readInt();
        this.updatedAt = in.readString();
    }

    public static final Creator<Action> CREATOR = new Creator<Action>() {
        public Action createFromParcel(Parcel source) {
            return new Action(source);
        }

        public Action[] newArray(int size) {
            return new Action[size];
        }
    };
}