package com.mandiri.salestools.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mandiri.salestools.R;
import com.mandiri.salestools.model.CIFs;
import com.mandiri.salestools.utils.ValidateUtils;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

/**
 * Created by esa on 18/08/15, with awesomeness
 */
public class CIFInputForm extends LinearLayout {

	@InjectView(R.id.cif_form_title) TextView mTxtTitle;
	@InjectView(R.id.cif_form_name) EditText mInpCIF;
	@InjectView(R.id.cif_form_position) EditText mInpNoRek;
	@InjectView(R.id.cif_form_delete) View mBtnDelete;

	private CIFInputFormListener mListener;

	public CIFInputForm(Context context) {
		this(context, null);
	}

	public CIFInputForm(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public CIFInputForm(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		init();
	}

	private void init() {
		setOrientation(LinearLayout.VERTICAL);
		LayoutInflater.from(getContext()).inflate(R.layout.view_cif_input_form, this, true);
		ButterKnife.inject(this);
	}

	public void setTitle(String title) {
		mTxtTitle.setText(title);
	}

	public boolean isFormValid() {
		return ValidateUtils.runningValidationWithViews(getString(R.string.required), mInpCIF, mInpNoRek);
	}

	private String getString(int resId) {
		return getContext().getString(resId);
	}

	public void setListener(CIFInputFormListener listener) {
		mListener = listener;
	}

	public void setHintNumber(String number) {
		mInpNoRek.setHint(getString(R.string.no_rek) + " " + number);
		mInpCIF.setHint(getString(R.string.cif) + " " + number);
	}

	public CIFs.CIF getCIF() {
		CIFs.CIF cif = new CIFs.CIF();
		cif.setAccount(mInpNoRek.getText().toString());
		cif.setCif(mInpCIF.getText().toString());
		return cif;
	}

	@OnClick(R.id.cif_form_delete)
	public void onDeleteClick() {
		if (mListener != null)
			mListener.onDeleteButtonClick(this);
	}

	public void setDeleteable(boolean isDeleteable) {
		mBtnDelete.setVisibility(isDeleteable ? View.VISIBLE : View.INVISIBLE);
	}

	public interface CIFInputFormListener {
		void onDeleteButtonClick(CIFInputForm picInputForm);
	}
}
