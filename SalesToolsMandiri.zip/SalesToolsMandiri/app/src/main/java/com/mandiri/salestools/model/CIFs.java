package com.mandiri.salestools.model;

import java.util.List;

/**
 * Created by esa on 17/08/15, with awesomeness
 */
public class CIFs extends BaseDao {
	/**
	 * clientInformations : []
	 */
	private List<CIF> clientInformations;

	public void setClientInformations(List<CIF> clientInformations) {
		this.clientInformations = clientInformations;
	}

	public List<CIF> getClientInformations() {
		return clientInformations;
	}

	public static class CIF {

		private String cif;
		private String account;
		private String clientId;

		public String getCif() {
			return cif;
		}

		public void setCif(String cif) {
			this.cif = cif;
		}

		public String getAccount() {
			return account;
		}

		public void setAccount(String account) {
			this.account = account;
		}

		public String getClientId() {
			return clientId;
		}

		public void setClientId(String clientId) {
			this.clientId = clientId;
		}
	}
}
