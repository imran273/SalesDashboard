/*
 * Copyright (c) 2015. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.
 * Vestibulum commodo. Ut rhoncus gravida arcu.
 */

package com.mandiri.salestools.model.comment;

import android.os.Parcel;

import com.mandiri.salestools.model.BaseDao;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by esa on 04/06/15, with awesomeness
 */
public class CommentsResponse extends BaseDao {

	private List<Comment> comments;

	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}

	public List<Comment> getPipelines() {
		return comments;
	}

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		super.writeToParcel(dest, flags);
		dest.writeList(this.comments);
	}

	public CommentsResponse() {
	}

	protected CommentsResponse(Parcel in) {
		this.comments = new ArrayList<>();
		in.readList(this.comments, List.class.getClassLoader());
	}

	public static final Creator<CommentsResponse> CREATOR = new Creator<CommentsResponse>() {
		public CommentsResponse createFromParcel(Parcel source) {
			return new CommentsResponse(source);
		}

		public CommentsResponse[] newArray(int size) {
			return new CommentsResponse[size];
		}
	};
}
