package com.mandiri.salestools.model.sales;

import android.os.Parcel;

import com.mandiri.salestools.model.BaseDao;

import java.util.List;

/**
 * Created by deni on 09/06/15
 */
public class SalesDao extends BaseDao {

	private List<Sales> sales;
    private SalesStatistic statistics;

    public List<Sales> getSales() {
        return sales;
    }

    public void setSales(List<Sales> sales) {
        this.sales = sales;
    }

    public SalesStatistic getStatistics() {
        return statistics;
    }

    public void setStatistics(SalesStatistic statistics) {
        this.statistics = statistics;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeTypedList(sales);
        dest.writeParcelable(this.statistics, 0);
    }

    public SalesDao() {
    }

    protected SalesDao(Parcel in) {
        this.sales = in.createTypedArrayList(Sales.CREATOR);
        this.statistics = in.readParcelable(SalesStatistic.class.getClassLoader());
    }

    public static final Creator<SalesDao> CREATOR = new Creator<SalesDao>() {
        public SalesDao createFromParcel(Parcel source) {
            return new SalesDao(source);
        }

        public SalesDao[] newArray(int size) {
            return new SalesDao[size];
        }
    };
}
