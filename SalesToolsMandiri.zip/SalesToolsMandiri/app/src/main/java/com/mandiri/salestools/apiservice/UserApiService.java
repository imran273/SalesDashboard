package com.mandiri.salestools.apiservice;

import android.content.Context;
import android.util.Log;

import com.loopj.android.http.TextHttpResponseHandler;
import com.mandiri.salestools.constants.URLCons;
import com.mandiri.salestools.http.MandiriClient;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.sales.Sales;
import com.mandiri.salestools.model.users.User;
import com.mandiri.salestools.model.users.UserDao;
import com.mandiri.salestools.utils.Logger;

import org.apache.http.Header;

import java.util.List;

public class UserApiService extends BaseApiService {

	public UserApiService(Context mContext) {
		super(mContext);
	}

//    public void loadSalesFull(final EventCallback<List<Sales>> eventCallback) {
//        loadDepartement(URLCons.SALES_FULL, eventCallback);
//    }

    public void loadUser(final EventCallback<List<User>> eventCallback) {
        loadUser(URLCons.USER, eventCallback);
    }

	private void loadUser(final String url,
                          final EventCallback<List<User>> eventCallback) {

		MandiriClient.get(mContext, url, new TextHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, String response) {
                Logger.log(Log.DEBUG, "Response :" + response);
                try {
                    UserDao baseApiDao = getGson().fromJson(response, UserDao.class);
                    if (baseApiDao.getError().getMessage() == null) {
                        List<User> report = baseApiDao.getUsers();

                        eventCallback.onEvent(report);
                    } else {
                        eventCallback.onEvent(null);
                    }
                } catch (Exception e) {
                    onFailure(statusCode, headers, response, e);
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                Logger.log(throwable);
                eventCallback.onEvent(null);
            }
        });
	}

	public void doAddSales(final Sales sales,
                           final EventCallback<User> eventCallback) {

//        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        String date = df.format(Calendar.getInstance().getTime());
//        sales.setStartDate(date);
        String json = getGson().toJson(sales);

		MandiriClient.postJSON(mContext, URLCons.USER, json, new TextHttpResponseHandler() {
			@Override
			public void onSuccess(int statusCode, Header[] headers, String response) {
				Logger.log(Log.DEBUG, "Response :" + response);
				try {
                    UserDao baseApiDao = getGson().fromJson(response, UserDao.class);
                    if (baseApiDao.getError().getMessage() == null) {
                        User user = baseApiDao.getUsers().get(0);

                        eventCallback.onEvent(user);
                    } else {
                        eventCallback.onEvent(null);
                    }
				} catch (Exception e) {
					onFailure(statusCode, headers, response, e);
				}
			}

			@Override
			public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
				Logger.log(throwable);
				eventCallback.onEvent(null);
			}
		});
	}
}
