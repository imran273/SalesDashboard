/*
 * Copyright (C) 2013 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.mandiri.salestools.utils;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.mandiri.salestools.R;
import com.mandiri.salestools.listener.EventCallback;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

/**
 * Defines app-wide constants and utilities
 */
public final class LocationUtils {

	public final static int CONNECTION_FAILURE_RESOLUTION_REQUEST = 9000;
	public static final int MILLISECONDS_PER_SECOND = 1000;
	public static final int UPDATE_INTERVAL_IN_SECONDS = 5;
	public static final int FAST_CEILING_IN_SECONDS = 1;
	public static final long UPDATE_INTERVAL_IN_MILLISECONDS = MILLISECONDS_PER_SECOND * UPDATE_INTERVAL_IN_SECONDS;
	public static final long FAST_INTERVAL_CEILING_IN_MILLISECONDS = MILLISECONDS_PER_SECOND * FAST_CEILING_IN_SECONDS;

	public static final String EMPTY_STRING = "";

	public static String getLatLng(Context context, Location currentLocation) {
		if (currentLocation != null) {
			return context.getString(
					R.string.latitude_longitude,
					currentLocation.getLatitude(),
					currentLocation.getLongitude());
		} else
			return EMPTY_STRING;
	}

	public static String getLocationString(Location location) {
		Logger.log(Log.INFO, "Location lat:" + location.getLatitude());
		Logger.log(Log.INFO, "Location lng:" + location.getLongitude());
		Logger.log(Log.INFO, "Location acc:" + location.getAccuracy());
		Logger.log(Log.INFO, "Location  time" + location.getTime());
		Logger.log(Log.INFO, "Location bearing:" + location.getBearing());
		return String.valueOf(location.getLatitude()) + ":" + location.getLongitude() + ":" + location.getAccuracy();
	}

	public static Location getLocationFromString(String content) {
		String[] data = content.split(":");
		Location location = new Location(LocationManager.GPS_PROVIDER);
		location.setLatitude(Double.valueOf(data[0]));
		location.setLongitude(Double.valueOf(data[1]));
		location.setAccuracy(Float.valueOf(data[2]));
		return location;
	}

	public static void getLocationName(final Context context, final double lat, final double lng, final EventCallback<String> eventCallback) {
		final Handler mHandler = new Handler(Looper.getMainLooper());
		new Thread(new Runnable() {
			@Override
			public void run() {
				Geocoder geocoder = new Geocoder(context, Locale.getDefault());
				List<Address> addresses;
				String address = null;

				try {
					addresses = geocoder.getFromLocation(lat, lng, 1);
					if (addresses.size() > 0)
						address = addresses.get(0).getAddressLine(0) + ", " +
								addresses.get(0).getAddressLine(1) + ", " +
								addresses.get(0).getAddressLine(2);
				} catch (IOException e) {
					Logger.log(e);
				}

				final String finalAddress = address;
				mHandler.post(new Runnable() {
					@Override
					public void run() {
						eventCallback.onEvent(finalAddress);
					}
				});
			}
		}).start();
	}
}
