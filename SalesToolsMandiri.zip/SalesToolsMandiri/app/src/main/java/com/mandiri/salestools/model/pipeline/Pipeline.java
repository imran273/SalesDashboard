package com.mandiri.salestools.model.pipeline;

import android.os.Parcel;
import android.os.Parcelable;

import com.mandiri.salestools.model.schedule.Schedule;
import com.mandiri.salestools.model.status.Status;

public class Pipeline implements Parcelable {

	/**
	 * clientId : 1
	 * expectedCloseDateRevised : 0000-00-00 00:00:00
	 * description : Deni adalah programmer android yang huwala...
	 * departementId : 2
	 * type : cash
	 * expectedCloseDate : 2015-06-29T17:00:00.000Z
	 * createdAt : 2015-06-10T15:25:45.000Z
	 * deletedAt : null
	 * salesId : 1
	 * statusId : 1
	 * closeImplementationDate : 0000-00-00 00:00:00
	 * dealEnded : 0000-00-00 00:00:00
	 * name : Deni Huwala
	 * wonDate : 0000-00-00 00:00:00
	 * dealDate : 0000-00-00 00:00:00
	 * id : 4
	 * category : simple
	 * openDate : 2015-06-09T17:00:00.000Z
	 * updatedAt : 2015-06-10T15:25:45.000Z
	 * estTrade : 0
	 * estOutstanding : 0
	 * estCash : 0
	 * estAvg : 0
	 */

	private int clientId;
	private String expectedCloseDateRevised;
	private String description;
	private int departementId;
	private String expectedCloseDate;
	private String createdAt;
	private String deletedAt;
	private int salesId;
	private String statusId;
	private String closeImplementationDate;
	private String dealEnded;
	private String name;
	private String wonDate;
	private String dealDate;
	private String id;
	private String openDate;
	private String updatedAt;
	private String cif;
	private String productId;
	private String offeringType;
	private int estTrade;
	private int estOutstanding;
	private int estCash;
	private int estAvg;
	private String groupBuc;
	private String action;
	private String comment;
	private String productType;
	private String cycleDeal;

	/* Relation */
	private Status status;
	private Schedule schedule;

	public int getClientId() {
		return clientId;
	}

	public void setClientId(int clientId) {
		this.clientId = clientId;
	}

	public String getExpectedCloseDateRevised() {
		return expectedCloseDateRevised;
	}

	public void setExpectedCloseDateRevised(String expectedCloseDateRevised) {
		this.expectedCloseDateRevised = expectedCloseDateRevised;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getDepartementId() {
		return departementId;
	}

	public void setDepartementId(int departementId) {
		this.departementId = departementId;
	}

	public String getExpectedCloseDate() {
		return expectedCloseDate;
	}

	public void setExpectedCloseDate(String expectedCloseDate) {
		this.expectedCloseDate = expectedCloseDate;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public String getDeletedAt() {
		return deletedAt;
	}

	public void setDeletedAt(String deletedAt) {
		this.deletedAt = deletedAt;
	}

	public int getSalesId() {
		return salesId;
	}

	public void setSalesId(int salesId) {
		this.salesId = salesId;
	}

	public String getStatusId() {
		return statusId;
	}

	public void setStatusId(String statusId) {
		this.statusId = statusId;
	}

	public String getCloseImplementationDate() {
		return closeImplementationDate;
	}

	public void setCloseImplementationDate(String closeImplementationDate) {
		this.closeImplementationDate = closeImplementationDate;
	}

	public String getDealEnded() {
		return dealEnded;
	}

	public void setDealEnded(String dealEnded) {
		this.dealEnded = dealEnded;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getWonDate() {
		return wonDate;
	}

	public void setWonDate(String wonDate) {
		this.wonDate = wonDate;
	}

	public String getDealDate() {
		return dealDate;
	}

	public void setDealDate(String dealDate) {
		this.dealDate = dealDate;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOpenDate() {
		return openDate;
	}

	public void setOpenDate(String openDate) {
		this.openDate = openDate;
	}

	public String getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getOfferingType() {
		return offeringType;
	}

	public void setOfferingType(String offeringType) {
		this.offeringType = offeringType;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Schedule getSchedule() {
		return schedule;
	}

	public void setSchedule(Schedule schedule) {
		this.schedule = schedule;
	}

	public Pipeline() {
	}

	public void setEstTrade(int estTrade) {
		this.estTrade = estTrade;
	}

	public void setEstOutstanding(int estOutstanding) {
		this.estOutstanding = estOutstanding;
	}

	public void setEstCash(int estCash) {
		this.estCash = estCash;
	}

	public void setEstAvg(int estAvg) {
		this.estAvg = estAvg;
	}

	public int getEstTrade() {
		return estTrade;
	}

	public int getEstOutstanding() {
		return estOutstanding;
	}

	public int getEstCash() {
		return estCash;
	}

	public int getEstAvg() {
		return estAvg;
	}

	public void setGroupBuc(String groupBuc) {
		this.groupBuc = groupBuc;
	}

	public String getGroupBuc() {
		return groupBuc;
	}

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getCycleDeal() {
        return cycleDeal;
    }

    public void setCycleDeal(String cycleDeal) {
        this.cycleDeal = cycleDeal;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.clientId);
        dest.writeString(this.expectedCloseDateRevised);
        dest.writeString(this.description);
        dest.writeInt(this.departementId);
        dest.writeString(this.expectedCloseDate);
        dest.writeString(this.createdAt);
        dest.writeString(this.deletedAt);
        dest.writeInt(this.salesId);
        dest.writeString(this.statusId);
        dest.writeString(this.closeImplementationDate);
        dest.writeString(this.dealEnded);
        dest.writeString(this.name);
        dest.writeString(this.wonDate);
        dest.writeString(this.dealDate);
        dest.writeString(this.id);
        dest.writeString(this.openDate);
        dest.writeString(this.updatedAt);
        dest.writeString(this.cif);
        dest.writeString(this.productId);
        dest.writeString(this.offeringType);
        dest.writeInt(this.estTrade);
        dest.writeInt(this.estOutstanding);
        dest.writeInt(this.estCash);
        dest.writeInt(this.estAvg);
        dest.writeString(this.groupBuc);
        dest.writeString(this.action);
        dest.writeString(this.comment);
        dest.writeString(this.productType);
        dest.writeString(this.cycleDeal);
        dest.writeParcelable(this.status, 0);
        dest.writeParcelable(this.schedule, 0);
    }

    protected Pipeline(Parcel in) {
        this.clientId = in.readInt();
        this.expectedCloseDateRevised = in.readString();
        this.description = in.readString();
        this.departementId = in.readInt();
        this.expectedCloseDate = in.readString();
        this.createdAt = in.readString();
        this.deletedAt = in.readString();
        this.salesId = in.readInt();
        this.statusId = in.readString();
        this.closeImplementationDate = in.readString();
        this.dealEnded = in.readString();
        this.name = in.readString();
        this.wonDate = in.readString();
        this.dealDate = in.readString();
        this.id = in.readString();
        this.openDate = in.readString();
        this.updatedAt = in.readString();
        this.cif = in.readString();
        this.productId = in.readString();
        this.offeringType = in.readString();
        this.estTrade = in.readInt();
        this.estOutstanding = in.readInt();
        this.estCash = in.readInt();
        this.estAvg = in.readInt();
        this.groupBuc = in.readString();
        this.action = in.readString();
        this.comment = in.readString();
        this.productType = in.readString();
        this.cycleDeal = in.readString();
        this.status = in.readParcelable(Status.class.getClassLoader());
        this.schedule = in.readParcelable(Schedule.class.getClassLoader());
    }

    public static final Creator<Pipeline> CREATOR = new Creator<Pipeline>() {
        public Pipeline createFromParcel(Parcel source) {
            return new Pipeline(source);
        }

        public Pipeline[] newArray(int size) {
            return new Pipeline[size];
        }
    };
}