package com.mandiri.salestools.model;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;

/**
 * Created by deni on 01/06/2015.
 */
public class ErrorMessage implements Parcelable {

	private String name;
	private String message;
	private Details details;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Details getDetails() {
		return details;
	}

	public void setDetails(Details details) {
		this.details = details;
	}

	public boolean isNotError() {
		return TextUtils.isEmpty(name) && TextUtils.isEmpty(message);
	}

	public class Details implements Parcelable {

		private String message;
		private String type;
		private String path;
		private String value;

		public String getMessage() {
			return message;
		}

		public void setMessage(String message) {
			this.message = message;
		}

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public String getPath() {
			return path;
		}

		public void setPath(String path) {
			this.path = path;
		}

		public String getValue() {
			return value;
		}

		public void setValue(String value) {
			this.value = value;
		}


		@Override
		public int describeContents() {
			return 0;
		}

		@Override
		public void writeToParcel(Parcel dest, int flags) {
			dest.writeString(this.message);
			dest.writeString(this.type);
			dest.writeString(this.path);
			dest.writeString(this.value);
		}

		public Details() {
		}

		private Details(Parcel in) {
			this.message = in.readString();
			this.type = in.readString();
			this.path = in.readString();
			this.value = in.readString();
		}

		public final Creator<Details> CREATOR = new Creator<Details>() {
			public Details createFromParcel(Parcel source) {
				return new Details(source);
			}

			public Details[] newArray(int size) {
				return new Details[size];
			}
		};
	}


	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(this.name);
		dest.writeString(this.message);
		dest.writeParcelable(this.details, flags);
	}

	public ErrorMessage() {
	}

	private ErrorMessage(Parcel in) {
		this.name = in.readString();
		this.message = in.readString();
		this.details = in.readParcelable(Details.class.getClassLoader());
	}

	public static final Creator<ErrorMessage> CREATOR = new Creator<ErrorMessage>() {
		public ErrorMessage createFromParcel(Parcel source) {
			return new ErrorMessage(source);
		}

		public ErrorMessage[] newArray(int size) {
			return new ErrorMessage[size];
		}
	};
}
