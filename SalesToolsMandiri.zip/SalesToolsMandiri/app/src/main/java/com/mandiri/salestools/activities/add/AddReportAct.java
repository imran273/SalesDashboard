package com.mandiri.salestools.activities.add;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.balysv.materialmenu.MaterialMenuDrawable;
import com.mandiri.salestools.R;
import com.mandiri.salestools.adapter.BaseListAdapter;
import com.mandiri.salestools.apiservice.PipelineApiService;
import com.mandiri.salestools.apiservice.RealizationApiService;
import com.mandiri.salestools.apiservice.ReportApiService;
import com.mandiri.salestools.apiservice.StatusApiService;
import com.mandiri.salestools.fragments.BaseFragment;
import com.mandiri.salestools.fragments.dialog.ProgressDialogFragment;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.pipeline.Pipeline;
import com.mandiri.salestools.model.realization.Realization;
import com.mandiri.salestools.model.report.Report;
import com.mandiri.salestools.model.status.Status;
import com.mandiri.salestools.utils.CommonUtils;

import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class AddReportAct extends BaseInputAct {


	@InjectView(R.id.toolbar) Toolbar mToolbar;
	@InjectView(R.id.inpActivity) EditText inpActivity;
	@InjectView(R.id.inpDescription) EditText inpDescription;
	@InjectView(R.id.spinnerRealization) Spinner spinerRealization;
	@InjectView(R.id.spinnerOffering) Spinner spinerPipeline;
	@InjectView(R.id.spinnerStatus) Spinner spinerStatus;
//	@InjectView(R.id.inpActionPlan) EditText inpActionPlan;

	private ReportApiService mReportApiService;

	private List<Status> mListDataStatus;
	private List<Pipeline> mListDataPipeline;
	private List<Realization> mListDataRealization;

	private StatusAdapter mStatusAdapter;
	private PipelineAdapter mPipelineAdapter;
	private RealizationAdapter mRealizationAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add_report);
		ButterKnife.inject(this);

		setupToolbar(mToolbar);
		materialMenuIcon.setState(MaterialMenuDrawable.IconState.ARROW);

		setupUI();
	}

	private void setupUI() {
//        RippleDrawable.createRipple(btnSubmit, getResources().getColor(R.color.ripple));

		spinerStatus.setAdapter(mStatusAdapter = new StatusAdapter(mContext));

		StatusApiService statusApiService = new StatusApiService(mContext);
		statusApiService.loadStatus(new EventCallback<List<Status>>() {
			@Override
			public void onEvent(List<Status> statuses, Bundle bundle) {
				mListDataStatus = statuses;
				mStatusAdapter.pushData(statuses);
			}
		});

		spinerPipeline.setAdapter(mPipelineAdapter = new PipelineAdapter(mContext));

		PipelineApiService pipelineApiService = new PipelineApiService(mContext);
		pipelineApiService.loadPiplines(new EventCallback<List<Pipeline>>() {
			@Override
			public void onEvent(List<Pipeline> pipelines, Bundle bundle) {
				mListDataPipeline = pipelines;
				mPipelineAdapter.pushData(pipelines);
			}
		});

		spinerRealization.setAdapter(mRealizationAdapter = new RealizationAdapter(mContext));

		RealizationApiService realizationApiService = new RealizationApiService(mContext);
		realizationApiService.loadRealizations(new EventCallback<List<Realization>>() {
			@Override
			public void onEvent(List<Realization> realizations, Bundle bundle) {
				mListDataRealization = realizations;
				mRealizationAdapter.pushData(realizations);
			}
		});

	}

	private class StatusAdapter extends BaseListAdapter<Status> {

		public StatusAdapter(Context context) {
			super(context);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			return getView(false, position, convertView, parent);
		}

		@Override
		public View getDropDownView(int position, View convertView, ViewGroup parent) {
			return getView(true, position, convertView, parent);
		}

		private View getView(boolean isDropDown, int position, View convertView, ViewGroup parent) {

			if (convertView == null)
				convertView = mInflater.inflate(isDropDown ? android.R.layout.simple_spinner_dropdown_item
						: android.R.layout.simple_spinner_item, parent, false);

			TextView textView = (TextView) convertView;
			textView.setText(mListData.get(position).getName());

			return convertView;
		}
	}

	private class PipelineAdapter extends BaseListAdapter<Pipeline> {

		public PipelineAdapter(Context context) {
			super(context);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			return getView(false, position, convertView, parent);
		}

		@Override
		public View getDropDownView(int position, View convertView, ViewGroup parent) {
			return getView(true, position, convertView, parent);
		}

		private View getView(boolean isDropDown, int position, View convertView, ViewGroup parent) {

			if (convertView == null)
				convertView = mInflater.inflate(isDropDown ? android.R.layout.simple_spinner_dropdown_item
						: android.R.layout.simple_spinner_item, parent, false);

			TextView textView = (TextView) convertView;
			textView.setText(mListData.get(position).getName());

			return convertView;
		}
	}

	private class RealizationAdapter extends BaseListAdapter<Realization> {

		public RealizationAdapter(Context context) {
			super(context);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			return getView(false, position, convertView, parent);
		}

		@Override
		public View getDropDownView(int position, View convertView, ViewGroup parent) {
			return getView(true, position, convertView, parent);
		}

		private View getView(boolean isDropDown, int position, View convertView, ViewGroup parent) {

			if (convertView == null)
				convertView = mInflater.inflate(isDropDown ? android.R.layout.simple_spinner_dropdown_item
						: android.R.layout.simple_spinner_item, parent, false);

			TextView textView = (TextView) convertView;
			textView.setText(mListData.get(position).getDescription());

			return convertView;
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.menu_submit, menu);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case R.id.menu_add:
				validatePost();
				break;
		}
		return super.onOptionsItemSelected(item);
	}

	private void validatePost() {
//		String actionPlan = inpActionPlan.getText().toString();
		String activity = inpActivity.getText().toString();
		String description = inpDescription.getText().toString();

		CommonUtils.hideKeyboard(getCurrentFocus());

		boolean isValid = true;
//		if (TextUtils.isEmpty(actionPlan.trim())) {
//			inpActionPlan.requestFocus();
//			inpActionPlan.setError("Action Plan must not be empty ");
//			isValid = false;
//		}
		if (TextUtils.isEmpty(activity.trim())) {
			inpActivity.requestFocus();
			inpActivity.setError("Activity must not be empty ");
			isValid = false;
		}
		if (TextUtils.isEmpty(description.trim())) {
			inpDescription.requestFocus();
			inpDescription.setError("Description must not be empty ");
			isValid = false;
		}

		if (!isValid)
			return;

		Report report = new Report();
//		report.setActionPlan(actionPlan);
//		report.setActivity(activity);
//		report.setDescription(description);
//		report.setRealizationId(mListDataRealization.get(spinerRealization.getSelectedItemPosition()).getId());
//		report.setOfferingId(mListDataPipeline.get(spinerPipeline.getSelectedItemPosition()).getId());
//		report.setUserId(mListDataStatus.get(spinerStatus.getSelectedItemPosition()).getId());

		doAddReport(report);
	}

	private void doAddReport(Report report) {

		if (mReportApiService == null)
			mReportApiService = new ReportApiService(mContext);

		final ProgressDialogFragment progressDialogFragment = ProgressDialogFragment.newInstance("Please wait..");
		progressDialogFragment.show(getSupportFragmentManager(), ProgressDialogFragment.TAG);

		mReportApiService.doAddReport(report, new EventCallback<Report>() {
			@Override
			public void onEvent(Report data, Bundle bundle) {
				progressDialogFragment.dismiss();
				if (data != null) {
					Toast.makeText(mContext, "success", Toast.LENGTH_SHORT).show();
				} else {
					Toast.makeText(mContext, "failed", Toast.LENGTH_SHORT).show();
				}
			}
		});
	}

	/* ---------- LAUNCHER ------------ */
	public static void startForResult(BaseFragment baseFragment) {
		baseFragment.startActivityForResult(new Intent(baseFragment.getActivity(), AddReportAct
				.class), BaseInputAct.BASE_INPUT_CODE);
	}
}
