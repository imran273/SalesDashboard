/*
 * Copyright (c) 2015. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.
 * Vestibulum commodo. Ut rhoncus gravida arcu.
 */

package com.mandiri.salestools.model.realization;

import android.os.Parcel;

import com.mandiri.salestools.model.BaseDao;

import java.util.List;

/**
 * Created by deni on 04/06/15
 */
public class RealizationDao extends BaseDao {

	private List<Realization> realizations;

    public List<Realization> getRealizations() {
        return realizations;
    }

    public void setRealizations(List<Realization> realizations) {
        this.realizations = realizations;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeTypedList(realizations);
    }

    public RealizationDao() {
    }

    protected RealizationDao(Parcel in) {
        this.realizations = in.createTypedArrayList(Realization.CREATOR);
    }

    public static final Creator<RealizationDao> CREATOR = new Creator<RealizationDao>() {
        public RealizationDao createFromParcel(Parcel source) {
            return new RealizationDao(source);
        }

        public RealizationDao[] newArray(int size) {
            return new RealizationDao[size];
        }
    };
}
