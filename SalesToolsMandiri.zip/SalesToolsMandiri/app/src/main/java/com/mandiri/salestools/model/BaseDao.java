package com.mandiri.salestools.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by deni on 01/06/2015.
 */
public class BaseDao implements Parcelable {

	private int count;
	private ErrorMessage error;

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public ErrorMessage getError() {
		return error;
	}

	public void setError(ErrorMessage error) {
		this.error = error;
	}

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeInt(this.count);
		dest.writeParcelable(this.error, 0);
	}

	public BaseDao() {
	}

	private BaseDao(Parcel in) {
		this.count = in.readInt();
		this.error = in.readParcelable(ErrorMessage.class.getClassLoader());
	}


	public static final Creator<BaseDao> CREATOR = new Creator<BaseDao>() {
		@Override
		public BaseDao createFromParcel(Parcel in) {
			return new BaseDao(in);
		}

		@Override
		public BaseDao[] newArray(int size) {
			return new BaseDao[size];
		}
	};
}
