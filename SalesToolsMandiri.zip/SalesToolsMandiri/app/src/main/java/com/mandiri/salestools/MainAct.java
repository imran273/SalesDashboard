package com.mandiri.salestools;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.balysv.materialmenu.MaterialMenuDrawable;
import com.mandiri.salestools.fragments.BaseFragment;
import com.mandiri.salestools.fragments.ClientListFragment;
import com.mandiri.salestools.fragments.DepartementListFragment;
import com.mandiri.salestools.fragments.DivisionListFragment;
import com.mandiri.salestools.fragments.PipelineListFragment;
import com.mandiri.salestools.fragments.ProductListFragment;
import com.mandiri.salestools.fragments.SalesCycleListFragment;
import com.mandiri.salestools.fragments.SalesListFragment;
import com.mandiri.salestools.fragments.ScheduleFragment;
import com.mandiri.salestools.fragments.UserListFragment;
import com.mandiri.salestools.fragments.dashboard.DashboardFragment;
import com.mandiri.salestools.utils.CommonUtils;
import com.mandiri.salestools.utils.Preferences;
import com.mandiri.salestools.widget.RippleDrawable;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

@Deprecated
public class MainAct extends BaseActivity implements NavigationView.OnNavigationItemSelectedListener {

	@InjectView(R.id.toolbar) Toolbar mToolbar;
	@InjectView(R.id.drawerLayout) DrawerLayout drawerLayout;
	@InjectView(R.id.navigationView) NavigationView navigationView;
	@InjectView(R.id.bgContent) ImageView bgContent;
	@InjectView(R.id.txtFullName) TextView txtFullName;
	@InjectView(R.id.txtEmail) TextView txtEmail;

	private BaseFragment mCurrentFragment;
	private FragmentManager fragmentManager;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		ButterKnife.inject(this);

		setupToolbar();
		materialMenuIcon.setState(drawerLayout.isDrawerOpen(GravityCompat.START) ?
				MaterialMenuDrawable.IconState.ARROW : MaterialMenuDrawable.IconState.BURGER);

		mCurrentFragment = DashboardFragment.newInstance();
		fragmentManager = getSupportFragmentManager();
		fragmentManager.beginTransaction()
				.replace(R.id.content, mCurrentFragment)
				.commit();

		RippleDrawable.createRipple(bgContent, getResources().getColor(R.color.ripple_material_dark));
		setupDrawerContent(navigationView);

		setupHeaderView();
	}

	private void setupToolbar() {
		setupToolbar(mToolbar, new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				if (drawerLayout.isDrawerOpen(GravityCompat.START))
					drawerLayout.closeDrawers();
				else {
					drawerLayout.openDrawer(navigationView);
				}
			}
		});
	}

	private void setupDrawerContent(NavigationView navigationView) {
		navigationView.setNavigationItemSelectedListener(this);
	}

	@Override
	public boolean onNavigationItemSelected(MenuItem menuItem) {
		int id = menuItem.getItemId();
		if (id == R.id.drawer_dashboard) {
			mCurrentFragment = DashboardFragment.newInstance();
		} else if (id == R.id.drawer_sh_summary) {
			mCurrentFragment = ScheduleFragment.newInstance();
		} else if (id == R.id.drawer_sales_summary) {
			mCurrentFragment = SalesListFragment.newInstance();
		} else if (id == R.id.drawer_clients) {
			mCurrentFragment = ClientListFragment.newInstance();
		} else if (id == R.id.drawer_pipelines) {
			mCurrentFragment = PipelineListFragment.newInstance();
		} else if (id == R.id.drawer_products) {
			mCurrentFragment = ProductListFragment.newInstance();
//				}else  if(id == R.id.drawer_appointment){
//					mCurrentFragment = ClientListFragment.newInstance();
//				}else  if(id == R.id.drawer_call_report){
//					mCurrentFragment = ClientListFragment.newInstance();
		} else if (id == R.id.drawer_users) {
			mCurrentFragment = UserListFragment.newInstance();
			//master settings change to activity
		} else if (id == R.id.drawer_division) {
			mCurrentFragment = DivisionListFragment.newInstance();
		} else if (id == R.id.drawer_departements) {
			mCurrentFragment = DepartementListFragment.newInstance();
//				}else  if(id == R.id.drawer_status){
//					mCurrentFragment = ClientListFragment.newInstance();
		} else if (id == R.id.drawer_sales_cycle) {
			mCurrentFragment = SalesCycleListFragment.newInstance();
		} else {
			CommonUtils.toastShort(mContext, menuItem.getTitle());
			return true;
		}
		navigateToFragment(mCurrentFragment);

		menuItem.setChecked(true);
		drawerLayout.closeDrawers();
		return false;
	}

	private void navigateToFragment(BaseFragment baseFragment) {
		fragmentManager = getSupportFragmentManager();
		fragmentManager.beginTransaction()
				.replace(R.id.content, baseFragment)
				.commit();
	}

	private void setupHeaderView() {
		txtFullName.setText(Preferences.getName(mContext));
		txtEmail.setText(Preferences.getEmail(mContext));
	}

	@OnClick(R.id.bgContent)
	public void onHeaderDrawerClick() {
		ProfileAct.start(mContext);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.menu_main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case android.R.id.home:
				drawerLayout.openDrawer(GravityCompat.START);
				return true;
			case R.id.action_logout:
				Preferences.clear(mContext);
				LoginAct.start(mContext);
				finish();
				return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/* -------- Initiator ------------- */

	public static void start(Context context) {
		Intent intent = new Intent(context, MainAct.class);
		context.startActivity(intent);
	}
}
