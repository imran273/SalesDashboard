package com.mandiri.salestools.utils;

import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

/**
 * Created by esa on 10/06/15, with awesomeness
 */
public class StringValueUtils {

	public static String getValue(TextView textView) {
		if (textView == null)
			throw new IllegalStateException("View must not be empty");
		return textView.getText().toString().trim();
	}

	public static String getValue(EditText editText) {
		if (editText == null)
			throw new IllegalStateException("View must not be empty");
		return editText.getText().toString().trim();
	}

	public static String getValue(Spinner spinner) {
		if (spinner == null)
			throw new IllegalStateException("View must not be empty");
		if (spinner.getSelectedItem() == null)
			throw new IllegalStateException("Spinner must be selected");
		return String.valueOf(spinner.getSelectedItem());
	}
}
