/*
 * Copyright (c) 2015. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.
 * Vestibulum commodo. Ut rhoncus gravida arcu.
 */

package com.mandiri.salestools.model.salescycle;

import android.os.Parcel;
import android.os.Parcelable;

import com.mandiri.salestools.model.BaseDao;

/**
 * Created by deni on 01/06/15.
 */
public class SalesCycle extends BaseDao implements Parcelable {

    /**
     * createdAt : 2015-06-08T19:07:19.000Z
     * deletedAt : null
     * statusId : 1
     * complex : 1
     * simple : 1
     * id : 1
     * medium : 1
     * departementId : 2
     * updatedAt : 2015-06-08T19:07:19.000Z
     */
    private String createdAt;
    private String deletedAt;
    private int statusId;
    private int complex;
    private int simple;
    private int id;
    private int medium;
    private int departementId;
    private String updatedAt;

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public void setDeletedAt(String deletedAt) {
        this.deletedAt = deletedAt;
    }

    public void setStatusId(int statusId) {
        this.statusId = statusId;
    }

    public void setComplex(int complex) {
        this.complex = complex;
    }

    public void setSimple(int simple) {
        this.simple = simple;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setMedium(int medium) {
        this.medium = medium;
    }

    public void setDepartementId(int departementId) {
        this.departementId = departementId;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public String getDeletedAt() {
        return deletedAt;
    }

    public int getStatusId() {
        return statusId;
    }

    public int getComplex() {
        return complex;
    }

    public int getSimple() {
        return simple;
    }

    public int getId() {
        return id;
    }

    public int getMedium() {
        return medium;
    }

    public int getDepartementId() {
        return departementId;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeString(this.createdAt);
        dest.writeString(this.deletedAt);
        dest.writeInt(this.statusId);
        dest.writeInt(this.complex);
        dest.writeInt(this.simple);
        dest.writeInt(this.id);
        dest.writeInt(this.medium);
        dest.writeInt(this.departementId);
        dest.writeString(this.updatedAt);
    }

    public SalesCycle() {
    }

    protected SalesCycle(Parcel in) {
        this.createdAt = in.readString();
        this.deletedAt = in.readString();
        this.statusId = in.readInt();
        this.complex = in.readInt();
        this.simple = in.readInt();
        this.id = in.readInt();
        this.medium = in.readInt();
        this.departementId = in.readInt();
        this.updatedAt = in.readString();
    }

    public static final Creator<SalesCycle> CREATOR = new Creator<SalesCycle>() {
        public SalesCycle createFromParcel(Parcel source) {
            return new SalesCycle(source);
        }

        public SalesCycle[] newArray(int size) {
            return new SalesCycle[size];
        }
    };
}
