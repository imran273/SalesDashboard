package com.mandiri.salestools.model.realization;

import android.os.Parcel;
import android.os.Parcelable;

public class Realization implements Parcelable {

    /**
     * date : 2015-06-04T08:20:29.000Z
     * teamClient : Sylvert, Devid, Huda
     * createdAt : 2015-06-09T16:44:14.000Z
     * teamMandiri : Deni Rohimat, Esa Firman, Muhammad Imran
     * deletedAt : null
     * lng : 106.774124
     * description : meeting timeline project
     * location : North Jakarta, North Jakarta City, Jakarta, Indonesia
     * id : 1
     * lat : -6.121435
     * scheduleId : 1
     * updatedAt : 2015-06-09T16:44:14.000Z
     */
    private String date;
    private String teamClient;
    private String createdAt;
    private String teamMandiri;
    private String deletedAt;
    private double lng;
    private String description;
    private String location;
    private String id;
    private double lat;
    private String scheduleId;
    private String updatedAt;
    private boolean flagUpdateCycle;
    //for add only
    private String salesId;

    public void setDate(String date) {
        this.date = date;
    }

    public void setTeamClient(String teamClient) {
        this.teamClient = teamClient;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public void setTeamMandiri(String teamMandiri) {
        this.teamMandiri = teamMandiri;
    }

    public void setDeletedAt(String deletedAt) {
        this.deletedAt = deletedAt;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public void setScheduleId(String scheduleId) {
        this.scheduleId = scheduleId;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getDate() {
        return date;
    }

    public String getTeamClient() {
        return teamClient;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public String getTeamMandiri() {
        return teamMandiri;
    }

    public String getDeletedAt() {
        return deletedAt;
    }

    public double getLng() {
        return lng;
    }

    public String getDescription() {
        return description;
    }

    public String getLocation() {
        return location;
    }

    public String getId() {
        return id;
    }

    public double getLat() {
        return lat;
    }

    public String getScheduleId() {
        return scheduleId;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public String getSalesId() {
        return salesId;
    }

    public void setSalesId(String salesId) {
        this.salesId = salesId;
    }

    public boolean isFlagUpdateCycle() {
        return flagUpdateCycle;
    }

    public void setFlagUpdateCycle(boolean flagUpdateCycle) {
        this.flagUpdateCycle = flagUpdateCycle;
    }

    public Realization() {
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.date);
        dest.writeString(this.teamClient);
        dest.writeString(this.createdAt);
        dest.writeString(this.teamMandiri);
        dest.writeString(this.deletedAt);
        dest.writeDouble(this.lng);
        dest.writeString(this.description);
        dest.writeString(this.location);
        dest.writeString(this.id);
        dest.writeDouble(this.lat);
        dest.writeString(this.scheduleId);
        dest.writeString(this.updatedAt);
        dest.writeByte(flagUpdateCycle ? (byte) 1 : (byte) 0);
        dest.writeString(this.salesId);
    }

    protected Realization(Parcel in) {
        this.date = in.readString();
        this.teamClient = in.readString();
        this.createdAt = in.readString();
        this.teamMandiri = in.readString();
        this.deletedAt = in.readString();
        this.lng = in.readDouble();
        this.description = in.readString();
        this.location = in.readString();
        this.id = in.readString();
        this.lat = in.readDouble();
        this.scheduleId = in.readString();
        this.updatedAt = in.readString();
        this.flagUpdateCycle = in.readByte() != 0;
        this.salesId = in.readString();
    }

    public static final Creator<Realization> CREATOR = new Creator<Realization>() {
        public Realization createFromParcel(Parcel source) {
            return new Realization(source);
        }

        public Realization[] newArray(int size) {
            return new Realization[size];
        }
    };
}