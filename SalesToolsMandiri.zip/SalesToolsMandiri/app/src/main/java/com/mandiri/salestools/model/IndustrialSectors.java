package com.mandiri.salestools.model;

import java.util.List;

/**
 * Created by esa on 16/08/15, with awesomeness
 */
public class IndustrialSectors extends BaseDao {

	private List<IndustrialSector> industrialSectors;

	public void setIndustrialSectors(List<IndustrialSector> industrialSectors) {
		this.industrialSectors = industrialSectors;
	}

	public List<IndustrialSector> getIndustrialSectors() {
		return industrialSectors;
	}

	public static class IndustrialSector {
		/**
		 * createdAt : 2015-08-14T15:26:15.000Z
		 * deletedAt : null
		 * name : Makanan & Minuman
		 * id : 1
		 * updatedAt : 2015-08-14T15:26:15.000Z
		 */
		private String createdAt;
		private String deletedAt;
		private String name;
		private int id;
		private String updatedAt;

		public void setCreatedAt(String createdAt) {
			this.createdAt = createdAt;
		}

		public void setDeletedAt(String deletedAt) {
			this.deletedAt = deletedAt;
		}

		public void setName(String name) {
			this.name = name;
		}

		public void setId(int id) {
			this.id = id;
		}

		public void setUpdatedAt(String updatedAt) {
			this.updatedAt = updatedAt;
		}

		public String getCreatedAt() {
			return createdAt;
		}

		public String getDeletedAt() {
			return deletedAt;
		}

		public String getName() {
			return name;
		}

		public int getId() {
			return id;
		}

		public String getUpdatedAt() {
			return updatedAt;
		}
	}
}
