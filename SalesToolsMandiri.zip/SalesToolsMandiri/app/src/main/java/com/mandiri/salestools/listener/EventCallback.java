package com.mandiri.salestools.listener;

import android.os.Bundle;

/**
 * Created by esa on 26/04/15, with awesomeness
 */
public abstract class EventCallback<T> {

	public abstract void onEvent(T t, Bundle bundle);

	public void onEvent(T t) {
		onEvent(t, null);
	}
}
