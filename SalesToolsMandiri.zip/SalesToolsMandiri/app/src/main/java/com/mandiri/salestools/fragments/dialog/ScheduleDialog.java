package com.mandiri.salestools.fragments.dialog;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.maps.MapFragment;
import com.mandiri.salestools.R;
import com.mandiri.salestools.activities.add.AddRealizationAct;
import com.mandiri.salestools.apiservice.SchedulesApiService;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.schedule.Schedule;
import com.mandiri.salestools.utils.CommonUtils;

import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

/**
 * Created by esa on 05/06/15, with awesomeness
 */
public class ScheduleDialog extends BaseDialogFragment {

	@InjectView(R.id.txtCaption) TextView mTxtCaption;
	@InjectView(R.id.txtTitle) TextView mTxtTitle;
	@InjectView(R.id.txtStatus) TextView mTxtStatus;
	@InjectView(R.id.inpTeam) TextView mInpTeam;
	@InjectView(R.id.inpTeamClient) TextView mInpTeamClient;
	@InjectView(R.id.inpPic) TextView mInpPic;
	@InjectView(R.id.inpContent) TextView mTxtDescription;
	@InjectView(R.id.btnSubmit) TextView mTxtLocation;
	@InjectView(R.id.btnAddRealization) Button mBtnAddRealization;

	private Schedule mSchedule;

	@NonNull
	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {
		Dialog dialog = new Dialog(mContext);
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setContentView(getContentView());
		dialog.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager
				.LayoutParams.WRAP_CONTENT);
		return dialog;
	}

	@SuppressLint("InflateParams")
	private View getContentView() {
		View view = mInflater.inflate(R.layout.activity_schedule_detail, null);
		ButterKnife.inject(this, view);
		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		mSchedule = getArguments().getParcelable(Schedule.class.getSimpleName());
		setupUI();

		SchedulesApiService apiService = new SchedulesApiService(mContext);
		apiService.loadSchedulesFull(mSchedule.getId(), new EventCallback<List<Schedule>>() {
			@Override
			public void onEvent(List<Schedule> schedules, Bundle bundle) {
				if (schedules == null) {
					CommonUtils.toastShort(mContext, R.string.error_string);
					return;
				}
				mSchedule = schedules.get(0);
				setupUI();
			}
		});
	}

	private void setupUI() {

		mTxtCaption.setText(mSchedule.getPlan());
		mInpPic.setText(mSchedule.getPic());
		mInpTeam.setText(mSchedule.getTeamMandiri());
		mInpTeamClient.setText(mSchedule.getTeamClient());
		mTxtLocation.setText(mSchedule.getLocation());
		mTxtDescription.setText(mSchedule.getDescription());

		if (mSchedule.getPipeline() != null) {
			mTxtStatus.setText(String.valueOf(mSchedule.getPipeline().getStatusId()));
			mTxtTitle.setText(mSchedule.getPipeline().getName());
		}
	}

	@OnClick(R.id.btnAddRealization)
	public void onAddRealizationClick() {
		AddRealizationAct.startForResult(this, mSchedule);
	}

	@Override
	public void onDestroyView() {
		super.onDestroyView();
		ButterKnife.reset(this);
	}

	/* ------- LAUNCHER ----------- */

	public static void show(FragmentManager fragmentManager, Schedule schedule) {
		Bundle bundle = new Bundle();
		bundle.putParcelable(Schedule.class.getSimpleName(), schedule);
		ScheduleDialog scheduleDialog = new ScheduleDialog();
		scheduleDialog.setArguments(bundle);

		FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
		fragmentTransaction.add(scheduleDialog, AddScheduleDialog.class.getSimpleName());
		fragmentTransaction.commitAllowingStateLoss();
	}
}
