package com.mandiri.salestools.fragments.dashboard;

import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mandiri.salestools.MainSalesAct;
import com.mandiri.salestools.R;
import com.mandiri.salestools.apiservice.SalesApiService;
import com.mandiri.salestools.fragments.BaseFragment;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.sales.SalesStatistic;
import com.mandiri.salestools.utils.CommonUtils;
import com.mandiri.salestools.widget.RippleDrawable;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

public class DashboardFragment extends BaseFragment {

    @InjectView(R.id.countCorporatePipeline)    TextView countCorporatePipeline;
    @InjectView(R.id.lyCorporate)    RelativeLayout lyCorporate;
    @InjectView(R.id.countSchedule)    TextView countSchedule;
    @InjectView(R.id.lySchedule)    RelativeLayout lySchedule;
    @InjectView(R.id.countNotification)    TextView countNotification;
    @InjectView(R.id.lyNotification)    RelativeLayout lyNotification;
    @InjectView(R.id.countTotalNewPipeline)    TextView countTotalNewPipeline;
    @InjectView(R.id.lyTotalNew)    RelativeLayout lyTotalNew;
    @InjectView(R.id.lyRefresh)    SwipeRefreshLayout mSwipeRefreshLayout;

    private SalesApiService mApiService;

    public static DashboardFragment newInstance() {
        return new DashboardFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        setHasOptionsMenu(true);
        super.onCreate(savedInstanceState);
        getActionBar().setTitle(R.string.dashboard);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_dashboard, container, false);
        ButterKnife.inject(this, rootView);
        setupUI();
        return rootView;
    }

    private void setupUI() {
        mSwipeRefreshLayout.setColorSchemeResources(R.color.primary);
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                loadData();
            }
        });

        RippleDrawable.createRipple(lyCorporate, getResources().getColor(R.color.grey));
        RippleDrawable.createRipple(lySchedule, getResources().getColor(R.color.grey));
        RippleDrawable.createRipple(lyNotification, getResources().getColor(R.color.grey));
        RippleDrawable.createRipple(lyTotalNew, getResources().getColor(R.color.grey));

        loadData();
    }

    @OnClick(R.id.lyCorporate)
    public void onClickDepartement() {
        MainSalesAct mainSalesAct = (MainSalesAct) getBaseActivity();
        mainSalesAct.setupFragment(MainSalesAct.TYPE_PIPELINE);
    }

    @OnClick(R.id.lySchedule)
    public void onClickSchedule() {
        MainSalesAct mainSalesAct = (MainSalesAct) getBaseActivity();
        mainSalesAct.setupFragment(MainSalesAct.TYPE_SCHEDULE);
    }

    private void loadData() {
        if (mApiService == null)
            mApiService = new SalesApiService(mContext);

        mSwipeRefreshLayout.setRefreshing(true);
        mApiService.loadSalesStatistic(new EventCallback<SalesStatistic>() {
            @Override
            public void onEvent(SalesStatistic data, Bundle bundle) {
                mSwipeRefreshLayout.setRefreshing(false);
                if (data == null) {
                    CommonUtils.toastShort(mContext, R.string.error_string);
                    return;
                }

                countCorporatePipeline.setText(String.valueOf(data.getTotal()));
                countSchedule.setText(String.valueOf(data.getWoRealization()));
                countNotification.setText(String.valueOf(data.getOnTrack()));
                countTotalNewPipeline.setText(String.valueOf(data.getMissed()));
            }
        });

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.reset(this);
    }
}