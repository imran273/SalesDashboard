/*
 * Copyright (c) 2015. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.
 * Vestibulum commodo. Ut rhoncus gravida arcu.
 */

package com.mandiri.salestools.model.action;

import android.os.Parcel;

import com.mandiri.salestools.model.BaseDao;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by esa on 04/06/15, with awesomeness
 */
public class ActionsResponse extends BaseDao {

	private List<Action> offeringActions;

	public void setOfferingActions(List<Action> offeringActions) {
		this.offeringActions = offeringActions;
	}

	public List<Action> getPipelines() {
		return offeringActions;
	}

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		super.writeToParcel(dest, flags);
		dest.writeList(this.offeringActions);
	}

	public ActionsResponse() {
	}

	protected ActionsResponse(Parcel in) {
		this.offeringActions = new ArrayList<>();
		in.readList(this.offeringActions, List.class.getClassLoader());
	}

	public static final Creator<ActionsResponse> CREATOR = new Creator<ActionsResponse>() {
		public ActionsResponse createFromParcel(Parcel source) {
			return new ActionsResponse(source);
		}

		public ActionsResponse[] newArray(int size) {
			return new ActionsResponse[size];
		}
	};
}
