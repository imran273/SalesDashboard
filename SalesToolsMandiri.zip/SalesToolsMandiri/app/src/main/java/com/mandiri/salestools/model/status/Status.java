package com.mandiri.salestools.model.status;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by esa on 05/06/15, with awesomeness
 */
public class Status implements Parcelable {

	/**
	 * createdAt : 2015-06-08T19:07:19.000Z
	 * deletedAt : null
	 * name : Opportunity gathering
	 * id : 1
	 * updatedAt : 2015-06-08T19:07:19.000Z
	 */
	private String createdAt;
	private String deletedAt;
	private String name;
	private String id;
	private String updatedAt;

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public void setDeletedAt(String deletedAt) {
		this.deletedAt = deletedAt;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public String getDeletedAt() {
		return deletedAt;
	}

	public String getName() {
		return name;
	}

	public String getId() {
		return id;
	}

	public String getUpdatedAt() {
		return updatedAt;
	}

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(this.createdAt);
		dest.writeString(this.deletedAt);
		dest.writeString(this.name);
		dest.writeString(this.id);
		dest.writeString(this.updatedAt);
	}

	public Status() {
	}

	protected Status(Parcel in) {
		this.createdAt = in.readString();
		this.deletedAt = in.readString();
		this.name = in.readString();
		this.id = in.readString();
		this.updatedAt = in.readString();
	}

	public static final Creator<Status> CREATOR = new Creator<Status>() {
		public Status createFromParcel(Parcel source) {
			return new Status(source);
		}

		public Status[] newArray(int size) {
			return new Status[size];
		}
	};
}
