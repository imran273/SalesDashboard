package com.mandiri.salestools.constants;

/**
 * Created by esa on 09/06/15, with awesomeness
 */
public class ApiCons {

	public static final String STATUS_CODE = "ApiCons.StatusCode";
}
