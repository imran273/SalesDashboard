package com.mandiri.salestools.model.status;

import android.os.Parcel;

import com.mandiri.salestools.model.BaseDao;

import java.util.List;

/**
 * Created by deni on 09/06/15
 */
public class StatusDao extends BaseDao {

	private List<Status> status;

    public List<Status> getStatus() {
        return status;
    }

    public void setStatus(List<Status> status) {
        this.status = status;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeTypedList(status);
    }

    public StatusDao() {
    }

    protected StatusDao(Parcel in) {
        this.status = in.createTypedArrayList(Status.CREATOR);
    }

    public static final Creator<StatusDao> CREATOR = new Creator<StatusDao>() {
        public StatusDao createFromParcel(Parcel source) {
            return new StatusDao(source);
        }

        public StatusDao[] newArray(int size) {
            return new StatusDao[size];
        }
    };
}
