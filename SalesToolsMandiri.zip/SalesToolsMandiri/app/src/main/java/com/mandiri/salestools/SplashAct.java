package com.mandiri.salestools;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Window;

import com.mandiri.salestools.utils.Preferences;

/**
 * Created by esa on 06/04/15, with awesomeness
 */
public class SplashAct extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_splash);

		Handler handler = new Handler(Looper.getMainLooper());
		handler.postDelayed(new Runnable() {
			@Override
			public void run() {
				if (Preferences.accountConfigured(SplashAct.this)){
                    MainSalesAct.start(SplashAct.this);
					finish();
				}else{
					LoginAct.start(SplashAct.this);
					finish();
				}
			}
		}, 1500);
	}
}
