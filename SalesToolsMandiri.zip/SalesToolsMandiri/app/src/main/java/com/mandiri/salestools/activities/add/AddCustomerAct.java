package com.mandiri.salestools.activities.add;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Spinner;

import com.balysv.materialmenu.MaterialMenuDrawable;
import com.mandiri.salestools.R;
import com.mandiri.salestools.adapter.spinner.BUCAdapter;
import com.mandiri.salestools.adapter.spinner.ClientAdapter;
import com.mandiri.salestools.adapter.spinner.IndustrialSectorAdapter;
import com.mandiri.salestools.apiservice.BUCApiService;
import com.mandiri.salestools.apiservice.BUCs;
import com.mandiri.salestools.apiservice.CIFApiService;
import com.mandiri.salestools.apiservice.ClientApiService;
import com.mandiri.salestools.apiservice.IndustrialSectorApiService;
import com.mandiri.salestools.apiservice.PicApiService;
import com.mandiri.salestools.fragments.BaseFragment;
import com.mandiri.salestools.fragments.dialog.ProgressDialogFragment;
import com.mandiri.salestools.listener.EventCallback;
import com.mandiri.salestools.model.CIFs;
import com.mandiri.salestools.model.IndustrialSectors;
import com.mandiri.salestools.model.clients.Client;
import com.mandiri.salestools.model.pic.PIC;
import com.mandiri.salestools.utils.CommonUtils;
import com.mandiri.salestools.utils.SegmentationUtils;
import com.mandiri.salestools.utils.ValidateUtils;
import com.mandiri.salestools.utils.helper.BundleHelper;
import com.mandiri.salestools.widget.CIFInputForm;
import com.mandiri.salestools.widget.PICInputForm;

import java.util.ArrayList;
import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;
import butterknife.OnItemSelected;

/**
 * Created by esa on 09/06/15, with awesomeness
 */
public class AddCustomerAct extends BaseInputAct {

	@InjectView(R.id.toolbar) Toolbar mToolbar;
	@InjectView(R.id.inpTitle) EditText mInpTitle;
	@InjectView(R.id.inpAddress) EditText mInpAddress;
	@InjectView(R.id.inpPhone) EditText mInpPhone;
	@InjectView(R.id.lyBottom) LinearLayout mBottomView;
	@InjectView(R.id.radioGroupMember) RadioGroup mRadioGroup;
	@InjectView(R.id.spnClientName) Spinner mSpnClientGroup;
	@InjectView(R.id.spnIndustrialSector) Spinner mSpnIndustrialSector;
	@InjectView(R.id.spnBUC) Spinner mSpnBUC;
	@InjectView(R.id.spnType) Spinner mSpnSegmentation;

	/* PIC */
	@InjectView(R.id.spnClient) Spinner mSpnPic;

	/* Multiple Entry */
	@InjectView(R.id.lyCIF) LinearLayout mCIFContainer;

	/* Adapter */
	private ClientAdapter mClientAdapter;
	private IndustrialSectorAdapter mSectorAdapter;
	private BUCAdapter mBUCAdapter;

	private ClientApiService mApiService;
	private PicApiService mPiCApiService;
	private BUCApiService mBucApiService;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add_customer);
		ButterKnife.inject(this);

		setupToolbar(mToolbar);
		setTitle(R.string.add_client);
		materialMenuIcon.setState(MaterialMenuDrawable.IconState.ARROW);

		mApiService = new ClientApiService(mContext);
		mPiCApiService = new PicApiService(mContext);

		setupView();
	}

	private void setupView() {
		mSpnPic.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
				mBottomView.setVisibility(i == 0 ? View.GONE : View.VISIBLE);
			}

			@Override
			public void onNothingSelected(AdapterView<?> adapterView) {
			}
		});

		mSpnClientGroup.setAdapter(mClientAdapter = new ClientAdapter(this));
		ClientApiService clientApiService = new ClientApiService(mContext);
		clientApiService.loadClients(new EventCallback<List<Client>>() {
			@Override
			public void onEvent(List<Client> clients, Bundle bundle) {

				List<Client> clientNames = new ArrayList<>();
				for (Client client : clients) {
					if (client.getParentId() != null)
						clientNames.add(client);
				}
				clients.removeAll(clientNames);

				mClientAdapter.pushData(clients);
			}
		});

		mSpnIndustrialSector.setAdapter(mSectorAdapter = new IndustrialSectorAdapter(this));
		IndustrialSectorApiService sectorApiService = new IndustrialSectorApiService(this);
		sectorApiService.loadIndustrialSectors(new EventCallback<IndustrialSectors>() {
			@Override
			public void onEvent(IndustrialSectors industrialSectors, Bundle bundle) {
				if (industrialSectors != null)
					mSectorAdapter.pushData(industrialSectors.getIndustrialSectors());
			}
		});

		mSpnBUC.setAdapter(mBUCAdapter = new BUCAdapter(this));

		addCIFField();
		mRadioGroup.check(R.id.radioGold);
	}

	@OnItemSelected(R.id.spnType)
	public void onSegmetationSelected(int position) {

		String departmentId = SegmentationUtils.getSegmentationID(position);

		if (mBucApiService == null)
			mBucApiService = new BUCApiService(this);

		mBucApiService.loadBUCsForDepartmentID(departmentId, new EventCallback<BUCs>() {
			@Override
			public void onEvent(BUCs buCs, Bundle bundle) {
				if (buCs != null) {
					mBUCAdapter.pushData(buCs.getBusinessUnitCodes());
				}
			}
		});
	}

	@OnClick(R.id.btnAddCIF)
	public void onAddCIFClick() {
		addCIFField();
	}

	@OnClick(R.id.btnAddPIC)
	public void onAddPICClick() {
		addPICField();
	}

	private void addCIFField() {
		CIFInputForm inputForm = new CIFInputForm(mContext);
		inputForm.setTitle(getString(R.string.cif_and_norek) + " #" + (mCIFContainer.getChildCount() + 1));
		inputForm.setHintNumber(String.valueOf(mCIFContainer.getChildCount() + 1));
		inputForm.setListener(new CIFInputForm.CIFInputFormListener() {
			@Override
			public void onDeleteButtonClick(CIFInputForm cifInputForm) {
				mCIFContainer.removeView(cifInputForm);
			}
		});

		if (mCIFContainer.getChildCount() == 0)
			inputForm.setDeleteable(false);

		mCIFContainer.addView(inputForm);
	}

	private void addPICField() {
		PICInputForm inputForm = new PICInputForm(mContext);
		inputForm.setTitle("PIC #" + mBottomView.getChildCount());
		inputForm.setListener(new PICInputForm.PICInputFormListener() {
			@Override
			public void onDeleteButtonClick(PICInputForm picInputForm) {
				mBottomView.removeView(picInputForm);
			}
		});
		mBottomView.addView(inputForm, mBottomView.getChildCount() - 1);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.menu_submit, menu);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case R.id.menu_add:
				if (isValid())
					doSubmitClient();
				break;
		}
		return super.onOptionsItemSelected(item);
	}

	private boolean isValid() {
		boolean isValid;
		isValid = ValidateUtils.runningValidationWithViews(getString(R.string.required), mInpTitle,
				  mInpAddress, mInpPhone);

		for (int i = 0; i < mBottomView.getChildCount(); i++) {
			if (mBottomView.getChildAt(i) instanceof PICInputForm) {
				PICInputForm inputForm = (PICInputForm) mBottomView.getChildAt(i);
				isValid = inputForm.isFormValid();
			}
		}

		for (int i = 0; i < mCIFContainer.getChildCount(); i++) {
			CIFInputForm cifInputForm = (CIFInputForm) mCIFContainer.getChildAt(i);
			isValid = cifInputForm.isFormValid();
		}

		return isValid;
	}

	private void doSubmitPIC(final Client client, final Bundle clientBundle) {
		final ProgressDialogFragment progressDialogFragment = ProgressDialogFragment.newInstance
				  ("Adding...").show(getSupportFragmentManager());

		List<PIC> pics = new ArrayList<>();
		for (int i = 0; i < mBottomView.getChildCount(); i++) {
			if (mBottomView.getChildAt(i) instanceof PICInputForm) {
				PICInputForm inputForm = (PICInputForm) mBottomView.getChildAt(i);
				PIC pic = inputForm.getPIC();
				pic.setClientId(String.valueOf(client.getId()));
				pics.add(pic);
			}
		}

		mPiCApiService.addBulkPIC(pics, new EventCallback<Boolean>() {
			@Override
			public void onEvent(Boolean aBoolean, Bundle bundle) {
				progressDialogFragment.dismissAllowingStateLoss();

				if (aBoolean == null) {
					CommonUtils.toastShort(mContext, R.string.error_string);
					return;
				}
				doSubmitCIF(client, clientBundle);
			}
		});
	}

	private void doSubmitClient() {
		final ProgressDialogFragment progressDialogFragment = ProgressDialogFragment.newInstance
				  ("Adding...").show(getSupportFragmentManager());

		String segmentation = SegmentationUtils.getSegmentation(mSpnSegmentation.getSelectedItemPosition());
		String sectorId = String.valueOf(mSectorAdapter.getItem(mSpnIndustrialSector.getSelectedItemPosition()).getId());
		String parentId = String.valueOf(mClientAdapter.getItem(mSpnClientGroup.getSelectedItemPosition()).getId());
		String bucId = String.valueOf(mBUCAdapter.getItem(mSpnBUC.getSelectedItemPosition()).getId());

		Client client = new Client();
		client.setName(mInpTitle.getText().toString().trim());
		client.setAddress(mInpAddress.getText().toString().trim());
		client.setPhone(mInpPhone.getText().toString().trim());
		client.setType(segmentation);
		client.setIndustrialSectorId(sectorId);
		client.setParentId(parentId);
		client.setBusinessUnitCodeId(bucId);
		client.setClientCategory(getClientCategory());

		mApiService.addClient(client, new EventCallback<Boolean>() {
			@Override
			public void onEvent(Boolean data, Bundle bundle) {
				progressDialogFragment.dismissAllowingStateLoss();

				if (data == null) {
					CommonUtils.toastShort(mContext, R.string.error_string);
					return;
				}

				Client clientResult = bundle.getParcelable(Client.class.getSimpleName());
				if (mBottomView.getVisibility() == View.VISIBLE) {
					doSubmitPIC(clientResult, bundle);
				} else {
					doSubmitCIF(clientResult, bundle);
				}
			}
		});
	}

	private void doSubmitCIF(Client client, final Bundle clientBundle) {

		List<CIFs.CIF> cifs = new ArrayList<>();
		for (int i = 0; i < mCIFContainer.getChildCount(); i++) {
			CIFInputForm cifInputForm = (CIFInputForm) mCIFContainer.getChildAt(i);
			CIFs.CIF cif = cifInputForm.getCIF();
			cif.setClientId(String.valueOf(client.getId()));
			cifs.add(cif);
		}

		CIFApiService cifApiService = new CIFApiService(mContext);
		cifApiService.postBulkCIF(cifs, new EventCallback<Boolean>() {
			@Override
			public void onEvent(Boolean aBoolean, Bundle bundle) {
				setResult(Activity.RESULT_OK, BundleHelper.createIntentWithBundle(clientBundle));
				finish();
			}
		});
	}

	private String getClientCategory() {
		int resId = mRadioGroup.getCheckedRadioButtonId();
		return resId == R.id.radioGold ? "gold" : "premium";
	}


	/* ---------- LAUNCHER ------------ */

	public static void startForResult(BaseFragment baseFragment) {
		baseFragment.startActivityForResult(new Intent(baseFragment.getActivity(), AddCustomerAct
				  .class), BaseInputAct.BASE_INPUT_CODE);
	}

	public static void start(Context context) {
		Intent intent = new Intent(context, AddCustomerAct.class);
		context.startActivity(intent);
	}
}
