package com.mandiri.salestools.apiservice;

import com.mandiri.salestools.model.BaseDao;

import java.util.List;

/**
 * Created by esa on 16/08/15, with awesomeness
 */
public class BUCs extends BaseDao {

	private List<BUC> businessUnitCodes;

	public BUCs() {
	}

	public void setBusinessUnitCodes(List<BUC> businessUnitCodes) {
		this.businessUnitCodes = businessUnitCodes;
	}

	public List<BUC> getBusinessUnitCodes() {
		return businessUnitCodes;
	}


	public static class BUC {
		/**
		 * regionalOffice :
		 * createdAt : 2015-08-14T15:26:15.000Z
		 * deletedAt : null
		 * name : CB101
		 * id : 1
		 * departementId : 2
		 * updatedAt : 2015-08-14T15:26:15.000Z
		 */
		private String regionalOffice;
		private String createdAt;
		private String deletedAt;
		private String name;
		private int id;
		private int departementId;
		private String updatedAt;

		public void setRegionalOffice(String regionalOffice) {
			this.regionalOffice = regionalOffice;
		}

		public void setCreatedAt(String createdAt) {
			this.createdAt = createdAt;
		}

		public void setDeletedAt(String deletedAt) {
			this.deletedAt = deletedAt;
		}

		public void setName(String name) {
			this.name = name;
		}

		public void setId(int id) {
			this.id = id;
		}

		public void setDepartementId(int departementId) {
			this.departementId = departementId;
		}

		public void setUpdatedAt(String updatedAt) {
			this.updatedAt = updatedAt;
		}

		public String getRegionalOffice() {
			return regionalOffice;
		}

		public String getCreatedAt() {
			return createdAt;
		}

		public String getDeletedAt() {
			return deletedAt;
		}

		public String getName() {
			return name;
		}

		public int getId() {
			return id;
		}

		public int getDepartementId() {
			return departementId;
		}

		public String getUpdatedAt() {
			return updatedAt;
		}
	}
}
