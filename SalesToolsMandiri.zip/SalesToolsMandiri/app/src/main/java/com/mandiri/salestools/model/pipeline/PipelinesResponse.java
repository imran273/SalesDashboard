package com.mandiri.salestools.model.pipeline;

import android.os.Parcel;

import com.mandiri.salestools.model.BaseDao;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by esa on 04/06/15, with awesomeness
 */
public class PipelinesResponse extends BaseDao {

	private List<Pipeline> offerings;

	public void setOfferings(List<Pipeline> offerings) {
		this.offerings = offerings;
	}

	public List<Pipeline> getPipelines() {
		return offerings;
	}

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		super.writeToParcel(dest, flags);
		dest.writeList(this.offerings);
	}

	public PipelinesResponse() {
	}

	protected PipelinesResponse(Parcel in) {
		this.offerings = new ArrayList<>();
		in.readList(this.offerings, List.class.getClassLoader());
	}

	public static final Creator<PipelinesResponse> CREATOR = new Creator<PipelinesResponse>() {
		public PipelinesResponse createFromParcel(Parcel source) {
			return new PipelinesResponse(source);
		}

		public PipelinesResponse[] newArray(int size) {
			return new PipelinesResponse[size];
		}
	};
}
