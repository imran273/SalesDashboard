package com.mandiri.salestools.model.report;

import android.os.Parcel;
import android.os.Parcelable;

public class Report implements Parcelable {

    /**
     * date : 2015-06-29T09:15:40.000Z
     * flagKTA : false
     * flagMGT : false
     * flagMCM : false
     * flagSCF : false
     * flagGiro : false
     * flagForfeiting : false
     * flagARFinancing : false
     * createdAt : 2015-06-29T09:15:43.000Z
     * clientType : new
     * flagDeptPengurus : false
     * flagEDC : false
     * flagBillPayment : false
     * flagOthers : false
     * flagGiroPengurus : false
     * id : 1
     * flagMPos : false
     * updatedAt : 2015-06-29T09:15:43.000Z
     * annualSales : 0
     * flagZBA : false
     * flagCreditCard : false
     * flagAXAMandiri : false
     * flagKMK : false
     * deletedAt : null
     * statusId : 1
     * flagETAX : false
     * flagAutoDebet : false
     * flagTBM : false
     * flagH2H : false
     * venue :
     * flagMVA : false
     * flagDF : false
     * flagNationalPooling : false
     * flagKendaraanMandiri : false
     * flagPrepaidCard : false
     * flagTR : false
     * flagDistributorCard : false
     * description :
     * flagBankGuarante : false
     * salesId : 1
     * flagBillAgregator : false
     * realizationId : 1
     * flagKreditMitraKarya : false
     * flagPayroll : false
     * flagERTE : false
     * product : Distributor Financing
     * attendee : none
     * flagDepo : false
     * flagKI : false
     * flagTabPengurus : false
     * offeringId : 2
     * flagCashPickUp : false
     * flagLCSKBDN : false
     */
    private String date;
    private boolean flagKTA;
    private boolean flagMGT;
    private boolean flagMCM;
    private boolean flagSCF;
    private boolean flagGiro;
    private boolean flagForfeiting;
    private boolean flagARFinancing;
    private String createdAt;
    private String clientType;
    private boolean flagDeptPengurus;
    private boolean flagEDC;
    private boolean flagBillPayment;
    private boolean flagOthers;
    private boolean flagGiroPengurus;
    private int id;
    private boolean flagMPos;
    private String updatedAt;
    private int annualSales;
    private boolean flagZBA;
    private boolean flagCreditCard;
    private boolean flagAXAMandiri;
    private boolean flagKMK;
    private String deletedAt;
    private int statusId;
    private boolean flagETAX;
    private boolean flagAutoDebet;
    private boolean flagTBM;
    private boolean flagH2H;
    private String venue;
    private boolean flagMVA;
    private boolean flagDF;
    private boolean flagNationalPooling;
    private boolean flagKendaraanMandiri;
    private boolean flagPrepaidCard;
    private boolean flagTR;
    private boolean flagDistributorCard;
    private String description;
    private boolean flagBankGuarante;
    private int salesId;
    private boolean flagBillAgregator;
    private int realizationId;
    private boolean flagKreditMitraKarya;
    private boolean flagPayroll;
    private boolean flagERTE;
    private String product;
    private String attendee;
    private boolean flagDepo;
    private boolean flagKI;
    private boolean flagTabPengurus;
    private int offeringId;
    private boolean flagCashPickUp;
    private boolean flagLCSKBDN;

    public void setDate(String date) {
        this.date = date;
    }

    public void setFlagKTA(boolean flagKTA) {
        this.flagKTA = flagKTA;
    }

    public void setFlagMGT(boolean flagMGT) {
        this.flagMGT = flagMGT;
    }

    public void setFlagMCM(boolean flagMCM) {
        this.flagMCM = flagMCM;
    }

    public void setFlagSCF(boolean flagSCF) {
        this.flagSCF = flagSCF;
    }

    public void setFlagGiro(boolean flagGiro) {
        this.flagGiro = flagGiro;
    }

    public void setFlagForfeiting(boolean flagForfeiting) {
        this.flagForfeiting = flagForfeiting;
    }

    public void setFlagARFinancing(boolean flagARFinancing) {
        this.flagARFinancing = flagARFinancing;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public void setClientType(String clientType) {
        this.clientType = clientType;
    }

    public void setFlagDeptPengurus(boolean flagDeptPengurus) {
        this.flagDeptPengurus = flagDeptPengurus;
    }

    public void setFlagEDC(boolean flagEDC) {
        this.flagEDC = flagEDC;
    }

    public void setFlagBillPayment(boolean flagBillPayment) {
        this.flagBillPayment = flagBillPayment;
    }

    public void setFlagOthers(boolean flagOthers) {
        this.flagOthers = flagOthers;
    }

    public void setFlagGiroPengurus(boolean flagGiroPengurus) {
        this.flagGiroPengurus = flagGiroPengurus;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setFlagMPos(boolean flagMPos) {
        this.flagMPos = flagMPos;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public void setAnnualSales(int annualSales) {
        this.annualSales = annualSales;
    }

    public void setFlagZBA(boolean flagZBA) {
        this.flagZBA = flagZBA;
    }

    public void setFlagCreditCard(boolean flagCreditCard) {
        this.flagCreditCard = flagCreditCard;
    }

    public void setFlagAXAMandiri(boolean flagAXAMandiri) {
        this.flagAXAMandiri = flagAXAMandiri;
    }

    public void setFlagKMK(boolean flagKMK) {
        this.flagKMK = flagKMK;
    }

    public void setDeletedAt(String deletedAt) {
        this.deletedAt = deletedAt;
    }

    public void setStatusId(int statusId) {
        this.statusId = statusId;
    }

    public void setFlagETAX(boolean flagETAX) {
        this.flagETAX = flagETAX;
    }

    public void setFlagAutoDebet(boolean flagAutoDebet) {
        this.flagAutoDebet = flagAutoDebet;
    }

    public void setFlagTBM(boolean flagTBM) {
        this.flagTBM = flagTBM;
    }

    public void setFlagH2H(boolean flagH2H) {
        this.flagH2H = flagH2H;
    }

    public void setVenue(String venue) {
        this.venue = venue;
    }

    public void setFlagMVA(boolean flagMVA) {
        this.flagMVA = flagMVA;
    }

    public void setFlagDF(boolean flagDF) {
        this.flagDF = flagDF;
    }

    public void setFlagNationalPooling(boolean flagNationalPooling) {
        this.flagNationalPooling = flagNationalPooling;
    }

    public void setFlagKendaraanMandiri(boolean flagKendaraanMandiri) {
        this.flagKendaraanMandiri = flagKendaraanMandiri;
    }

    public void setFlagPrepaidCard(boolean flagPrepaidCard) {
        this.flagPrepaidCard = flagPrepaidCard;
    }

    public void setFlagTR(boolean flagTR) {
        this.flagTR = flagTR;
    }

    public void setFlagDistributorCard(boolean flagDistributorCard) {
        this.flagDistributorCard = flagDistributorCard;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setFlagBankGuarante(boolean flagBankGuarante) {
        this.flagBankGuarante = flagBankGuarante;
    }

    public void setSalesId(int salesId) {
        this.salesId = salesId;
    }

    public void setFlagBillAgregator(boolean flagBillAgregator) {
        this.flagBillAgregator = flagBillAgregator;
    }

    public void setRealizationId(int realizationId) {
        this.realizationId = realizationId;
    }

    public void setFlagKreditMitraKarya(boolean flagKreditMitraKarya) {
        this.flagKreditMitraKarya = flagKreditMitraKarya;
    }

    public void setFlagPayroll(boolean flagPayroll) {
        this.flagPayroll = flagPayroll;
    }

    public void setFlagERTE(boolean flagERTE) {
        this.flagERTE = flagERTE;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public void setAttendee(String attendee) {
        this.attendee = attendee;
    }

    public void setFlagDepo(boolean flagDepo) {
        this.flagDepo = flagDepo;
    }

    public void setFlagKI(boolean flagKI) {
        this.flagKI = flagKI;
    }

    public void setFlagTabPengurus(boolean flagTabPengurus) {
        this.flagTabPengurus = flagTabPengurus;
    }

    public void setOfferingId(int offeringId) {
        this.offeringId = offeringId;
    }

    public void setFlagCashPickUp(boolean flagCashPickUp) {
        this.flagCashPickUp = flagCashPickUp;
    }

    public void setFlagLCSKBDN(boolean flagLCSKBDN) {
        this.flagLCSKBDN = flagLCSKBDN;
    }

    public String getDate() {
        return date;
    }

    public boolean isFlagKTA() {
        return flagKTA;
    }

    public boolean isFlagMGT() {
        return flagMGT;
    }

    public boolean isFlagMCM() {
        return flagMCM;
    }

    public boolean isFlagSCF() {
        return flagSCF;
    }

    public boolean isFlagGiro() {
        return flagGiro;
    }

    public boolean isFlagForfeiting() {
        return flagForfeiting;
    }

    public boolean isFlagARFinancing() {
        return flagARFinancing;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public String getClientType() {
        return clientType;
    }

    public boolean isFlagDeptPengurus() {
        return flagDeptPengurus;
    }

    public boolean isFlagEDC() {
        return flagEDC;
    }

    public boolean isFlagBillPayment() {
        return flagBillPayment;
    }

    public boolean isFlagOthers() {
        return flagOthers;
    }

    public boolean isFlagGiroPengurus() {
        return flagGiroPengurus;
    }

    public int getId() {
        return id;
    }

    public boolean isFlagMPos() {
        return flagMPos;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public int getAnnualSales() {
        return annualSales;
    }

    public boolean isFlagZBA() {
        return flagZBA;
    }

    public boolean isFlagCreditCard() {
        return flagCreditCard;
    }

    public boolean isFlagAXAMandiri() {
        return flagAXAMandiri;
    }

    public boolean isFlagKMK() {
        return flagKMK;
    }

    public String getDeletedAt() {
        return deletedAt;
    }

    public int getStatusId() {
        return statusId;
    }

    public boolean isFlagETAX() {
        return flagETAX;
    }

    public boolean isFlagAutoDebet() {
        return flagAutoDebet;
    }

    public boolean isFlagTBM() {
        return flagTBM;
    }

    public boolean isFlagH2H() {
        return flagH2H;
    }

    public String getVenue() {
        return venue;
    }

    public boolean isFlagMVA() {
        return flagMVA;
    }

    public boolean isFlagDF() {
        return flagDF;
    }

    public boolean isFlagNationalPooling() {
        return flagNationalPooling;
    }

    public boolean isFlagKendaraanMandiri() {
        return flagKendaraanMandiri;
    }

    public boolean isFlagPrepaidCard() {
        return flagPrepaidCard;
    }

    public boolean isFlagTR() {
        return flagTR;
    }

    public boolean isFlagDistributorCard() {
        return flagDistributorCard;
    }

    public String getDescription() {
        return description;
    }

    public boolean isFlagBankGuarante() {
        return flagBankGuarante;
    }

    public int getSalesId() {
        return salesId;
    }

    public boolean isFlagBillAgregator() {
        return flagBillAgregator;
    }

    public int getRealizationId() {
        return realizationId;
    }

    public boolean isFlagKreditMitraKarya() {
        return flagKreditMitraKarya;
    }

    public boolean isFlagPayroll() {
        return flagPayroll;
    }

    public boolean isFlagERTE() {
        return flagERTE;
    }

    public String getProduct() {
        return product;
    }

    public String getAttendee() {
        return attendee;
    }

    public boolean isFlagDepo() {
        return flagDepo;
    }

    public boolean isFlagKI() {
        return flagKI;
    }

    public boolean isFlagTabPengurus() {
        return flagTabPengurus;
    }

    public int getOfferingId() {
        return offeringId;
    }

    public boolean isFlagCashPickUp() {
        return flagCashPickUp;
    }

    public boolean isFlagLCSKBDN() {
        return flagLCSKBDN;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.date);
        dest.writeByte(flagKTA ? (byte) 1 : (byte) 0);
        dest.writeByte(flagMGT ? (byte) 1 : (byte) 0);
        dest.writeByte(flagMCM ? (byte) 1 : (byte) 0);
        dest.writeByte(flagSCF ? (byte) 1 : (byte) 0);
        dest.writeByte(flagGiro ? (byte) 1 : (byte) 0);
        dest.writeByte(flagForfeiting ? (byte) 1 : (byte) 0);
        dest.writeByte(flagARFinancing ? (byte) 1 : (byte) 0);
        dest.writeString(this.createdAt);
        dest.writeString(this.clientType);
        dest.writeByte(flagDeptPengurus ? (byte) 1 : (byte) 0);
        dest.writeByte(flagEDC ? (byte) 1 : (byte) 0);
        dest.writeByte(flagBillPayment ? (byte) 1 : (byte) 0);
        dest.writeByte(flagOthers ? (byte) 1 : (byte) 0);
        dest.writeByte(flagGiroPengurus ? (byte) 1 : (byte) 0);
        dest.writeInt(this.id);
        dest.writeByte(flagMPos ? (byte) 1 : (byte) 0);
        dest.writeString(this.updatedAt);
        dest.writeInt(this.annualSales);
        dest.writeByte(flagZBA ? (byte) 1 : (byte) 0);
        dest.writeByte(flagCreditCard ? (byte) 1 : (byte) 0);
        dest.writeByte(flagAXAMandiri ? (byte) 1 : (byte) 0);
        dest.writeByte(flagKMK ? (byte) 1 : (byte) 0);
        dest.writeString(this.deletedAt);
        dest.writeInt(this.statusId);
        dest.writeByte(flagETAX ? (byte) 1 : (byte) 0);
        dest.writeByte(flagAutoDebet ? (byte) 1 : (byte) 0);
        dest.writeByte(flagTBM ? (byte) 1 : (byte) 0);
        dest.writeByte(flagH2H ? (byte) 1 : (byte) 0);
        dest.writeString(this.venue);
        dest.writeByte(flagMVA ? (byte) 1 : (byte) 0);
        dest.writeByte(flagDF ? (byte) 1 : (byte) 0);
        dest.writeByte(flagNationalPooling ? (byte) 1 : (byte) 0);
        dest.writeByte(flagKendaraanMandiri ? (byte) 1 : (byte) 0);
        dest.writeByte(flagPrepaidCard ? (byte) 1 : (byte) 0);
        dest.writeByte(flagTR ? (byte) 1 : (byte) 0);
        dest.writeByte(flagDistributorCard ? (byte) 1 : (byte) 0);
        dest.writeString(this.description);
        dest.writeByte(flagBankGuarante ? (byte) 1 : (byte) 0);
        dest.writeInt(this.salesId);
        dest.writeByte(flagBillAgregator ? (byte) 1 : (byte) 0);
        dest.writeInt(this.realizationId);
        dest.writeByte(flagKreditMitraKarya ? (byte) 1 : (byte) 0);
        dest.writeByte(flagPayroll ? (byte) 1 : (byte) 0);
        dest.writeByte(flagERTE ? (byte) 1 : (byte) 0);
        dest.writeString(this.product);
        dest.writeString(this.attendee);
        dest.writeByte(flagDepo ? (byte) 1 : (byte) 0);
        dest.writeByte(flagKI ? (byte) 1 : (byte) 0);
        dest.writeByte(flagTabPengurus ? (byte) 1 : (byte) 0);
        dest.writeInt(this.offeringId);
        dest.writeByte(flagCashPickUp ? (byte) 1 : (byte) 0);
        dest.writeByte(flagLCSKBDN ? (byte) 1 : (byte) 0);
    }

    public Report() {
    }

    protected Report(Parcel in) {
        this.date = in.readString();
        this.flagKTA = in.readByte() != 0;
        this.flagMGT = in.readByte() != 0;
        this.flagMCM = in.readByte() != 0;
        this.flagSCF = in.readByte() != 0;
        this.flagGiro = in.readByte() != 0;
        this.flagForfeiting = in.readByte() != 0;
        this.flagARFinancing = in.readByte() != 0;
        this.createdAt = in.readString();
        this.clientType = in.readString();
        this.flagDeptPengurus = in.readByte() != 0;
        this.flagEDC = in.readByte() != 0;
        this.flagBillPayment = in.readByte() != 0;
        this.flagOthers = in.readByte() != 0;
        this.flagGiroPengurus = in.readByte() != 0;
        this.id = in.readInt();
        this.flagMPos = in.readByte() != 0;
        this.updatedAt = in.readString();
        this.annualSales = in.readInt();
        this.flagZBA = in.readByte() != 0;
        this.flagCreditCard = in.readByte() != 0;
        this.flagAXAMandiri = in.readByte() != 0;
        this.flagKMK = in.readByte() != 0;
        this.deletedAt = in.readString();
        this.statusId = in.readInt();
        this.flagETAX = in.readByte() != 0;
        this.flagAutoDebet = in.readByte() != 0;
        this.flagTBM = in.readByte() != 0;
        this.flagH2H = in.readByte() != 0;
        this.venue = in.readString();
        this.flagMVA = in.readByte() != 0;
        this.flagDF = in.readByte() != 0;
        this.flagNationalPooling = in.readByte() != 0;
        this.flagKendaraanMandiri = in.readByte() != 0;
        this.flagPrepaidCard = in.readByte() != 0;
        this.flagTR = in.readByte() != 0;
        this.flagDistributorCard = in.readByte() != 0;
        this.description = in.readString();
        this.flagBankGuarante = in.readByte() != 0;
        this.salesId = in.readInt();
        this.flagBillAgregator = in.readByte() != 0;
        this.realizationId = in.readInt();
        this.flagKreditMitraKarya = in.readByte() != 0;
        this.flagPayroll = in.readByte() != 0;
        this.flagERTE = in.readByte() != 0;
        this.product = in.readString();
        this.attendee = in.readString();
        this.flagDepo = in.readByte() != 0;
        this.flagKI = in.readByte() != 0;
        this.flagTabPengurus = in.readByte() != 0;
        this.offeringId = in.readInt();
        this.flagCashPickUp = in.readByte() != 0;
        this.flagLCSKBDN = in.readByte() != 0;
    }

    public static final Creator<Report> CREATOR = new Creator<Report>() {
        public Report createFromParcel(Parcel source) {
            return new Report(source);
        }

        public Report[] newArray(int size) {
            return new Report[size];
        }
    };
}